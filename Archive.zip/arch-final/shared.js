// ════════════════════════════════════
//  ARCH EDUCATION — SHARED JS
// ════════════════════════════════════
(function(){
  // ── CURSOR ──
  const co = document.getElementById('cur-o');
  const ci = document.getElementById('cur-i');
  if(!co||!ci) return;
  let mx=innerWidth/2,my=innerHeight/2,rx=mx,ry=my;
  document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;});
  (function tick(){
    rx+=(mx-rx)*.11; ry+=(my-ry)*.11;
    ci.style.left=mx+'px'; ci.style.top=my+'px';
    co.style.left=rx+'px'; co.style.top=ry+'px';
    requestAnimationFrame(tick);
  })();
  document.querySelectorAll('a,button,.course-card,.mentor-card,.faq-item').forEach(el=>{
    el.addEventListener('mouseenter',()=>{co.style.width='60px';co.style.height='60px';co.style.borderColor='rgba(255,61,0,.4)';});
    el.addEventListener('mouseleave',()=>{co.style.width='38px';co.style.height='38px';co.style.borderColor='rgba(0,0,0,.25)';});
  });

  // ── PROGRESS BAR ──
  const pb = document.getElementById('pbar');
  if(pb){
    window.addEventListener('scroll',()=>{
      const pct = window.scrollY/(document.body.scrollHeight-innerHeight)*100;
      pb.style.width=Math.min(100,pct)+'%';
    },{passive:true});
  }

  // ── SCROLL REVEAL ──
  const rvEls = document.querySelectorAll('.rv,.rv-l,.rv-r');
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        const d = parseFloat(getComputedStyle(e.target).transitionDelay||0)*1000;
        setTimeout(()=>e.target.classList.add('in'),d);
        obs.unobserve(e.target);
      }
    });
  },{threshold:.1});
  rvEls.forEach(el=>obs.observe(el));

  // ── NAV SCROLL ──
  const nav = document.querySelector('.nav');
  if(nav){
    window.addEventListener('scroll',()=>{
      nav.style.height = window.scrollY>40?'56px':'66px';
    },{passive:true});
  }

  // ── ACTIVE NAV LINK ──
  const path = window.location.pathname.split('/').pop()||'index.html';
  document.querySelectorAll('.nav-links a').forEach(a=>{
    if(a.getAttribute('href')===path) a.classList.add('active');
  });

  // ── ANIME BTN RIPPLE ──
  document.querySelectorAll('.btn').forEach(btn=>{
    btn.style.position='relative';
    btn.style.overflow='hidden';
    btn.addEventListener('click',e=>{
      const r=btn.getBoundingClientRect();
      const rip=document.createElement('span');
      rip.style.cssText=`position:absolute;width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.35);top:${e.clientY-r.top-4}px;left:${e.clientX-r.left-4}px;pointer-events:none;`;
      btn.appendChild(rip);
      if(window.anime){
        anime({targets:rip,scale:[1,28],opacity:[.5,0],duration:550,easing:'easeOutExpo',complete(){rip.remove();}});
      } else { setTimeout(()=>rip.remove(),600); }
    });
  });

  // ── CART COUNT ──
  const badge = document.querySelector('.cart-badge');
  const count = parseInt(localStorage.getItem('arch-cart')||'0');
  if(badge) badge.textContent = count||'0';
})();
