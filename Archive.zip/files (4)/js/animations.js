// ============================================================
// ANIMATIONS.JS — GSAP ScrollTrigger + Anime.js animations
// ============================================================

gsap.registerPlugin(ScrollTrigger);

// ─── CURSOR ─────────────────────────────────────────────────
(function initCursor() {
  const dot = document.getElementById('cursor');
  const ring = document.getElementById('cursor-ring');
  if (!dot || !ring) return;

  let mx = 0, my = 0, rx = 0, ry = 0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
    dot.style.left = mx + 'px';
    dot.style.top = my + 'px';
  });

  (function lerpRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top = ry + 'px';
    requestAnimationFrame(lerpRing);
  })();

  document.querySelectorAll('a, button, .btn-primary, .btn-outline, .filter-btn').forEach(el => {
    el.addEventListener('mouseenter', () => {
      dot.style.width = '32px';
      dot.style.height = '32px';
      ring.style.opacity = '0';
    });
    el.addEventListener('mouseleave', () => {
      dot.style.width = '12px';
      dot.style.height = '12px';
      ring.style.opacity = '1';
    });
  });
})();

// ─── NAVBAR ─────────────────────────────────────────────────
(function initNav() {
  const nav = document.querySelector('nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });
})();

// ─── PROGRESS BAR ────────────────────────────────────────────
(function initProgressBar() {
  const bar = document.getElementById('progress-bar');
  if (!bar) return;
  window.addEventListener('scroll', () => {
    const pct = window.scrollY / (document.body.scrollHeight - window.innerHeight) * 100;
    bar.style.width = pct + '%';
  });
})();

// ─── HERO WORD ENTRANCE (Anime.js) ──────────────────────────
function initHeroEntrance() {
  const title = document.querySelector('.hero-title');
  if (!title) return;

  // Wrap words
  title.querySelectorAll('.word').forEach(w => {
    // already wrapped
  });

  const words = title.querySelectorAll('.word');
  const eyebrow = document.querySelector('.hero-eyebrow');
  const sub = document.querySelector('.hero-sub');
  const hint = document.querySelector('.scroll-hint');

  anime.timeline({ easing: 'cubicBezier(0.16, 1, 0.3, 1)' })
    .add({ targets: eyebrow, opacity: [0, 1], translateY: [20, 0], duration: 600, delay: 200 })
    .add({
      targets: words,
      translateY: ['110%', '0%'],
      duration: 700,
      delay: anime.stagger(80),
    }, '-=300')
    .add({ targets: sub, opacity: [0, 1], translateY: [20, 0], duration: 600 }, '-=300')
    .add({ targets: hint, opacity: [0, 1], translateY: [10, 0], duration: 500 }, '-=200');
}

// ─── CINEMATIC STAGE — Main scroll driver ────────────────────
function initCinematicStage() {
  const stage = document.getElementById('cinematic-stage');
  if (!stage) return;

  const pin = document.getElementById('stage-pin');
  const cuts = document.querySelectorAll('.cut');
  const totalScrollHeight = stage.scrollHeight;

  // Init canvases
  const heroCanvas = document.getElementById('hero-canvas');
  let heroParticles;
  if (heroCanvas) heroParticles = initHeroParticles(heroCanvas);

  // Dot grid (cut1 overlay) — inline styled
  const dotGrid = document.getElementById('dot-grid');
  const dotDots = dotGrid ? dotGrid.querySelectorAll('.dot-cell') : [];

  // SVG line draw (cut1 lower or cut2)
  const svgPaths = document.querySelectorAll('.svg-path-draw');
  svgPaths.forEach(path => {
    const len = path.getTotalLength();
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
  });

  // Scatter canvas (cut3)
  const scatterCanvas = document.getElementById('scatter-canvas');
  let scatterSystem;
  if (scatterCanvas) scatterSystem = initScatterConverge(scatterCanvas);

  // Orbit canvas (cut4)
  const orbitCanvas = document.getElementById('orbit-canvas');
  let orbitSystem;
  if (orbitCanvas) orbitSystem = initOrbitRings(orbitCanvas);

  // Course cards in cut1
  const filmCards = document.querySelectorAll('.course-card-film');

  // Spring cards in cut3
  const springCards = document.querySelectorAll('.spring-card');

  // Mentor tiles in cut4
  const mentorTiles = document.querySelectorAll('.mentor-tile');

  // Cut content text overlays
  const cut1Text = document.querySelector('.cut1-left');
  const cut2Stats = document.querySelectorAll('.stat-item');
  const cut3Header = document.querySelector('.cut3-header');
  const cut4Header = document.querySelector('.cut4-header');

  // Stats counter
  let statsAnimated = false;

  function animateStats() {
    if (statsAnimated) return;
    statsAnimated = true;
    document.querySelectorAll('.stat-num[data-target]').forEach((el, i) => {
      const target = parseInt(el.dataset.target);
      anime({
        targets: el,
        innerHTML: [0, target],
        round: 1,
        duration: 1800,
        delay: i * 150,
        easing: 'easeOutExpo',
        update: function(a) {
          el.innerHTML = Math.round(a.animations[0].currentValue).toLocaleString() + (el.dataset.suffix || '');
        }
      });
    });
  }

  // Map progress (0-1) to cut index (0-4) and local progress
  // Breakpoints: 0-0.15 = cut0, 0.15-0.35 = cut1, 0.35-0.55 = cut2, 0.55-0.75 = cut3, 0.75-1.0 = cut4
  const cutBreaks = [0, 0.15, 0.35, 0.55, 0.75, 1.0];

  function getCutInfo(progress) {
    for (let i = 0; i < cutBreaks.length - 1; i++) {
      if (progress <= cutBreaks[i + 1]) {
        const local = (progress - cutBreaks[i]) / (cutBreaks[i + 1] - cutBreaks[i]);
        return { cut: i, local: Math.max(0, Math.min(1, local)) };
      }
    }
    return { cut: 4, local: 1 };
  }

  function onProgress(p) {
    const { cut, local } = getCutInfo(p);

    // ── Transition cuts ──────────────────────────────────
    cuts.forEach((el, i) => {
      if (i === cut) {
        gsap.to(el, { opacity: 1, duration: 0.3 });
        el.style.pointerEvents = 'auto';
      } else {
        gsap.to(el, { opacity: 0, duration: 0.3 });
        el.style.pointerEvents = 'none';
      }
    });

    // ── CUT 0 — Hero particle field ──────────────────────
    // nothing special, just ambient

    // ── CUT 1 — Film cards cascade ───────────────────────
    if (cut === 1) {
      filmCards.forEach((card, i) => {
        const t = Math.max(0, (local - i * 0.12) / 0.4);
        gsap.set(card, {
          x: (1 - Math.min(1, t)) * 120,
          opacity: Math.min(1, t)
        });
      });

      if (cut1Text) {
        gsap.set(cut1Text, { opacity: local > 0.3 ? 1 : local / 0.3 });
      }

      // Dot grid
      dotDots.forEach((dot, i) => {
        const centerDelay = getCenterDelay(i, 8) * 0.4;
        const t = Math.max(0, (local - centerDelay) / 0.6);
        const clampedT = Math.min(1, t);
        dot.style.transform = `scale(${1 + clampedT * 1.5})`;
        dot.style.opacity = 0.05 + clampedT * 0.7;
        dot.style.background = `rgba(255,61,0,${clampedT * 0.8})`;
      });
    }

    // ── CUT 2 — Red stats ────────────────────────────────
    if (cut === 2) {
      if (local > 0.2 && !statsAnimated) animateStats();
      cut2Stats && cut2Stats.forEach((s, i) => {
        const t = Math.max(0, (local - i * 0.08) / 0.4);
        gsap.set(s, { opacity: Math.min(1, t), y: (1 - Math.min(1, t)) * 30 });
      });

      // SVG paths draw
      svgPaths.forEach(path => {
        const len = parseFloat(path.style.strokeDasharray);
        path.style.strokeDashoffset = len * (1 - Math.max(0, (local - 0.1) / 0.7));
      });
    }

    // ── CUT 3 — Spring cards ─────────────────────────────
    if (cut === 3) {
      if (scatterSystem) scatterSystem.setProgress(local);

      springCards.forEach((card, i) => {
        const t = Math.max(0, (local - i * 0.08) / 0.5);
        gsap.set(card, {
          y: (1 - Math.min(1, t)) * 80,
          opacity: Math.min(1, t)
        });
      });

      if (cut3Header) {
        gsap.set(cut3Header, { opacity: local > 0.1 ? 1 : local / 0.1 });
      }
    }

    // ── CUT 4 — Orbit rings + mentor tiles ───────────────
    if (cut === 4) {
      if (orbitSystem) orbitSystem.setProgress(local);

      mentorTiles.forEach((tile, i) => {
        const t = Math.max(0, (local - i * 0.1) / 0.5);
        gsap.set(tile, {
          scale: 0.85 + Math.min(1, t) * 0.15,
          opacity: Math.min(1, t)
        });
      });

      if (cut4Header) {
        gsap.set(cut4Header, { opacity: local > 0.1 ? 1 : local / 0.1 });
      }
    }
  }

  // Create pinned scroll trigger
  ScrollTrigger.create({
    trigger: stage,
    start: 'top top',
    end: 'bottom bottom',
    pin: pin,
    scrub: 0.8,
    onUpdate: (self) => onProgress(self.progress)
  });
}

// Helper: distance from center in 8x8 grid
function getCenterDelay(index, cols) {
  const row = Math.floor(index / cols);
  const col = index % cols;
  const centerR = (cols - 1) / 2;
  const centerC = (cols - 1) / 2;
  const dist = Math.sqrt(Math.pow(row - centerR, 2) + Math.pow(col - centerC, 2));
  return dist / (cols / 2);
}

// ─── MARQUEE HOVER PAUSE ─────────────────────────────────────
function initMarquee() {
  const inner = document.querySelector('.marquee-inner');
  if (!inner) return;
  const band = inner.closest('.marquee-band');
  if (!band) return;
  band.addEventListener('mouseenter', () => inner.style.animationPlayState = 'paused');
  band.addEventListener('mouseleave', () => inner.style.animationPlayState = 'running');
}

// ─── TESTIMONIALS SCROLL REVEAL ──────────────────────────────
function initTestimonialsReveal() {
  const cards = document.querySelectorAll('.testimonial-card');
  cards.forEach((card, i) => {
    gsap.fromTo(card,
      { opacity: 0, y: 40 },
      {
        opacity: 1, y: 0, duration: 0.7,
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          toggleActions: 'play none none reverse'
        },
        delay: i * 0.1
      }
    );
  });
}

// ─── STATS BAND (non-stage stats on about/courses pages) ─────
function initStatsBand() {
  const nums = document.querySelectorAll('.stat-num[data-target]:not([data-animated])');
  nums.forEach(el => {
    ScrollTrigger.create({
      trigger: el,
      start: 'top 80%',
      once: true,
      onEnter: () => {
        el.dataset.animated = true;
        const target = parseInt(el.dataset.target);
        anime({
          duration: 1800,
          easing: 'easeOutExpo',
          update: function(a) {
            const val = Math.round(target * a.progress);
            el.innerHTML = val.toLocaleString() + (el.dataset.suffix || '');
          }
        });
      }
    });
  });
}

// ─── CTA SECTION REVEAL ──────────────────────────────────────
function initCTAReveal() {
  const cta = document.querySelector('.cta-section');
  if (!cta) return;
  gsap.fromTo(cta.querySelector('h2'),
    { opacity: 0, y: 60 },
    { opacity: 1, y: 0, duration: 1, scrollTrigger: { trigger: cta, start: 'top 70%' } }
  );
}

// ─── PAGE SECTION REVEALS (about, courses, mentors, contact) ──
function initPageReveals() {
  gsap.utils.toArray('.mentor-full-card, .course-full-card, .value-item').forEach((el, i) => {
    gsap.fromTo(el,
      { opacity: 0, y: 40 },
      {
        opacity: 1, y: 0, duration: 0.6,
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none reverse' },
        delay: (i % 3) * 0.1
      }
    );
  });
}

// ─── CONTACT FORM VALIDATION ─────────────────────────────────
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  function showError(fieldId, msg) {
    const err = document.getElementById(fieldId + '-error');
    if (err) { err.textContent = msg; err.classList.add('show'); }
  }
  function clearError(fieldId) {
    const err = document.getElementById(fieldId + '-error');
    if (err) err.classList.remove('show');
  }
  function validateEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
  function validatePhone(p) { return /^[\d\s\+\-\(\)]{7,15}$/.test(p); }

  ['name', 'email', 'phone', 'subject', 'message'].forEach(field => {
    const el = form.querySelector(`[name="${field}"]`);
    if (el) el.addEventListener('input', () => clearError(field));
  });

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    let valid = true;

    const name = form.querySelector('[name="name"]');
    const email = form.querySelector('[name="email"]');
    const phone = form.querySelector('[name="phone"]');
    const subject = form.querySelector('[name="subject"]');
    const message = form.querySelector('[name="message"]');

    if (!name || name.value.trim().length < 2) {
      showError('name', 'Please enter your full name.'); valid = false;
    }
    if (!email || !validateEmail(email.value)) {
      showError('email', 'Please enter a valid email address.'); valid = false;
    }
    if (phone && phone.value && !validatePhone(phone.value)) {
      showError('phone', 'Please enter a valid phone number.'); valid = false;
    }
    if (!subject || subject.value.trim().length < 2) {
      showError('subject', 'Please select a subject.'); valid = false;
    }
    if (!message || message.value.trim().length < 10) {
      showError('message', 'Please write at least 10 characters.'); valid = false;
    }

    if (valid) {
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Sending...';
      btn.disabled = true;
      setTimeout(() => {
        const success = document.getElementById('form-success');
        if (success) success.classList.add('show');
        form.reset();
        btn.textContent = 'Send Message';
        btn.disabled = false;
      }, 1200);
    }
  });
}

// ─── MOBILE RESPONSIVE SCROLLTRIGGER ─────────────────────────
function initMobileResponsive() {
  ScrollTrigger.matchMedia({
    '(max-width: 768px)': function() {
      ScrollTrigger.getAll().forEach(st => {
        if (st.vars && st.vars.pin) {
          st.kill();
        }
      });
    }
  });
}

// ─── INIT ALL ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  // Detect page
  const isIndex = document.body.classList.contains('page-index');
  const isContact = document.body.classList.contains('page-contact');

  if (isIndex) {
    initHeroEntrance();
    initCinematicStage();
    initMarquee();
    initTestimonialsReveal();
    initCTAReveal();
  }

  if (isContact) {
    initContactForm();
  }

  // Page hero canvas
  const pageHeroCanvas = document.getElementById('page-hero-canvas');
  if (pageHeroCanvas) initAmbientParticles(pageHeroCanvas, 55);

  initPageReveals();
  initStatsBand();
  initMobileResponsive();
});
