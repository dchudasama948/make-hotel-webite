// ============================================================
// PARTICLES.JS — Canvas particle systems for Vintar Academy
// ============================================================

// Hero particle field with mouse repel
function initHeroParticles(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  const particles = [];
  let mouse = { x: -999, y: -999 };
  let animId;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }

  function createParticles(n) {
    particles.length = 0;
    for (let i = 0; i < n; i++) {
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        ox: 0, oy: 0,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.4 + 0.4,
        // red spark?
        spark: Math.random() < 0.06
      });
    }
  }

  resize();
  createParticles(110);
  window.addEventListener('resize', () => { resize(); createParticles(110); });

  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  canvas.addEventListener('mouseleave', () => { mouse.x = -999; mouse.y = -999; });

  function draw() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach((p, i) => {
      // mouse repel
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 100) {
        const force = (100 - dist) / 100;
        p.vx += (dx / dist) * force * 0.6;
        p.vy += (dy / dist) * force * 0.6;
      }

      // dampen
      p.vx *= 0.98;
      p.vy *= 0.98;

      // clamp speed
      const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
      if (speed > 1.5) { p.vx = (p.vx / speed) * 1.5; p.vy = (p.vy / speed) * 1.5; }
      if (speed < 0.1) { p.vx += (Math.random() - 0.5) * 0.02; p.vy += (Math.random() - 0.5) * 0.02; }

      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = W;
      if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H;
      if (p.y > H) p.y = 0;

      // draw
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.spark ? 'rgba(255,61,0,0.7)' : 'rgba(245,245,240,0.55)';
      ctx.fill();

      // connect nearby
      for (let j = i + 1; j < particles.length; j++) {
        const px = p.x - particles[j].x;
        const py = p.y - particles[j].y;
        const d = Math.sqrt(px * px + py * py);
        if (d < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          const alpha = (1 - d / 120) * 0.07;
          ctx.strokeStyle = p.spark || particles[j].spark
            ? `rgba(255,61,0,${alpha})`
            : `rgba(245,245,240,${alpha})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });

    animId = requestAnimationFrame(draw);
  }

  draw();
  return { stop: () => cancelAnimationFrame(animId) };
}

// Small ambient particle bg (used in about/contact page heroes)
function initAmbientParticles(canvas, count = 60) {
  const ctx = canvas.getContext('2d');
  let W, H;
  const particles = [];
  let animId;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }

  resize();
  window.addEventListener('resize', resize);

  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * W,
      y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.25,
      vy: (Math.random() - 0.5) * 0.25,
      r: Math.random() * 1.2 + 0.3,
      spark: Math.random() < 0.08
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach((p, i) => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = W;
      if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H;
      if (p.y > H) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.spark ? 'rgba(255,61,0,0.5)' : 'rgba(245,245,240,0.4)';
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const dx = p.x - particles[j].x;
        const dy = p.y - particles[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 100) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(245,245,240,${(1 - d / 100) * 0.05})`;
          ctx.lineWidth = 0.4;
          ctx.stroke();
        }
      }
    });
    animId = requestAnimationFrame(draw);
  }

  draw();
  return { stop: () => cancelAnimationFrame(animId) };
}

// Scatter/converge particle system (Cut3 / feature)
function initScatterConverge(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H, animId;
  const N = 200;
  const particles = [];
  let progress = 0;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    initPts();
  }

  function initPts() {
    particles.length = 0;
    const cx = W / 2, cy = H / 2;
    for (let i = 0; i < N; i++) {
      const angle = (i / N) * Math.PI * 2;
      const R = Math.min(W, H) * 0.28;
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        tx: cx + Math.cos(angle) * R, // target: circle
        ty: cy + Math.sin(angle) * R,
        sx: Math.random() * W,        // scatter position
        sy: Math.random() * H,
        r: Math.random() * 2 + 0.5
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  function lerp(a, b, t) { return a + (b - a) * t; }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach(p => {
      let px, py;
      if (progress < 0.5) {
        // scatter phase 0→0.5
        const t = progress * 2;
        px = lerp(W / 2, p.sx, t);
        py = lerp(H / 2, p.sy, t);
      } else {
        // converge phase 0.5→1
        const t = (progress - 0.5) * 2;
        px = lerp(p.sx, p.tx, t);
        py = lerp(p.sy, p.ty, t);
      }

      ctx.beginPath();
      ctx.arc(px, py, p.r, 0, Math.PI * 2);
      const alpha = progress > 0.7 ? 0.3 + (progress - 0.7) / 0.3 * 0.5 : 0.3;
      ctx.fillStyle = progress > 0.5
        ? `rgba(255,61,0,${alpha})`
        : `rgba(245,245,240,${0.25})`;
      ctx.fill();
    });

    animId = requestAnimationFrame(draw);
  }

  draw();

  return {
    setProgress: (p) => { progress = Math.max(0, Math.min(1, p)); },
    stop: () => cancelAnimationFrame(animId)
  };
}

// Concentric orbit rings
function initOrbitRings(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H, animId;
  let progress = 0;
  let lastTime = 0;
  let rotationAccum = 0;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }

  resize();
  window.addEventListener('resize', resize);

  const rings = [
    { radius: 0.12, dots: 4, color: 'rgba(255,61,0,0.8)', size: 4 },
    { radius: 0.20, dots: 6, color: 'rgba(245,245,240,0.6)', size: 3 },
    { radius: 0.30, dots: 8, color: 'rgba(255,61,0,0.4)', size: 2.5 },
    { radius: 0.42, dots: 12, color: 'rgba(245,245,240,0.3)', size: 2 }
  ];

  function draw(ts) {
    const dt = ts - lastTime;
    lastTime = ts;

    const speed = 0.0004 + progress * 0.003;
    rotationAccum += dt * speed;

    ctx.clearRect(0, 0, W, H);
    const cx = W / 2, cy = H / 2;
    const minDim = Math.min(W, H);

    rings.forEach((ring, ri) => {
      const r = ring.radius * minDim;
      const dir = ri % 2 === 0 ? 1 : -1;
      const rotation = rotationAccum * dir * (1 + ri * 0.3);

      // ring track
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(245,245,240,0.04)`;
      ctx.lineWidth = 1;
      ctx.stroke();

      // dots
      for (let d = 0; d < ring.dots; d++) {
        const angle = rotation + (d / ring.dots) * Math.PI * 2;
        const dx = cx + Math.cos(angle) * r;
        const dy = cy + Math.sin(angle) * r;

        ctx.beginPath();
        ctx.arc(dx, dy, ring.size, 0, Math.PI * 2);
        ctx.fillStyle = ring.color;
        ctx.fill();

        // glow
        if (progress > 0.7) {
          ctx.beginPath();
          ctx.arc(dx, dy, ring.size * 2.5, 0, Math.PI * 2);
          ctx.fillStyle = ring.color.replace(/[\d.]+\)$/, `${(progress - 0.7) * 0.3})`);
          ctx.fill();
        }
      }
    });

    // alignment flash at progress=1
    if (progress > 0.95) {
      const flash = (progress - 0.95) / 0.05;
      ctx.beginPath();
      ctx.arc(cx, cy, minDim * 0.08, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,61,0,${flash * 0.6})`;
      ctx.fill();
    }

    animId = requestAnimationFrame(draw);
  }

  animId = requestAnimationFrame(draw);

  return {
    setProgress: (p) => { progress = Math.max(0, Math.min(1, p)); },
    stop: () => cancelAnimationFrame(animId)
  };
}
