/* ============================================
   TUTOR CHARACTER — tutor.js
   Animated cartoon tutor that walks across sections
   ============================================ */

(function() {
  const MESSAGES = {
    hero:        "Hi! I'm Zeno 👋 Let's learn together!",
    dotgrid:     "Every mentor here is hand-picked! 🌟",
    linedraw:    "Chart your path to success! 📈",
    particles:   "Learn anywhere, anytime! 🌍",
    orbit:       "Join 50K+ thriving learners! 🚀",
    stats:       "Real numbers, real results! 💯",
    courses:     "Find your perfect course! 🎓",
    testimonials:"They loved it — you will too! ❤️",
    cta:         "Ready to start? Let's go! ✨"
  };

  const POSITIONS = [
    { section: '.hero',           x: 8,   y: 12 },   // % from left, % from bottom
    { section: '.section-dotgrid', x: 5,  y: 15 },
    { section: '.section-linedraw', x: 65, y: 15 },
    { section: '.section-particles', x: 8, y: 15 },
    { section: '.section-orbit',  x: 65,  y: 15 },
    { section: '.stats-band',     x: 20,  y: 15 },
    { section: '.cards-section',  x: 65,  y: 12 },
    { section: '.testimonials',   x: 8,   y: 15 },
    { section: '.cta-section',    x: 45,  y: 10 }
  ];

  let currentSectionIdx = -1;
  let isWalking = false;
  let messageTimeout = null;

  function createTutor() {
    const el = document.createElement('div');
    el.id = 'tutor-character';
    el.innerHTML = `
      <div class="tutor-bubble" id="tutor-bubble"></div>
      <svg viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg" id="tutor-svg">
        <!-- Shadow -->
        <ellipse cx="50" cy="135" rx="22" ry="5" fill="rgba(0,0,0,0.10)"/>
        
        <!-- Body group (bobs up/down) -->
        <g id="tutor-body-group">
          <!-- Left Arm -->
          <g id="tutor-arm-l" transform="translate(28,62)">
            <line x1="0" y1="0" x2="-8" y2="18" stroke="#FF8A50" stroke-width="6" stroke-linecap="round"/>
            <!-- Hand -->
            <circle cx="-8" cy="20" r="5" fill="#FFDAB9"/>
          </g>
          
          <!-- Right Arm -->
          <g id="tutor-arm-r" transform="translate(72,62)">
            <line x1="0" y1="0" x2="8" y2="18" stroke="#FF8A50" stroke-width="6" stroke-linecap="round"/>
            <circle cx="8" cy="20" r="5" fill="#FFDAB9"/>
          </g>

          <!-- Torso -->
          <rect x="28" y="58" width="44" height="42" rx="12" fill="#FF6B35"/>
          <!-- Shirt detail -->
          <rect x="42" y="62" width="16" height="3" rx="1.5" fill="rgba(255,255,255,0.3)"/>
          <rect x="45" y="68" width="10" height="2" rx="1" fill="rgba(255,255,255,0.2)"/>
          <!-- Collar -->
          <path d="M42 58 L50 68 L58 58" stroke="white" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>

          <!-- Left Leg -->
          <g id="tutor-leg-l" transform="translate(36,98)">
            <rect x="-7" y="0" width="14" height="22" rx="6" fill="#3B4ED8"/>
            <!-- Shoe -->
            <ellipse cx="0" cy="23" rx="9" ry="6" fill="#1a1a2e"/>
          </g>

          <!-- Right Leg -->
          <g id="tutor-leg-r" transform="translate(64,98)">
            <rect x="-7" y="0" width="14" height="22" rx="6" fill="#3B4ED8"/>
            <ellipse cx="0" cy="23" rx="9" ry="6" fill="#1a1a2e"/>
          </g>

          <!-- Neck -->
          <rect x="43" y="50" width="14" height="12" rx="4" fill="#FFDAB9"/>

          <!-- Head -->
          <circle cx="50" cy="36" r="26" fill="#FFDAB9"/>
          
          <!-- Ears -->
          <circle cx="24" cy="36" r="7" fill="#FFDAB9"/>
          <circle cx="76" cy="36" r="7" fill="#FFDAB9"/>
          <circle cx="24" cy="36" r="4" fill="#FFB99A"/>
          <circle cx="76" cy="36" r="4" fill="#FFB99A"/>

          <!-- Hair -->
          <path d="M26 22 Q50 5 74 22 Q70 10 50 8 Q30 10 26 22Z" fill="#2D1B00"/>
          <path d="M24 26 Q22 18 28 14" stroke="#2D1B00" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M76 26 Q78 18 72 14" stroke="#2D1B00" stroke-width="4" fill="none" stroke-linecap="round"/>

          <!-- Eyes (happy/closed arc) -->
          <g id="tutor-eyes-open">
            <circle cx="40" cy="33" r="5.5" fill="white"/>
            <circle cx="60" cy="33" r="5.5" fill="white"/>
            <circle cx="41" cy="34" r="3" fill="#2D1B00"/>
            <circle cx="61" cy="34" r="3" fill="#2D1B00"/>
            <!-- Pupils shine -->
            <circle cx="42.5" cy="32.5" r="1" fill="white"/>
            <circle cx="62.5" cy="32.5" r="1" fill="white"/>
          </g>
          <!-- Blink (hidden by default) -->
          <g id="tutor-eyes-blink" style="display:none">
            <path d="M35 33 Q40 29 45 33" stroke="#2D1B00" stroke-width="2" fill="none" stroke-linecap="round"/>
            <path d="M55 33 Q60 29 65 33" stroke="#2D1B00" stroke-width="2" fill="none" stroke-linecap="round"/>
          </g>

          <!-- Nose -->
          <ellipse cx="50" cy="40" rx="3" ry="2" fill="#FFB99A"/>

          <!-- Smile -->
          <path id="tutor-mouth" d="M42 46 Q50 53 58 46" stroke="#2D1B00" stroke-width="2.5" fill="none" stroke-linecap="round"/>

          <!-- Graduation cap -->
          <rect x="30" y="12" width="40" height="6" rx="2" fill="#2D1B00"/>
          <rect x="44" y="6" width="12" height="8" rx="2" fill="#2D1B00"/>
          <!-- Tassel -->
          <line x1="70" y1="15" x2="76" y2="26" stroke="#FF6B35" stroke-width="1.5"/>
          <circle cx="76" cy="27" r="2.5" fill="#FF6B35"/>
        </g>
      </svg>
    `;
    document.body.appendChild(el);
    return el;
  }

  function showBubble(text) {
    const bubble = document.getElementById('tutor-bubble');
    const el = document.getElementById('tutor-character');
    if (!bubble || !el) return;
    bubble.textContent = text;
    clearTimeout(messageTimeout);
    el.classList.add('talking');
    messageTimeout = setTimeout(() => el.classList.remove('talking'), 3500);
  }

  function blinkEyes() {
    const open = document.getElementById('tutor-eyes-open');
    const blink = document.getElementById('tutor-eyes-blink');
    if (!open || !blink) return;
    open.style.display = 'none';
    blink.style.display = 'block';
    setTimeout(() => {
      open.style.display = 'block';
      blink.style.display = 'none';
    }, 150);
  }

  function moveTutor(xPercent, yPercent, message, facingRight) {
    const el = document.getElementById('tutor-character');
    if (!el) return;

    el.classList.remove('tutor-idle');
    el.classList.add('tutor-walking');

    const viewW = window.innerWidth;
    const viewH = window.innerHeight;
    const newLeft = (viewW * xPercent / 100) + 'px';
    const newBottom = (yPercent) + 'vh';

    el.style.left = newLeft;
    el.style.bottom = newBottom;

    // Flip direction
    const svg = el.querySelector('#tutor-svg');
    if (svg) svg.style.transform = facingRight ? 'scaleX(1)' : 'scaleX(-1)';

    setTimeout(() => {
      el.classList.remove('tutor-walking');
      el.classList.add('tutor-idle');
      if (message) showBubble(message);
      blinkEyes();
    }, 900);
  }

  function checkSection() {
    const scrollY = window.scrollY;
    const viewH = window.innerHeight;

    POSITIONS.forEach((pos, idx) => {
      const section = document.querySelector(pos.section);
      if (!section) return;
      const rect = section.getBoundingClientRect();
      const inView = rect.top < viewH * 0.6 && rect.bottom > viewH * 0.4;

      if (inView && currentSectionIdx !== idx) {
        currentSectionIdx = idx;
        const sectionKey = pos.section.replace('.section-', '').replace('.', '');
        const msg = MESSAGES[sectionKey] || null;
        const facingRight = pos.x < 50;
        moveTutor(pos.x, pos.y, msg, facingRight);
      }
    });
  }

  window.addEventListener('scroll', () => {
    requestAnimationFrame(checkSection);
  });

  // Init
  document.addEventListener('DOMContentLoaded', () => {
    createTutor();
    checkSection();

    // Random blinks
    setInterval(blinkEyes, 3000 + Math.random() * 2000);

    // Wave on page load
    setTimeout(() => {
      const el = document.getElementById('tutor-character');
      if (el) {
        moveTutor(8, 12, MESSAGES.hero, true);
      }
    }, 1200);
  });
})();
