/* ============================================
   LEARNOVA ACADEMY — ANIMATIONS.JS
   GSAP ScrollTrigger + anime.js
   ============================================ */

gsap.registerPlugin(ScrollTrigger);

/* ======= NAVBAR SCROLL ======= */
function initNavbar() {
  const nav = document.querySelector('nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });

  // Mobile toggle
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => links.classList.toggle('open'));
  }
}

/* ======= CUSTOM CURSOR ======= */
function initCursor() {
  const cursor = document.querySelector('.cursor');
  const ring = document.querySelector('.cursor-ring');
  if (!cursor || !ring) return;
  let mx = -100, my = -100, rx = -100, ry = -100;

  window.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cursor.style.left = mx + 'px';
    cursor.style.top = my + 'px';
  });

  function animateRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top = ry + 'px';
    requestAnimationFrame(animateRing);
  }
  animateRing();

  document.querySelectorAll('a, button, .course-card, .testi-card').forEach(el => {
    el.addEventListener('mouseenter', () => ring.classList.add('hovering'));
    el.addEventListener('mouseleave', () => ring.classList.remove('hovering'));
  });
}

/* ======= HERO CANVAS ======= */
function initHeroCanvas() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const particles = [];

  function resize() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  for (let i = 0; i < 100; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() * 1.2 + 0.5
    });
  }

  let mx = -999, my = -999;
  canvas.addEventListener('mousemove', e => {
    const r = canvas.getBoundingClientRect();
    mx = e.clientX - r.left;
    my = e.clientY - r.top;
  });

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p, i) => {
      // Repel from mouse
      const dx0 = p.x - mx, dy0 = p.y - my;
      const d0 = Math.sqrt(dx0*dx0 + dy0*dy0);
      if (d0 < 80) {
        const force = (80 - d0) / 80 * 0.3;
        p.vx += (dx0 / d0) * force;
        p.vy += (dy0 / d0) * force;
      }
      p.vx *= 0.98; p.vy *= 0.98;
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(13,13,13,0.35)';
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const dx = p.x - particles[j].x, dy = p.y - particles[j].y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(13,13,13,${(1 - dist/120) * 0.07})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });
    requestAnimationFrame(draw);
  }
  draw();
}

/* ======= HERO TEXT ENTRANCE ======= */
function initHeroEntrance() {
  const h1 = document.querySelector('.hero-h1');
  if (!h1) return;

  // Wrap each word
  h1.innerHTML = h1.textContent.trim().split(' ').map(w =>
    `<span class="word-wrap"><span class="word">${w}</span></span>`
  ).join(' ');

  const words = h1.querySelectorAll('.word');
  const sub = document.querySelector('.hero-sub');
  const actions = document.querySelector('.hero-actions');

  anime({
    targets: words,
    translateY: ['110%', '0%'],
    opacity: [0, 1],
    duration: 700,
    delay: anime.stagger(80),
    easing: 'cubicBezier(0.16, 1, 0.3, 1)'
  });

  if (sub) anime({ targets: sub, opacity: [0,1], translateY: [20,0], duration: 700, delay: 400, easing: 'cubicBezier(0.16,1,0.3,1)' });
  if (actions) anime({ targets: actions, opacity: [0,1], translateY: [20,0], duration: 700, delay: 600, easing: 'cubicBezier(0.16,1,0.3,1)' });
}

/* ======= PINNED SECTION 1: DOT GRID ======= */
function initDotGrid() {
  const section = document.querySelector('.section-dotgrid');
  if (!section) return;
  const dots = section.querySelectorAll('.dot-grid-item');
  const content = section.querySelector('.pinned-content');

  // Sort dots by distance from center
  const center = Math.floor(dots.length / 2);
  const sortedDots = Array.from(dots).sort((a, b) => {
    const ai = parseInt(a.dataset.idx), bi = parseInt(b.dataset.idx);
    const rows = 8;
    const ax = ai % rows, ay = Math.floor(ai / rows);
    const bx = bi % rows, by = Math.floor(bi / rows);
    const da = Math.sqrt((ax-3.5)**2 + (ay-3.5)**2);
    const db = Math.sqrt((bx-3.5)**2 + (by-3.5)**2);
    return da - db;
  });

  ScrollTrigger.create({
    trigger: section,
    start: 'top top',
    end: '+=200%',
    pin: true,
    scrub: 1,
    onUpdate: self => {
      const p = self.progress;
      sortedDots.forEach((dot, i) => {
        const delay = i / sortedDots.length * 0.5;
        const local = Math.max(0, Math.min(1, (p - delay) / 0.5));
        dot.style.transform = `scale(${1 + local * 1.5})`;
        dot.style.opacity = 0.1 + local * 0.85;
        dot.style.background = `rgba(${lerp(13,255,local)},${lerp(13,107,local)},${lerp(13,53,local)},${0.12 + local * 0.88})`;
      });
      if (content && p > 0.2) {
        content.classList.add('visible');
      } else if (content && p <= 0.2) {
        content.classList.remove('visible');
      }
    }
  });
}

/* ======= PINNED SECTION 2: SVG LINE DRAW ======= */
function initLineDrawSection() {
  const section = document.querySelector('.section-linedraw');
  if (!section) return;
  const paths = section.querySelectorAll('.draw-path');
  const circles = section.querySelectorAll('.travel-circle');
  const content = section.querySelector('.pinned-content');

  paths.forEach(path => {
    const len = path.getTotalLength();
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    path.dataset.len = len;
  });

  ScrollTrigger.create({
    trigger: section,
    start: 'top top',
    end: '+=200%',
    pin: true,
    scrub: 1,
    onUpdate: self => {
      const p = self.progress;
      paths.forEach((path, i) => {
        const len = parseFloat(path.dataset.len);
        const delay = i * 0.15;
        const local = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
        path.style.strokeDashoffset = len * (1 - local);

        if (circles[i]) {
          const pt = path.getPointAtLength(local * len);
          circles[i].setAttribute('cx', pt.x);
          circles[i].setAttribute('cy', pt.y);
          circles[i].style.opacity = local;
        }
      });
      if (content && p > 0.3) content.classList.add('visible');
      else if (content) content.classList.remove('visible');
    }
  });
}

/* ======= PINNED SECTION 3: PARTICLE CANVAS ======= */
function initParticleSection() {
  const section = document.querySelector('.section-particles');
  if (!section) return;
  const canvas = section.querySelector('.pinned-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const content = section.querySelector('.pinned-content');
  const COUNT = 200;
  let W, H;
  const particles = [];
  let progress = 0;

  function resize() {
    W = canvas.width = section.offsetWidth;
    H = canvas.height = section.offsetHeight;
    initParticles();
  }

  function initParticles() {
    particles.length = 0;
    const CX = W / 2, CY = H / 2;
    const R = Math.min(W, H) * 0.22;
    for (let i = 0; i < COUNT; i++) {
      const angle = (i / COUNT) * Math.PI * 2;
      particles.push({
        cx: CX + Math.cos(angle) * R,
        cy: CY + Math.sin(angle) * R,
        sx: Math.random() * W,
        sy: Math.random() * H,
        x: 0, y: 0,
        r: Math.random() * 2 + 1,
        hue: Math.random() * 40 + 15
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const p = progress;
    particles.forEach(pt => {
      let tx, ty;
      if (p < 0.5) {
        const local = p * 2;
        tx = pt.sx + (pt.cx + (Math.random() - 0.5) * 300 - pt.sx) * local;
        ty = pt.sy + (pt.cy + (Math.random() - 0.5) * 300 - pt.sy) * local;
      } else {
        const local = (p - 0.5) * 2;
        const ex = pt.cx + (Math.random() - 0.5) * 300;
        const ey = pt.cy + (Math.random() - 0.5) * 300;
        tx = ex + (pt.cx - ex) * local;
        ty = ey + (pt.cy - ey) * local;
      }
      pt.x += (tx - pt.x) * 0.18;
      pt.y += (ty - pt.y) * 0.18;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.r, 0, Math.PI * 2);
      const alpha = p > 0.4 && p < 0.6 ? 0.4 : 0.7;
      ctx.fillStyle = `hsla(${pt.hue}, 80%, 55%, ${alpha})`;
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  draw();

  ScrollTrigger.create({
    trigger: section,
    start: 'top top',
    end: '+=200%',
    pin: true,
    scrub: 1,
    onUpdate: self => {
      progress = self.progress;
      if (content && progress > 0.35) content.classList.add('visible');
      else if (content) content.classList.remove('visible');
    }
  });
}

/* ======= PINNED SECTION 4: ORBIT RINGS ======= */
function initOrbitSection() {
  const section = document.querySelector('.section-orbit');
  if (!section) return;
  const rings = section.querySelectorAll('.orbit-ring');
  const orbitDots = section.querySelectorAll('.orbit-dot');
  const content = section.querySelector('.pinned-content');
  let rotation = [0, 0, 0, 0];

  ScrollTrigger.create({
    trigger: section,
    start: 'top top',
    end: '+=200%',
    pin: true,
    scrub: 1,
    onUpdate: self => {
      const p = self.progress;
      rings.forEach((ring, i) => {
        const speed = (i + 1) * 360 * p;
        const dir = i % 2 === 0 ? 1 : -1;
        ring.style.transform = `rotate(${speed * dir}deg)`;
      });
      orbitDots.forEach((dot, i) => {
        const ringIdx = parseInt(dot.dataset.ring);
        const speed = (ringIdx + 1) * 360 * p;
        const dir = ringIdx % 2 === 0 ? 1 : -1;
        const baseAngle = (i / orbitDots.length) * 360;
      });
      if (content && p > 0.2) content.classList.add('visible');
      else if (content) content.classList.remove('visible');
    }
  });
}

/* ======= STATS COUNT-UP ======= */
function initStats() {
  const stats = document.querySelectorAll('.stat-val');
  if (!stats.length) return;

  stats.forEach(el => {
    const target = parseFloat(el.dataset.target);
    let animated = false;

    ScrollTrigger.create({
      trigger: el,
      start: 'top 80%',
      onEnter: () => {
        if (animated) return;
        animated = true;
        anime({
          targets: el,
          innerHTML: [0, target],
          round: target >= 10 ? 1 : 10,
          duration: 1800,
          delay: parseInt(el.dataset.delay || 0),
          easing: 'cubicBezier(0.16, 1, 0.3, 1)',
          update: function(anim) {
            const val = parseFloat(el.innerHTML);
            if (target >= 1000) el.innerHTML = Math.round(val).toLocaleString();
          }
        });
      }
    });
  });
}

/* ======= HORIZONTAL CARD DRAG ======= */
function initCardDrag() {
  const scroll = document.querySelector('.cards-scroll');
  if (!scroll) return;
  let isDown = false, startX, scrollLeft;

  scroll.addEventListener('mousedown', e => {
    isDown = true;
    scroll.style.cursor = 'grabbing';
    startX = e.pageX - scroll.offsetLeft;
    scrollLeft = scroll.scrollLeft;
  });
  scroll.addEventListener('mouseleave', () => { isDown = false; scroll.style.cursor = 'grab'; });
  scroll.addEventListener('mouseup', () => { isDown = false; scroll.style.cursor = 'grab'; });
  scroll.addEventListener('mousemove', e => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - scroll.offsetLeft;
    scroll.scrollLeft = scrollLeft - (x - startX) * 1.5;
  });
}

/* ======= SCROLL REVEAL (non-pinned) ======= */
function initScrollReveal() {
  const els = document.querySelectorAll('.reveal');
  els.forEach(el => {
    gsap.fromTo(el,
      { opacity: 0, y: 30 },
      {
        opacity: 1, y: 0, duration: 0.8,
        ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 82%', once: true }
      }
    );
  });
}

/* ======= MARQUEE PAUSE ON HOVER ======= */
function initMarquee() {
  const track = document.querySelector('.marquee-track');
  if (!track) return;
  track.addEventListener('mouseenter', () => track.style.animationPlayState = 'paused');
  track.addEventListener('mouseleave', () => track.style.animationPlayState = 'running');
}

/* ======= MOBILE PINNED → NORMAL ======= */
function initMobileScrollTrigger() {
  ScrollTrigger.matchMedia({
    '(max-width: 768px)': function() {
      ScrollTrigger.getAll().forEach(t => {
        if (t.pin) t.disable();
      });
    }
  });
}

/* ======= UTILITY ======= */
function lerp(a, b, t) { return a + (b - a) * t; }

/* ======= INIT ALL ======= */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initCursor();
  initHeroCanvas();
  initHeroEntrance();
  initDotGrid();
  initLineDrawSection();
  initParticleSection();
  initOrbitSection();
  initStats();
  initCardDrag();
  initScrollReveal();
  initMarquee();
});
