/* ============================================
   NOVA CHARACTER SYSTEM
   Scroll-driven mascot that travels the page
   ============================================ */

class NovaCharacter {
  constructor() {
    this.wrapper = document.getElementById('nova-wrapper');
    if (!this.wrapper) return;

    this.bubble = this.wrapper.querySelector('.nova-bubble');
    this.currentX = window.innerWidth / 2;
    this.currentY = window.innerHeight / 2;
    this.targetX = this.currentX;
    this.targetY = this.currentY;
    this.currentRotation = 0;
    this.targetRotation = 0;
    this.scaleX = 1; // for flip direction

    this.sections = [];
    this.messages = {
      hero: '👋 Welcome to Vintar!',
      categories: '📚 Pick a category!',
      feature1: '🎓 Learn from the best!',
      feature2: '🚀 Build your career!',
      feature3: '📱 Study anywhere!',
      feature4: '🌍 Real-world skills!',
      stats: '🏆 Amazing results!',
      courses: '✨ Great courses!',
      mentors: '👩‍🏫 Meet our mentors!',
      testimonials: '💬 Hear their stories!',
      cta: '🎉 Let\'s go!'
    };

    this.currentMsg = '';
    this.setupSections();
    this.bindScroll();
    this.animate();
  }

  setupSections() {
    // Map section IDs to nova waypoints
    const sectionDefs = [
      { id: 'hero',         msg: 'hero',         x: 0.75, y: 0.5, rot: 0 },
      { id: 'categories',   msg: 'categories',   x: 0.15, y: 0.5, rot: 5 },
      { id: 'feature-1',    msg: 'feature1',     x: 0.85, y: 0.3, rot: -5 },
      { id: 'feature-2',    msg: 'feature2',     x: 0.12, y: 0.6, rot: 8 },
      { id: 'feature-3',    msg: 'feature3',     x: 0.8,  y: 0.7, rot: -8 },
      { id: 'feature-4',    msg: 'feature4',     x: 0.15, y: 0.4, rot: 3 },
      { id: 'stats',        msg: 'stats',         x: 0.5,  y: 0.2, rot: 0 },
      { id: 'courses-section', msg: 'courses',   x: 0.88, y: 0.5, rot: -6 },
      { id: 'mentors-section', msg: 'mentors',   x: 0.1,  y: 0.6, rot: 5 },
      { id: 'testimonials', msg: 'testimonials', x: 0.8,  y: 0.4, rot: -4 },
      { id: 'cta',          msg: 'cta',           x: 0.5,  y: 0.5, rot: 0 },
    ];

    sectionDefs.forEach(def => {
      const el = document.getElementById(def.id);
      if (el) {
        this.sections.push({ el, ...def });
      }
    });
  }

  getActiveSection() {
    const scrollY = window.scrollY;
    const vh = window.innerHeight;
    let best = null;
    let bestScore = -Infinity;

    this.sections.forEach(sec => {
      const rect = sec.el.getBoundingClientRect();
      const center = rect.top + rect.height / 2;
      const distFromMid = Math.abs(center - vh / 2);
      const score = -distFromMid;
      if (score > bestScore) {
        bestScore = score;
        best = sec;
      }
    });

    return best;
  }

  bindScroll() {
    window.addEventListener('scroll', () => {
      const active = this.getActiveSection();
      if (!active) return;

      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // Lerp target towards section waypoint
      this.targetX = vw * active.x;
      this.targetY = vh * active.y;
      this.targetRotation = active.rot;

      // Flip nova based on direction
      if (this.targetX > vw / 2) {
        this.scaleX = 1;
      } else {
        this.scaleX = -1;
      }

      // Update speech bubble
      if (this.messages[active.msg] !== this.currentMsg) {
        this.currentMsg = this.messages[active.msg];
        if (this.bubble) {
          this.bubble.textContent = this.currentMsg;
        }
      }

      // Temporarily show bubble
      if (this.bubble) {
        this.bubble.style.opacity = '1';
        clearTimeout(this._bubbleTimer);
        this._bubbleTimer = setTimeout(() => {
          if (this.bubble) this.bubble.style.opacity = '0';
        }, 2000);
      }
    }, { passive: true });
  }

  animate() {
    const lerpFactor = 0.06;

    // Smooth lerp towards target
    this.currentX += (this.targetX - this.currentX) * lerpFactor;
    this.currentY += (this.targetY - this.currentY) * lerpFactor;
    this.currentRotation += (this.targetRotation - this.currentRotation) * lerpFactor;

    if (this.wrapper) {
      this.wrapper.style.left = `${this.currentX}px`;
      this.wrapper.style.top = `${this.currentY}px`;
      this.wrapper.style.transform = `translate(-50%, -50%) rotate(${this.currentRotation}deg) scaleX(${this.scaleX})`;
    }

    requestAnimationFrame(() => this.animate());
  }
}

// Init Nova when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window._nova = new NovaCharacter();
});
