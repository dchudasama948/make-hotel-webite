/* ============================================
   ANIMATIONS.JS — VINTAR ACADEMY
   GSAP ScrollTrigger + anime.js
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ========= CUSTOM CURSOR ========= */
  const cursor = document.getElementById('cursor');
  const ring = document.getElementById('cursor-ring');
  if (cursor && ring) {
    let mx = 0, my = 0, rx = 0, ry = 0;
    window.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });
    (function moveCursor() {
      rx += (mx - rx) * 0.12;
      ry += (my - ry) * 0.12;
      if (cursor) { cursor.style.left = mx + 'px'; cursor.style.top = my + 'px'; }
      if (ring) { ring.style.left = rx + 'px'; ring.style.top = ry + 'px'; }
      requestAnimationFrame(moveCursor);
    })();
    document.querySelectorAll('a, button, [data-cursor]').forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.style.width = '20px'; cursor.style.height = '20px';
        ring.style.width = '60px'; ring.style.height = '60px';
        ring.style.borderColor = 'var(--accent)';
      });
      el.addEventListener('mouseleave', () => {
        cursor.style.width = '12px'; cursor.style.height = '12px';
        ring.style.width = '40px'; ring.style.height = '40px';
        ring.style.borderColor = 'var(--accent)';
      });
    });
  }

  /* ========= NAVBAR ========= */
  const nav = document.querySelector('nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  /* ========= HAMBURGER ========= */
  const hamburger = document.querySelector('.hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
      const spans = hamburger.querySelectorAll('span');
      if (mobileMenu.classList.contains('open')) {
        spans[0].style.transform = 'rotate(45deg) translate(5px,5px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(5px,-5px)';
      } else {
        spans[0].style.transform = '';
        spans[1].style.opacity = '';
        spans[2].style.transform = '';
      }
    });
    mobileMenu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => mobileMenu.classList.remove('open'));
    });
  }

  /* ========= HERO ENTRANCE ========= */
  const heroWords = document.querySelectorAll('.hero-title .word span');
  if (heroWords.length) {
    anime({
      targets: heroWords,
      translateY: [110, 0],
      opacity: [0, 1],
      easing: 'cubicBezier(0.16, 1, 0.3, 1)',
      duration: 900,
      delay: anime.stagger(80, { start: 300 })
    });
    anime({
      targets: ['.hero-sub', '.hero-btns', '.hero-stats'],
      translateY: [20, 0],
      opacity: [0, 1],
      easing: 'cubicBezier(0.16, 1, 0.3, 1)',
      duration: 700,
      delay: anime.stagger(120, { start: 700 })
    });
  }

  /* ========= GSAP SETUP ========= */
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  gsap.registerPlugin(ScrollTrigger);

  // Helper: create pinned scroll section
  function createPinnedSection(sectionEl, onProgress, extraConfig = {}) {
    if (!sectionEl) return;
    const proxy = { progress: 0 };
    gsap.to(proxy, {
      progress: 1,
      ease: 'none',
      scrollTrigger: {
        trigger: sectionEl,
        start: 'top top',
        end: '+=220%',
        pin: true,
        scrub: 1.2,
        onUpdate: self => onProgress(self.progress),
        ...extraConfig
      }
    });
  }

  /* -------- FEATURE 1: Dot Grid -------- */
  (function() {
    const section = document.getElementById('feature-1');
    if (!section) return;
    const dots = section.querySelectorAll('.dot-grid-dot');
    const content = section.querySelector('.pinned-content');
    const fill = section.querySelector('.progress-fill');

    // Pre-sort dots by distance from center
    const centerIdx = 31.5;
    const sorted = Array.from(dots).map((d, i) => {
      const row = Math.floor(i / 8);
      const col = i % 8;
      const dr = Math.abs(row - 3.5);
      const dc = Math.abs(col - 3.5);
      return { el: d, dist: Math.sqrt(dr*dr + dc*dc) };
    }).sort((a, b) => a.dist - b.dist);

    createPinnedSection(section, p => {
      if (fill) fill.style.width = (p * 100) + '%';
      if (content && p > 0.2 && !content.classList.contains('visible')) {
        content.classList.add('visible');
      }
      if (content && p < 0.05 && content.classList.contains('visible')) {
        content.classList.remove('visible');
      }
      // Animate dots outward from center
      sorted.forEach(({ el, dist }, i) => {
        const maxDist = sorted[sorted.length - 1].dist;
        const delay = dist / maxDist * 0.6;
        const localP = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
        const scale = 1 + localP * 1.8;
        const alpha = 0.08 + localP * 0.92;
        const hue = 210 + localP * 20;
        el.style.transform = `scale(${scale})`;
        el.style.background = `hsla(${hue}, 85%, 60%, ${alpha})`;
        el.style.boxShadow = localP > 0.5 ? `0 0 ${localP * 12}px hsla(${hue}, 85%, 60%, 0.4)` : 'none';
      });
    });
  })();

  /* -------- FEATURE 2: SVG Line Draw -------- */
  (function() {
    const section = document.getElementById('feature-2');
    if (!section) return;
    const paths = section.querySelectorAll('.draw-path');
    const travelers = section.querySelectorAll('.path-traveler');
    const content = section.querySelector('.pinned-content');
    const fill = section.querySelector('.progress-fill');

    // Setup dashes
    const pathLengths = [];
    paths.forEach(path => {
      const len = path.getTotalLength ? path.getTotalLength() : 400;
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = len;
      pathLengths.push(len);
    });

    createPinnedSection(section, p => {
      if (fill) fill.style.width = (p * 100) + '%';
      if (content && p > 0.3 && !content.classList.contains('visible')) {
        content.classList.add('visible');
      }
      if (content && p < 0.05 && content.classList.contains('visible')) {
        content.classList.remove('visible');
      }
      paths.forEach((path, i) => {
        const delay = i * 0.15;
        const localP = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
        path.style.strokeDashoffset = pathLengths[i] * (1 - localP);
        path.style.opacity = 0.3 + localP * 0.7;
      });

      // Travelers along path
      travelers.forEach((t, i) => {
        if (paths[i] && paths[i].getTotalLength) {
          const len = paths[i].getTotalLength();
          const delay = i * 0.15;
          const localP = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
          const pos = paths[i].getPointAtLength(localP * len);
          t.style.transform = `translate(${pos.x - 6}px, ${pos.y - 6}px)`;
          t.style.opacity = localP > 0.1 ? '1' : '0';
        }
      });
    });
  })();

  /* -------- FEATURE 3: Particle Scatter/Form -------- */
  (function() {
    const section = document.getElementById('feature-3');
    if (!section) return;
    const canvas = section.querySelector('canvas');
    if (!canvas) return;
    const content = section.querySelector('.pinned-content');
    const fill = section.querySelector('.progress-fill');

    const particleSys = initScatterParticles(canvas.id || 'scatter-canvas');

    createPinnedSection(section, p => {
      if (fill) fill.style.width = (p * 100) + '%';
      if (particleSys) particleSys.setProgress(p);
      if (content && p > 0.55 && !content.classList.contains('visible')) {
        content.classList.add('visible');
      }
      if (content && p < 0.05 && content.classList.contains('visible')) {
        content.classList.remove('visible');
      }
    });
  })();

  /* -------- FEATURE 4: Orbit Rings -------- */
  (function() {
    const section = document.getElementById('feature-4');
    if (!section) return;
    const rings = section.querySelectorAll('.orbit-ring');
    const orbitDots = section.querySelectorAll('.orbit-dot');
    const content = section.querySelector('.pinned-content');
    const fill = section.querySelector('.progress-fill');

    let baseRotations = [0, 45, 90, 135]; // starting angles per ring

    createPinnedSection(section, p => {
      if (fill) fill.style.width = (p * 100) + '%';
      if (content && p > 0.2 && !content.classList.contains('visible')) {
        content.classList.add('visible');
      }
      if (content && p < 0.05 && content.classList.contains('visible')) {
        content.classList.remove('visible');
      }

      rings.forEach((ring, i) => {
        const speed = (i + 1) * 2.5;
        const rotation = baseRotations[i] + p * speed * 360;
        ring.style.transform = `rotate(${rotation}deg)`;
        // Scale rings in
        const scaleP = Math.min(1, p * 3);
        const scale = 0.3 + scaleP * 0.7;
        ring.style.opacity = scaleP;
        ring.style.setProperty('--ring-scale', scale);
      });

      // Flash alignment at p=1
      if (p > 0.95) {
        rings.forEach(ring => {
          ring.style.boxShadow = `0 0 ${(p - 0.95) * 400}px var(--accent-glow)`;
        });
      } else {
        rings.forEach(ring => ring.style.boxShadow = '');
      }
    });
  })();

  /* ========= STATS COUNT-UP ========= */
  (function() {
    const stats = document.querySelectorAll('[data-count]');
    if (!stats.length) return;

    ScrollTrigger.create({
      trigger: '#stats',
      start: 'top 80%',
      once: true,
      onEnter: () => {
        stats.forEach((el, i) => {
          const target = parseInt(el.dataset.count);
          anime({
            targets: el,
            innerHTML: [0, target],
            round: 1,
            easing: 'easeOutExpo',
            duration: 2200,
            delay: i * 150,
            update: a => { el.innerHTML = Math.round(a.animations[0].currentValue).toLocaleString(); }
          });
        });
      }
    });
  })();

  /* ========= SCROLL REVEALS ========= */
  document.querySelectorAll('.reveal').forEach(el => {
    ScrollTrigger.create({
      trigger: el,
      start: 'top 88%',
      onEnter: () => el.classList.add('visible'),
      onLeaveBack: () => el.classList.remove('visible')
    });
  });

  /* ========= CATEGORIES FAN ========= */
  (function() {
    const cats = document.querySelectorAll('.cat-card');
    if (!cats.length) return;
    ScrollTrigger.create({
      trigger: '#categories',
      start: 'top 75%',
      once: true,
      onEnter: () => {
        anime({
          targets: cats,
          translateY: [40, 0],
          opacity: [0, 1],
          rotateZ: [(i) => (i - 2) * 3, 0],
          easing: 'cubicBezier(0.16, 1, 0.3, 1)',
          duration: 800,
          delay: anime.stagger(60)
        });
      }
    });
  })();

  /* ========= HOW STEPS ========= */
  (function() {
    const steps = document.querySelectorAll('.how-step');
    if (!steps.length) return;
    ScrollTrigger.create({
      trigger: '#how',
      start: 'top 75%',
      once: true,
      onEnter: () => {
        anime({
          targets: steps,
          translateY: [50, 0],
          opacity: [0, 1],
          easing: 'cubicBezier(0.16, 1, 0.3, 1)',
          duration: 700,
          delay: anime.stagger(100)
        });
      }
    });
  })();

  /* ========= TESTIMONIALS ========= */
  (function() {
    const cards = document.querySelectorAll('.testi-card');
    if (!cards.length) return;
    ScrollTrigger.create({
      trigger: '#testimonials',
      start: 'top 80%',
      once: true,
      onEnter: () => {
        anime({
          targets: cards,
          translateY: [30, 0],
          opacity: [0, 1],
          easing: 'cubicBezier(0.16, 1, 0.3, 1)',
          duration: 600,
          delay: anime.stagger(80)
        });
      }
    });
  })();

  /* ========= COURSES DRAG SCROLL ========= */
  (function() {
    const track = document.querySelector('.courses-track');
    if (!track) return;
    let isDown = false, startX, scrollLeft;
    track.addEventListener('mousedown', e => {
      isDown = true; track.classList.add('active');
      startX = e.pageX - track.offsetLeft;
      scrollLeft = track.scrollLeft || track.parentElement.scrollLeft;
    });
    track.addEventListener('mouseleave', () => { isDown = false; track.classList.remove('active'); });
    track.addEventListener('mouseup', () => { isDown = false; track.classList.remove('active'); });
    track.addEventListener('mousemove', e => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - track.offsetLeft;
      const walk = (x - startX) * 1.5;
      track.parentElement.scrollLeft = scrollLeft - walk;
    });
  })();

  /* ========= CTA BUTTON HOVER PARTICLES ========= */
  (function() {
    const btn = document.querySelector('#cta .btn-primary');
    if (!btn) return;
    btn.addEventListener('mouseenter', () => {
      // Small burst effect
      const rect = btn.getBoundingClientRect();
      for (let i = 0; i < 8; i++) {
        const spark = document.createElement('div');
        spark.style.cssText = `
          position:fixed; width:4px; height:4px; border-radius:50%;
          background:var(--accent); pointer-events:none; z-index:9997;
          left:${rect.left + rect.width/2}px; top:${rect.top + rect.height/2}px;
        `;
        document.body.appendChild(spark);
        const angle = (i / 8) * Math.PI * 2;
        anime({
          targets: spark,
          translateX: Math.cos(angle) * 50,
          translateY: Math.sin(angle) * 50,
          opacity: [1, 0],
          scale: [1, 0],
          duration: 600,
          easing: 'easeOutExpo',
          complete: () => spark.remove()
        });
      }
    });
  })();

  /* ========= MOBILE: disable pins ========= */
  ScrollTrigger.matchMedia({
    '(max-width: 768px)': function() {
      ScrollTrigger.getAll().forEach(st => {
        if (st.pin) { st.kill(); }
      });
    }
  });

  /* ========= MARQUEE hover pause ========= */
  const marqueeTrack = document.querySelector('.marquee-track');
  if (marqueeTrack) {
    marqueeTrack.parentElement.addEventListener('mouseenter', () => {
      marqueeTrack.style.animationPlayState = 'paused';
    });
    marqueeTrack.parentElement.addEventListener('mouseleave', () => {
      marqueeTrack.style.animationPlayState = 'running';
    });
  }

  /* ========= CONTACT FORM VALIDATION ========= */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;

      const fields = contactForm.querySelectorAll('[required]');
      fields.forEach(field => {
        const err = field.parentElement.querySelector('.form-error');
        if (!field.value.trim()) {
          if (err) { err.style.display = 'block'; err.textContent = 'This field is required.'; }
          field.style.borderColor = '#ef4444';
          valid = false;
        } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
          if (err) { err.style.display = 'block'; err.textContent = 'Please enter a valid email.'; }
          field.style.borderColor = '#ef4444';
          valid = false;
        } else {
          if (err) err.style.display = 'none';
          field.style.borderColor = '';
        }
      });

      if (valid) {
        const success = document.querySelector('.form-success');
        if (success) {
          success.style.display = 'block';
          anime({ targets: success, opacity: [0,1], translateY: [10,0], duration: 400, easing: 'easeOutExpo' });
        }
        contactForm.reset();
      }
    });
  }

});
