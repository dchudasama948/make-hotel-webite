/* ============================================
   PARTICLE SYSTEMS — VINTAR ACADEMY
   ============================================ */

/* ---- HERO PARTICLE CONSTELLATION ---- */
function initHeroParticles(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let particles = [];
  let mouse = { x: -999, y: -999 };
  let animId;

  function resize() {
    canvas.width = canvas.offsetWidth || window.innerWidth;
    canvas.height = canvas.offsetHeight || window.innerHeight;
    createParticles();
  }

  function createParticles() {
    particles = [];
    const count = Math.min(110, Math.floor((canvas.width * canvas.height) / 8000));
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.2 + 0.5,
        ox: 0, oy: 0  // repel offset
      });
    }
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Update positions
    particles.forEach(p => {
      // Mouse repel
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 100) {
        const force = (100 - dist) / 100;
        p.ox += dx / dist * force * 1.5;
        p.oy += dy / dist * force * 1.5;
      }
      p.ox *= 0.92;
      p.oy *= 0.92;

      p.x += p.vx + p.ox * 0.1;
      p.y += p.vy + p.oy * 0.1;

      if (p.x < 0) p.x = canvas.width;
      if (p.x > canvas.width) p.x = 0;
      if (p.y < 0) p.y = canvas.height;
      if (p.y > canvas.height) p.y = 0;
    });

    // Draw connections
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const dx = p.x - q.x;
        const dy = p.y - q.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 130) {
          const alpha = (1 - dist / 130) * 0.08;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(79, 142, 247, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }
      // Draw dot
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(79, 142, 247, 0.4)`;
      ctx.fill();
    }

    animId = requestAnimationFrame(draw);
  }

  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  canvas.addEventListener('mouseleave', () => { mouse.x = -999; mouse.y = -999; });

  window.addEventListener('resize', resize);
  resize();
  draw();

  return { destroy: () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); } };
}

/* ---- PARTICLE SCATTER → FORM SYSTEM ---- */
function initScatterParticles(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let particles = [];
  let animId;
  let progress = 0;

  // Generate target positions (graduation cap shape)
  function makeGradCapTargets(cx, cy, scale) {
    const targets = [];
    // Board
    for (let x = -4; x <= 4; x++) {
      for (let y = -2; y <= 1; y++) {
        targets.push({ tx: cx + x * scale, ty: cy + y * scale });
      }
    }
    // Top hat
    for (let x = -2; x <= 2; x++) {
      for (let y = -4; y <= -2; y++) {
        targets.push({ tx: cx + x * scale, ty: cy + y * scale });
      }
    }
    // Tassel
    targets.push({ tx: cx + 2 * scale, ty: cy - 4 * scale });
    targets.push({ tx: cx + 2.5 * scale, ty: cy - 3.5 * scale });
    targets.push({ tx: cx + 3 * scale, ty: cy - 3 * scale });
    return targets;
  }

  function resize() {
    canvas.width = canvas.offsetWidth || window.innerWidth;
    canvas.height = canvas.offsetHeight || window.innerHeight;
    createParticles();
  }

  function createParticles() {
    particles = [];
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const targets = makeGradCapTargets(cx, cy, 16);

    for (let i = 0; i < 200; i++) {
      const target = targets[i % targets.length];
      const angle = Math.random() * Math.PI * 2;
      const radius = Math.random() * Math.min(canvas.width, canvas.height) * 0.4;
      particles.push({
        // scattered start
        sx: cx + Math.cos(angle) * radius,
        sy: cy + Math.sin(angle) * radius,
        // target position
        tx: target.tx,
        ty: target.ty,
        // current
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
        r: Math.random() * 2.5 + 1,
        color: `hsl(${210 + Math.random() * 40}, 85%, ${50 + Math.random() * 20}%)`,
      });
    }
  }

  function setProgress(p) {
    progress = Math.max(0, Math.min(1, p));
    updateParticles();
  }

  function easeInOut(t) {
    return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  }

  function updateParticles() {
    const scattered = progress < 0.5;
    const localP = scattered
      ? easeInOut(progress * 2)           // 0→1 scatter
      : easeInOut((progress - 0.5) * 2); // 0→1 gather

    particles.forEach((p, i) => {
      if (progress < 0.5) {
        // scatter outward
        const angle = (i / particles.length) * Math.PI * 2;
        const spread = localP * Math.min(canvas.width, canvas.height) * 0.3;
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        p.x = p.sx + (Math.cos(angle) * spread - (p.sx - cx)) * localP * 0.5;
        p.y = p.sy + (Math.sin(angle) * spread - (p.sy - cy)) * localP * 0.5;
      } else {
        // converge to target
        p.x = p.sx + (p.tx - p.sx) * localP;
        p.y = p.sy + (p.ty - p.sy) * localP;
      }
    });
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      const alpha = progress < 0.5
        ? 0.3 + progress * 0.4
        : 0.5 + (progress - 0.5) * 1.0;
      ctx.globalAlpha = Math.min(1, alpha);
      ctx.fill();
      ctx.globalAlpha = 1;
    });
    animId = requestAnimationFrame(draw);
  }

  window.addEventListener('resize', resize);
  resize();
  draw();

  return {
    setProgress,
    destroy: () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); }
  };
}

/* ---- CTA SUBTLE CANVAS ---- */
function initCtaCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let animId;
  let t = 0;

  function resize() {
    canvas.width = canvas.offsetWidth || window.innerWidth;
    canvas.height = canvas.offsetHeight || window.innerHeight;
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    t += 0.008;

    // Draw soft floating blobs
    const blobs = [
      { x: 0.2, y: 0.3, r: 200, color: 'rgba(79,142,247,0.04)', speed: 0.7 },
      { x: 0.8, y: 0.7, r: 280, color: 'rgba(79,142,247,0.05)', speed: 0.5 },
      { x: 0.5, y: 0.1, r: 180, color: 'rgba(79,142,247,0.03)', speed: 1.1 },
    ];

    blobs.forEach(b => {
      const x = canvas.width * b.x + Math.sin(t * b.speed) * 40;
      const y = canvas.height * b.y + Math.cos(t * b.speed) * 30;
      const grad = ctx.createRadialGradient(x, y, 0, x, y, b.r);
      grad.addColorStop(0, b.color);
      grad.addColorStop(1, 'transparent');
      ctx.beginPath();
      ctx.arc(x, y, b.r, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();
    });

    animId = requestAnimationFrame(draw);
  }

  window.addEventListener('resize', resize);
  resize();
  draw();

  return { destroy: () => cancelAnimationFrame(animId) };
}
