// ─────────────────────────────────────────
//  particles.js  –  Learnova Canvas Systems
// ─────────────────────────────────────────

/* ── HERO PARTICLE NETWORK ── */
function initHeroParticles(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const particles = [];
  let W, H, mouse = { x: -9999, y: -9999 };

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  canvas.parentElement.addEventListener('mousemove', e => {
    const r = canvas.getBoundingClientRect();
    mouse.x = e.clientX - r.left;
    mouse.y = e.clientY - r.top;
  });
  canvas.parentElement.addEventListener('mouseleave', () => {
    mouse.x = -9999; mouse.y = -9999;
  });

  const N = 100;
  for (let i = 0; i < N; i++) {
    particles.push({
      x: Math.random() * (W || window.innerWidth),
      y: Math.random() * (H || window.innerHeight),
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() * 1.4 + 0.5
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach((p, i) => {
      // Mouse repel
      const mdx = p.x - mouse.x;
      const mdy = p.y - mouse.y;
      const md = Math.sqrt(mdx * mdx + mdy * mdy);
      if (md < 100) {
        const force = (100 - md) / 100 * 0.6;
        p.vx += (mdx / md) * force;
        p.vy += (mdy / md) * force;
      }
      // Damping
      p.vx *= 0.992;
      p.vy *= 0.992;
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fill();

      for (let j = i + 1; j < N; j++) {
        const dx = p.x - particles[j].x;
        const dy = p.y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 130) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(255,255,255,${(1 - dist / 130) * 0.07})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });
    requestAnimationFrame(draw);
  }
  draw();
}

/* ── SCATTER/FORM PARTICLE SYSTEM (Section 3) ── */
function initScatterCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    buildParticles();
  }

  const N = 200;
  let particles = [];
  let targetPositions = [];

  function buildParticles() {
    particles = [];
    targetPositions = [];
    const cx = W / 2, cy = H / 2;
    const R = Math.min(W, H) * 0.28;

    for (let i = 0; i < N; i++) {
      const angle = (i / N) * Math.PI * 2;
      // Circle target
      targetPositions.push({
        x: cx + Math.cos(angle) * R,
        y: cy + Math.sin(angle) * R
      });
      // Random scatter start
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        ox: Math.random() * W,  // outer scatter
        oy: Math.random() * H,
        tx: cx + Math.cos(angle) * R,
        ty: cy + Math.sin(angle) * R,
        r: Math.random() * 1.8 + 0.6
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  let progress = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      let px, py, alpha;
      if (progress <= 0.5) {
        // 0→0.5: particles scatter from current to outer
        const t = progress / 0.5;
        const ease = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        px = p.tx + (p.ox - p.tx) * ease;
        py = p.ty + (p.oy - p.ty) * ease;
        alpha = 0.15 + (1 - ease) * 0.35;
      } else {
        // 0.5→1: particles converge from outer to circle
        const t = (progress - 0.5) / 0.5;
        const ease = t * t * (3 - 2 * t);
        px = p.ox + (p.tx - p.ox) * ease;
        py = p.oy + (p.ty - p.oy) * ease;
        alpha = 0.1 + ease * 0.7;
      }

      ctx.beginPath();
      ctx.arc(px, py, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(167,139,250,${alpha})`;
      ctx.fill();
    });

    // At convergence: draw center glow
    if (progress > 0.8) {
      const intensity = (progress - 0.8) / 0.2;
      const grad = ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, Math.min(W,H)*0.32);
      grad.addColorStop(0, `rgba(167,139,250,${0.08 * intensity})`);
      grad.addColorStop(1, 'rgba(167,139,250,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    }

    requestAnimationFrame(draw);
  }
  draw();

  return {
    setProgress: (p) => { progress = p; }
  };
}

/* ── ORBITS SYSTEM (Section 4) ── */
function initOrbitsCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const rings = [
    { r: 0.12, dotCount: 3, speed: 1.0, phase: 0, color: 'rgba(79,142,247,0.9)', dotR: 4 },
    { r: 0.20, dotCount: 5, speed: 0.7, phase: 0.8, color: 'rgba(167,139,250,0.8)', dotR: 3.5 },
    { r: 0.29, dotCount: 7, speed: 0.5, phase: 1.2, color: 'rgba(52,211,153,0.7)', dotR: 3 },
    { r: 0.38, dotCount: 9, speed: 0.35, phase: 2.1, color: 'rgba(245,158,11,0.6)', dotR: 2.5 }
  ];

  let scrollProgress = 0;
  let time = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const cx = W / 2, cy = H / 2;
    const baseR = Math.min(W, H) * 0.42;
    const speedMult = 0.3 + scrollProgress * 3.5;
    time += 0.008 * speedMult;

    rings.forEach((ring, ri) => {
      const radius = ring.r * baseR / 0.38;
      // Draw orbit ring
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(255,255,255,${0.04 + scrollProgress * 0.04})`;
      ctx.lineWidth = 1;
      ctx.stroke();

      // Dots on ring
      for (let d = 0; d < ring.dotCount; d++) {
        const angle = time * ring.speed + ring.phase + (d / ring.dotCount) * Math.PI * 2;
        const dx = cx + Math.cos(angle) * radius;
        const dy = cy + Math.sin(angle) * radius;

        ctx.beginPath();
        ctx.arc(dx, dy, ring.dotR * (0.6 + scrollProgress * 0.7), 0, Math.PI * 2);
        ctx.fillStyle = ring.color;
        ctx.fill();
      }
    });

    // Center dot
    ctx.beginPath();
    ctx.arc(cx, cy, 4 + scrollProgress * 4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.fill();

    // Alignment flash at progress ~1
    if (scrollProgress > 0.9) {
      const intensity = (scrollProgress - 0.9) / 0.1;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseR * 0.5);
      grad.addColorStop(0, `rgba(255,255,255,${0.05 * intensity})`);
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    }

    requestAnimationFrame(draw);
  }
  draw();

  return {
    setProgress: (p) => { scrollProgress = p; }
  };
}
