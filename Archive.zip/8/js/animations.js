// ──────────────────────────────────────────────
//  animations.js  –  Learnova Scroll Animations
// ──────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {

  // ── Register GSAP plugins ──
  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
  }

  // ── NAVBAR SCROLL BEHAVIOR ──
  const navbar = document.getElementById('navbar');
  if (navbar) {
    ScrollTrigger.create({
      start: 'top -60',
      onUpdate: (self) => {
        if (self.scroller.scrollTop > 60) {
          navbar.classList.add('scrolled');
        } else {
          navbar.classList.remove('scrolled');
        }
      }
    });
    // Simple scroll listener fallback
    window.addEventListener('scroll', () => {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  // ── HAMBURGER MENU ──
  const hamburger = document.querySelector('.nav-hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      mobileNav.classList.toggle('open');
    });
  }

  // ── HERO ENTRANCE ANIMATION ──
  const heroWords = document.querySelectorAll('.hero-h1 .word');
  if (heroWords.length) {
    gsap.to(heroWords, {
      y: 0,
      duration: 0.7,
      ease: 'power4.out',
      stagger: 0.08,
      delay: 0.2
    });
    gsap.to('.hero-sub', { opacity: 1, duration: 0.7, delay: 0.7, ease: 'power2.out' });
    gsap.to('.hero-actions', { opacity: 1, duration: 0.7, delay: 0.9, ease: 'power2.out' });
  }

  // ── HELPER: CREATE PINNED SCROLL SECTION ──
  function createPinnedSection(sectionEl, onProgress) {
    if (!sectionEl) return;
    const proxy = { progress: 0 };
    gsap.to(proxy, {
      progress: 1,
      ease: 'none',
      scrollTrigger: {
        trigger: sectionEl,
        start: 'top top',
        end: '+=200%',
        pin: true,
        scrub: 1,
        onUpdate: (self) => {
          onProgress(self.progress);
        }
      }
    });
  }

  // ── SECTION 1: DOT GRID ──
  const section1 = document.getElementById('feature-1');
  const dots = document.querySelectorAll('.dot-grid-item');
  const content1 = document.querySelector('#feature-1 .pinned-content');

  if (section1 && dots.length) {
    // Pre-calculate center distances for stagger
    const gridSize = 8;
    const center = (gridSize - 1) / 2;
    const dotDistances = Array.from(dots).map((_, i) => {
      const row = Math.floor(i / gridSize);
      const col = i % gridSize;
      return Math.sqrt((row - center) ** 2 + (col - center) ** 2);
    });
    const maxDist = Math.max(...dotDistances);

    createPinnedSection(section1, (progress) => {
      dots.forEach((dot, i) => {
        const delay = dotDistances[i] / maxDist * 0.55;
        const localP = Math.max(0, Math.min(1, (progress - delay) / (1 - delay * 0.5)));
        const ease = localP * localP * (3 - 2 * localP);
        dot.style.transform = `scale(${1 + ease * 1.6})`;
        dot.style.background = `rgba(79,142,247,${0.08 + ease * 0.82})`;
        dot.style.boxShadow = ease > 0.5 ? `0 0 ${ease * 14}px rgba(79,142,247,${ease * 0.5})` : '';
      });

      // Text fade in at 0.2
      if (content1) {
        const textP = Math.max(0, Math.min(1, (progress - 0.2) / 0.25));
        content1.style.opacity = textP;
        content1.style.transform = `translateY(${(1 - textP) * 20}px)`;
      }
    });
  }

  // ── SECTION 2: SVG LINE DRAW ──
  const section2 = document.getElementById('feature-2');
  const svgPaths = document.querySelectorAll('#feature-2 .draw-path');
  const svgCircles = document.querySelectorAll('#feature-2 .travel-dot');
  const content2 = document.querySelector('#feature-2 .pinned-content');

  if (section2 && svgPaths.length) {
    // Initialize stroke dash
    svgPaths.forEach(path => {
      const len = path.getTotalLength();
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = len;
      path.dataset.len = len;
    });

    createPinnedSection(section2, (progress) => {
      svgPaths.forEach((path, i) => {
        const delay = i * 0.18;
        const localP = Math.max(0, Math.min(1, (progress - delay) / (1 - delay)));
        const len = parseFloat(path.dataset.len);
        path.style.strokeDashoffset = len * (1 - localP);

        // Move travel dot along path
        if (svgCircles[i] && localP > 0) {
          const pt = path.getPointAtLength(len * localP);
          svgCircles[i].setAttribute('cx', pt.x);
          svgCircles[i].setAttribute('cy', pt.y);
          svgCircles[i].style.opacity = localP > 0.05 ? 1 : 0;
        }
      });

      // Text fade at 0.3
      if (content2) {
        const textP = Math.max(0, Math.min(1, (progress - 0.3) / 0.25));
        content2.style.opacity = textP;
        content2.style.transform = `translateY(${(1 - textP) * 20}px)`;
      }
    });
  }

  // ── SECTION 3: SCATTER/FORM PARTICLES ──
  const section3 = document.getElementById('feature-3');
  const content3 = document.querySelector('#feature-3 .pinned-content');
  let scatterSystem = null;

  if (typeof initScatterCanvas !== 'undefined') {
    scatterSystem = initScatterCanvas('scatter-canvas');
  }

  if (section3) {
    createPinnedSection(section3, (progress) => {
      if (scatterSystem) scatterSystem.setProgress(progress);
      if (content3) {
        const textP = Math.max(0, Math.min(1, (progress - 0.3) / 0.25));
        content3.style.opacity = textP;
        content3.style.transform = `translateY(${(1 - textP) * 20}px)`;
      }
    });
  }

  // ── SECTION 4: ORBITS ──
  const section4 = document.getElementById('feature-4');
  const content4 = document.querySelector('#feature-4 .pinned-content');
  let orbitsSystem = null;

  if (typeof initOrbitsCanvas !== 'undefined') {
    orbitsSystem = initOrbitsCanvas('orbits-canvas');
  }

  if (section4) {
    createPinnedSection(section4, (progress) => {
      if (orbitsSystem) orbitsSystem.setProgress(progress);
      if (content4) {
        const textP = Math.max(0, Math.min(1, (progress - 0.15) / 0.25));
        content4.style.opacity = textP;
        content4.style.transform = `translateY(${(1 - textP) * 20}px)`;
      }
    });
  }

  // ── STATS COUNT UP (anime.js) ──
  const statsSection = document.querySelector('.stats-section');
  if (statsSection && typeof anime !== 'undefined') {
    const statEls = statsSection.querySelectorAll('.stat-number');
    ScrollTrigger.create({
      trigger: statsSection,
      start: 'top 80%',
      once: true,
      onEnter: () => {
        statEls.forEach((el, i) => {
          const target = parseFloat(el.dataset.target);
          const suffix = el.dataset.suffix || '';
          const isDecimal = String(target).includes('.');
          anime({
            targets: el,
            innerHTML: [0, target],
            duration: 1600,
            delay: i * 150,
            round: isDecimal ? 10 : 1,
            easing: 'easeOutExpo',
            update: function(anim) {
              if (isDecimal) {
                el.textContent = parseFloat(el.innerHTML).toFixed(1) + suffix;
              } else {
                el.textContent = Math.round(parseFloat(el.innerHTML)).toLocaleString() + suffix;
              }
            }
          });
        });
      }
    });
  }

  // ── CARDS DRAG SCROLL ──
  const track = document.querySelector('.cards-track');
  const wrapper = document.querySelector('.cards-track-wrapper');
  if (track && wrapper) {
    let isDown = false, startX = 0, scrollLeft = 0;

    wrapper.addEventListener('mousedown', e => {
      isDown = true;
      startX = e.pageX - wrapper.offsetLeft;
      scrollLeft = wrapper.scrollLeft;
      track.style.transition = 'none';
    });

    document.addEventListener('mouseup', () => { isDown = false; });
    document.addEventListener('mousemove', e => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - wrapper.offsetLeft;
      wrapper.scrollLeft = scrollLeft - (x - startX);
    });

    // Touch
    wrapper.addEventListener('touchstart', e => {
      startX = e.touches[0].pageX;
      scrollLeft = wrapper.scrollLeft;
    }, { passive: true });
    wrapper.addEventListener('touchmove', e => {
      const x = e.touches[0].pageX;
      wrapper.scrollLeft = scrollLeft - (x - startX);
    }, { passive: true });

    // Make wrapper scrollable
    wrapper.style.overflowX = 'auto';
    wrapper.style.scrollbarWidth = 'none';
    wrapper.style.msOverflowStyle = 'none';
    const style = document.createElement('style');
    style.textContent = '.cards-track-wrapper::-webkit-scrollbar{display:none}';
    document.head.appendChild(style);
  }

  // ── GENERAL FADE-IN ON SCROLL (non-pinned sections) ──
  const fadeEls = document.querySelectorAll('.fade-in');
  fadeEls.forEach(el => {
    gsap.fromTo(el,
      { opacity: 0, y: 30 },
      {
        opacity: 1, y: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          once: true
        }
      }
    );
  });

  // ── MOBILE: Disable pinned scrolltrigger on small screens ──
  ScrollTrigger.matchMedia({
    '(max-width: 768px)': function() {
      // On mobile, kill all pinned triggers and make sections static
      ScrollTrigger.getAll().forEach(st => {
        if (st.pin) st.kill();
      });
      // Show all pinned content immediately
      document.querySelectorAll('.pinned-content').forEach(el => {
        el.style.opacity = '1';
        el.style.transform = 'none';
      });
      document.querySelectorAll('.dot-grid-item').forEach(dot => {
        dot.style.background = 'rgba(79,142,247,0.6)';
      });
    }
  });

});

// ── CONTACT FORM VALIDATION ──
(function() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  function showError(fieldId, msg) {
    const el = document.getElementById(fieldId + '-error');
    if (el) { el.textContent = msg; el.style.display = 'block'; }
  }
  function clearError(fieldId) {
    const el = document.getElementById(fieldId + '-error');
    if (el) { el.style.display = 'none'; }
  }
  function isValidEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

  form.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    const name = form.querySelector('#name');
    const email = form.querySelector('#email');
    const subject = form.querySelector('#subject');
    const message = form.querySelector('#message');

    clearError('name'); clearError('email');
    clearError('subject'); clearError('message');

    if (!name.value.trim() || name.value.trim().length < 2) {
      showError('name', 'Please enter your full name (min 2 characters).');
      valid = false;
    }
    if (!isValidEmail(email.value)) {
      showError('email', 'Please enter a valid email address.');
      valid = false;
    }
    if (!subject.value.trim() || subject.value.trim().length < 3) {
      showError('subject', 'Please enter a subject (min 3 characters).');
      valid = false;
    }
    if (!message.value.trim() || message.value.trim().length < 15) {
      showError('message', 'Please enter a message (min 15 characters).');
      valid = false;
    }

    if (valid) {
      const btn = form.querySelector('.form-submit');
      btn.textContent = 'Message Sent ✓';
      btn.style.background = '#34d399';
      btn.style.color = '#0d0d0d';
      btn.disabled = true;
      form.reset();
      setTimeout(() => {
        btn.textContent = 'Send Message';
        btn.style.background = '';
        btn.style.color = '';
        btn.disabled = false;
      }, 3500);
    }
  });
})();
