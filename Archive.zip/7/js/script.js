/* ==============================
   LEARNFLOW — JS (Anime.js Powered)
   ============================== */

// ——— Wait for DOM ———
document.addEventListener('DOMContentLoaded', () => {

  // ——— CURSOR ———
  const cursor = document.querySelector('.cursor');
  const follower = document.querySelector('.cursor-follower');
  if (cursor && follower) {
    document.addEventListener('mousemove', e => {
      anime({ targets: cursor, left: e.clientX - 6, top: e.clientY - 6, duration: 0, easing: 'linear' });
      anime({ targets: follower, left: e.clientX - 18, top: e.clientY - 18, duration: 120, easing: 'easeOutQuad' });
    });
    document.querySelectorAll('a, button, .cat-card, .course-card, .mentor-card, .faq-q').forEach(el => {
      el.addEventListener('mouseenter', () => { cursor.classList.add('hovered'); follower.classList.add('hovered'); });
      el.addEventListener('mouseleave', () => { cursor.classList.remove('hovered'); follower.classList.remove('hovered'); });
    });
  }

  // ——— NAV SCROLL ———
  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  });

  // ——— MOBILE MENU ———
  const hamburger = document.querySelector('.hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');
  const mobileOverlay = document.querySelector('.mobile-overlay');
  if (hamburger) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
      mobileOverlay.classList.toggle('open');
    });
    mobileOverlay.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      mobileOverlay.classList.remove('open');
    });
  }

  // ——— HERO ENTRANCE ———
  const heroTl = anime.timeline({ easing: 'easeOutExpo' });
  heroTl
    .add({ targets: '.hero-badge', opacity: [0, 1], translateY: [20, 0], duration: 700 })
    .add({ targets: '.hero-title', opacity: [0, 1], translateY: [40, 0], duration: 900 }, '-=400')
    .add({ targets: '.hero-desc', opacity: [0, 1], translateY: [20, 0], duration: 700 }, '-=500')
    .add({ targets: '.hero-actions', opacity: [0, 1], translateY: [20, 0], duration: 600 }, '-=400')
    .add({ targets: '.hero-stats .hero-stat', opacity: [0, 1], translateY: [20, 0], delay: anime.stagger(100), duration: 500 }, '-=300')
    .add({ targets: '.hero-visual', opacity: [0, 1], translateX: [60, 0], duration: 900 }, '-=1100')
    .add({ targets: '.hero-card', opacity: [0, 1], scale: [0.9, 1], delay: anime.stagger(150), duration: 600, easing: 'easeOutBack' }, '-=600');

  // ——— COUNTER ANIMATION ———
  const counters = document.querySelectorAll('[data-count]');
  const runCounters = (entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseFloat(el.dataset.count);
        const isDecimal = target % 1 !== 0;
        anime({
          targets: { val: 0 },
          val: target,
          duration: 2000,
          easing: 'easeOutExpo',
          update(anim) {
            const val = anim.animatables[0].target.val;
            el.textContent = isDecimal ? val.toFixed(1) : Math.round(val);
          }
        });
        observer.unobserve(el);
      }
    });
  };
  const counterObs = new IntersectionObserver(runCounters, { threshold: 0.5 });
  counters.forEach(c => counterObs.observe(c));

  // ——— SCROLL REVEAL ———
  const reveals = document.querySelectorAll('.reveal');
  const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const delay = parseFloat(el.dataset.delay || 0);
        anime({
          targets: el,
          opacity: [0, 1],
          translateY: [40, 0],
          duration: 800,
          delay,
          easing: 'easeOutExpo'
        });
        el.classList.add('visible');
        revealObs.unobserve(el);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  reveals.forEach(el => revealObs.observe(el));

  // ——— STAGGER REVEALS ———
  const staggerGroups = document.querySelectorAll('[data-stagger]');
  staggerGroups.forEach(group => {
    const children = group.children;
    Array.from(children).forEach(child => { child.style.opacity = '0'; child.style.transform = 'translateY(30px)'; });
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          anime({
            targets: children,
            opacity: [0, 1],
            translateY: [30, 0],
            delay: anime.stagger(80),
            duration: 700,
            easing: 'easeOutExpo'
          });
          obs.unobserve(group);
        }
      });
    }, { threshold: 0.1 });
    obs.observe(group);
  });

  // ——— CAT CARD HOVER (magnetic) ———
  document.querySelectorAll('.cat-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      anime({ targets: card, translateX: x * 0.05, translateY: y * 0.05, duration: 200, easing: 'easeOutQuad' });
    });
    card.addEventListener('mouseleave', () => {
      anime({ targets: card, translateX: 0, translateY: 0, duration: 400, easing: 'easeOutElastic(1, 0.6)' });
    });
  });

  // ——— FAQ ———
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.closest('.faq-item');
      const a = item.querySelector('.faq-a');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(openItem => {
        openItem.classList.remove('open');
      });
      if (!isOpen) {
        item.classList.add('open');
        anime({ targets: a, maxHeight: ['0px', '200px'], duration: 400, easing: 'easeOutExpo' });
      }
    });
  });

  // ——— COURSE CARD TILT ———
  document.querySelectorAll('.course-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      anime({
        targets: card,
        rotateY: x * 8,
        rotateX: -y * 5,
        duration: 200,
        easing: 'easeOutQuad'
      });
    });
    card.addEventListener('mouseleave', () => {
      anime({ targets: card, rotateY: 0, rotateX: 0, duration: 600, easing: 'easeOutElastic(1, 0.6)' });
    });
  });
  document.querySelector('.courses-grid')?.style.setProperty('perspective', '1200px');

  // ——— FLOATING HERO CARDS ———
  anime({
    targets: '.hero-card-1',
    translateY: [-8, 8],
    duration: 3000,
    loop: true,
    direction: 'alternate',
    easing: 'easeInOutSine'
  });
  anime({
    targets: '.hero-card-2',
    translateY: [5, -12],
    duration: 3800,
    loop: true,
    direction: 'alternate',
    easing: 'easeInOutSine'
  });

  // ——— NEWSLETTER ———
  const nlForm = document.querySelector('.newsletter-form');
  if (nlForm) {
    nlForm.addEventListener('submit', e => {
      e.preventDefault();
      const btn = nlForm.querySelector('button');
      btn.textContent = '✓';
      anime({ targets: btn, scale: [1.2, 1], duration: 400, easing: 'easeOutBack' });
      setTimeout(() => { btn.textContent = 'Join'; }, 2000);
    });
  }

  // ——— CONTACT FORM ———
  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      const inputs = contactForm.querySelectorAll('input, textarea');
      let valid = true;
      inputs.forEach(input => {
        if (!input.value.trim()) {
          valid = false;
          input.style.borderColor = '#ff6b6b';
          anime({ targets: input, translateX: [-6, 6, -4, 4, 0], duration: 300, easing: 'easeInOutSine' });
        } else {
          input.style.borderColor = '';
        }
      });
      if (valid) {
        const btn = contactForm.querySelector('button[type="submit"]');
        btn.textContent = 'Message Sent! ✓';
        btn.style.background = '#22c55e';
        anime({ targets: btn, scale: [0.95, 1.02, 1], duration: 500, easing: 'easeOutBack' });
      }
    });
  }

  // ——— SECTION BG PARALLAX ———
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    const heroBg = document.querySelector('.hero-bg');
    if (heroBg) {
      anime({ targets: heroBg, translateY: scrollY * 0.15, duration: 0, easing: 'linear' });
    }
  });

});
