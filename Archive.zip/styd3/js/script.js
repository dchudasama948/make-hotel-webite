/* ============================================================
   NEXLEARN — Premium Animation Engine
   Scroll animations, parallax, cursor, counters, split text
   ============================================================ */

(function () {
  'use strict';

  /* ===== UTILS ===== */
  const $ = (s, ctx = document) => ctx.querySelector(s);
  const $$ = (s, ctx = document) => [...ctx.querySelectorAll(s)];
  const clamp = (v, min, max) => Math.min(Math.max(v, min), max);
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeOut3 = t => 1 - Math.pow(1 - t, 3);

  /* ===== LOADER ===== */
  function initLoader() {
    const loader = $('.page-loader');
    if (!loader) return;
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
      loader.classList.add('done');
      setTimeout(() => {
        loader.remove();
        document.body.style.overflow = '';
        triggerHeroAnimations();
      }, 900);
    }, 2400);
  }

  function triggerHeroAnimations() {
    // Stagger reveal for hero stats, etc.
    $$('[data-hero-in]').forEach((el, i) => {
      setTimeout(() => el.classList.add('in'), i * 150);
    });
  }

  /* ===== CUSTOM CURSOR ===== */
  const dot = $('.cursor-dot');
  const circle = $('.cursor-circle');
  const label = $('.cursor-label');
  let mx = 0, my = 0, cx = 0, cy = 0;
  let raf;

  if (dot && circle) {
    document.addEventListener('mousemove', e => {
      mx = e.clientX;
      my = e.clientY;
    });

    function animCursor() {
      cx = lerp(cx, mx, 0.12);
      cy = lerp(cy, my, 0.12);
      dot.style.left = mx + 'px';
      dot.style.top = my + 'px';
      circle.style.left = cx + 'px';
      circle.style.top = cy + 'px';
      if (label) { label.style.left = cx + 'px'; label.style.top = cy + 'px'; }
      raf = requestAnimationFrame(animCursor);
    }
    animCursor();

    // Hover interactions
    const links = $$('a, button, [data-cursor]');
    links.forEach(el => {
      el.addEventListener('mouseenter', () => {
        const lbl = el.dataset.cursor || '';
        document.body.classList.add('cursor-expand');
        if (label && lbl) { label.textContent = lbl; document.body.classList.add('cursor-view'); }
        circle.style.background = 'transparent';
      });
      el.addEventListener('mouseleave', () => {
        document.body.classList.remove('cursor-expand', 'cursor-view');
      });
    });

    document.addEventListener('mouseleave', () => { dot.style.opacity = '0'; circle.style.opacity = '0'; });
    document.addEventListener('mouseenter', () => { dot.style.opacity = '1'; circle.style.opacity = '1'; });

    document.addEventListener('mousedown', () => {
      dot.style.transform = 'translate(-50%,-50%) scale(0.7)';
    });
    document.addEventListener('mouseup', () => {
      dot.style.transform = 'translate(-50%,-50%) scale(1)';
    });
  }

  /* ===== NAVBAR ===== */
  const nav = $('nav');
  if (nav) {
    const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 50);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ===== MOBILE MENU ===== */
  const hamburger = $('.nav-hamburger');
  const mobileMenu = $('.mobile-menu');
  const mobileClose = $('.mobile-close');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
    const close = () => { mobileMenu.classList.remove('open'); document.body.style.overflow = ''; };
    mobileClose?.addEventListener('click', close);
    $$('.mobile-menu a').forEach(a => a.addEventListener('click', close));
  }

  /* ===== INTERSECTION OBSERVER - SCROLL REVEALS ===== */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const delay = parseInt(el.dataset.delay || 0);
      setTimeout(() => {
        el.classList.add('in');
        // Also trigger stagger children
        $$('.stagger', el.parentElement).forEach(s => {
          if (s === el || s.closest('[data-delay]') === el) return;
        });
      }, delay);
      revealObserver.unobserve(el);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -80px 0px' });

  const staggerObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('in');
      staggerObserver.unobserve(entry.target);
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

  function initReveal() {
    $$('.reveal').forEach(el => revealObserver.observe(el));
    $$('.stagger').forEach(el => staggerObserver.observe(el));
  }

  /* ===== SPLIT TEXT ===== */
  function initSplitText() {
    $$('[data-split]').forEach(el => {
      const words = el.textContent.split(' ');
      el.innerHTML = words.map(word => {
        const chars = word.split('').map((c, i) => {
          const span = document.createElement('span');
          span.className = 'char';
          span.textContent = c === '' ? '\u00A0' : c;
          return span.outerHTML;
        }).join('');
        return `<span class="word">${chars}</span>`;
      }).join(' ');

      const splitObs = new IntersectionObserver(entries => {
        entries.forEach(e => {
          if (!e.isIntersecting) return;
          e.target.classList.add('in');
          // stagger each char
          $$('.char', e.target).forEach((ch, i) => {
            ch.style.transitionDelay = i * 0.03 + 's';
          });
          splitObs.unobserve(e.target);
        });
      }, { threshold: 0.3 });
      el.classList.add('split-text');
      splitObs.observe(el);
    });
  }

  /* ===== PARALLAX ===== */
  function initParallax() {
    const parallaxBandImg = $('.parallax-band-img');
    const heroImgs = $$('[data-parallax]');

    function updateParallax() {
      const scrollY = window.scrollY;

      // Parallax band image
      if (parallaxBandImg) {
        const band = parallaxBandImg.closest('.parallax-band');
        if (band) {
          const rect = band.getBoundingClientRect();
          const progress = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
          const offset = (progress - 0.5) * 120;
          parallaxBandImg.style.transform = `translateY(calc(-15% + ${offset}px))`;
        }
      }

      // Generic parallax elements
      heroImgs.forEach(el => {
        const speed = parseFloat(el.dataset.parallax || 0.15);
        const rect = el.getBoundingClientRect();
        const centerY = rect.top + rect.height / 2 - window.innerHeight / 2;
        el.style.transform = `translateY(${centerY * speed}px)`;
      });
    }

    window.addEventListener('scroll', updateParallax, { passive: true });
    updateParallax();
  }

  /* ===== COUNTERS ===== */
  function animateCounter(el) {
    if (el._counted) return;
    el._counted = true;
    const target = parseFloat(el.dataset.count);
    const duration = parseInt(el.dataset.duration || 2000);
    const decimals = parseInt(el.dataset.decimals || 0);
    const start = performance.now();

    function tick(now) {
      const elapsed = now - start;
      const t = clamp(elapsed / duration, 0, 1);
      const val = target * easeOut3(t);
      el.textContent = decimals > 0 ? val.toFixed(decimals) : Math.round(val).toLocaleString();
      if (t < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) animateCounter(e.target); });
  }, { threshold: 0.6 });

  function initCounters() {
    $$('[data-count]').forEach(el => counterObs.observe(el));
  }

  /* ===== MAGNETIC BUTTONS ===== */
  function initMagnetic() {
    $$('[data-magnetic]').forEach(el => {
      const strength = parseFloat(el.dataset.magnetic || 0.35);
      el.addEventListener('mousemove', e => {
        const rect = el.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        const dx = (e.clientX - cx) * strength;
        const dy = (e.clientY - cy) * strength;
        el.style.transform = `translate(${dx}px, ${dy}px)`;
      });
      el.addEventListener('mouseleave', () => {
        el.style.transform = '';
      });
    });
  }

  /* ===== 3D CARD TILT ===== */
  function initTilt() {
    $$('[data-tilt]').forEach(card => {
      card.addEventListener('mousemove', e => {
        const rect = card.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width - 0.5) * 16;
        const y = ((e.clientY - rect.top) / rect.height - 0.5) * 16;
        card.style.transform = `perspective(600px) rotateY(${x}deg) rotateX(${-y}deg) translateY(-10px)`;
        card.style.boxShadow = `${-x * 2}px ${y * 2 + 20}px 60px rgba(26,26,46,0.18)`;
      });
      card.addEventListener('mouseleave', () => {
        card.style.transform = '';
        card.style.boxShadow = '';
      });
    });
  }

  /* ===== FEATURE TABS ===== */
  function initTabs() {
    $$('.feat-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        $$('.feat-tab').forEach(t => t.classList.remove('active'));
        $$('.feat-panel').forEach(p => { p.style.display = 'none'; p.classList.remove('panel-in'); });
        tab.classList.add('active');
        const panel = $(`[data-panel="${tab.dataset.tab}"]`);
        if (panel) {
          panel.style.display = 'grid';
          requestAnimationFrame(() => panel.classList.add('panel-in'));
          // re-run reveals inside
          $$('.reveal', panel).forEach(el => {
            el.classList.remove('in');
            setTimeout(() => el.classList.add('in'), 50);
          });
          $$('[data-count]', panel).forEach(el => {
            el._counted = false;
            animateCounter(el);
          });
        }
      });
    });
  }

  /* ===== COURSES FILTER ===== */
  function initFilter() {
    $$('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const f = btn.dataset.filter;
        $$('.course-card-wrap').forEach(wrap => {
          const show = f === 'all' || wrap.dataset.cat === f;
          wrap.style.display = show ? 'block' : 'none';
          if (show) {
            wrap.style.opacity = '0';
            wrap.style.transform = 'translateY(20px)';
            requestAnimationFrame(() => {
              wrap.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
              wrap.style.opacity = '1';
              wrap.style.transform = 'translateY(0)';
            });
          }
        });
      });
    });
  }

  /* ===== FORM VALIDATION ===== */
  function initForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', e => {
      e.preventDefault();
      let ok = true;
      $$('[data-req]', form).forEach(field => {
        const group = field.closest('.form-group');
        const err = group?.querySelector('.form-err-msg');
        const empty = !field.value.trim();
        const emailBad = field.type === 'email' && field.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
        if (empty || emailBad) {
          field.classList.add('err');
          if (err) { err.textContent = emailBad ? 'Enter a valid email.' : 'This field is required.'; err.classList.add('show'); }
          ok = false;
        } else {
          field.classList.remove('err');
          err?.classList.remove('show');
        }
      });

      if (ok) {
        const fields = $('.form-fields', form);
        const success = $('.form-success', form);
        if (fields) { fields.style.opacity = '0'; fields.style.transform = 'translateY(-20px)'; setTimeout(() => fields.style.display = 'none', 400); }
        setTimeout(() => success?.classList.add('show'), 450);
      }
    });

    $$('.form-input', form).forEach(field => {
      field.addEventListener('input', () => {
        field.classList.remove('err');
        field.closest('.form-group')?.querySelector('.form-err-msg')?.classList.remove('show');
      });
    });
  }

  /* ===== HORIZONTAL SCROLL CARDS AUTO-DRAG ===== */
  function initDragScroll() {
    $$('[data-drag-scroll]').forEach(el => {
      let isDown = false, startX, scrollLeft;
      el.addEventListener('mousedown', e => {
        isDown = true;
        el.style.cursor = 'grabbing';
        startX = e.pageX - el.offsetLeft;
        scrollLeft = el.scrollLeft;
      });
      document.addEventListener('mouseup', () => { isDown = false; el.style.cursor = ''; });
      el.addEventListener('mousemove', e => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - el.offsetLeft;
        el.scrollLeft = scrollLeft - (x - startX) * 1.5;
      });
    });
  }

  /* ===== SMOOTH ANCHOR SCROLL ===== */
  function initAnchorScroll() {
    $$('a[href^="#"]').forEach(a => {
      a.addEventListener('click', e => {
        const target = document.querySelector(a.getAttribute('href'));
        if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
      });
    });
  }

  /* ===== NUMBER SCRAMBLE ON HOVER ===== */
  function initScramble() {
    $$('[data-scramble]').forEach(el => {
      const original = el.textContent;
      const chars = '0123456789';
      let interval;
      el.addEventListener('mouseenter', () => {
        let iterations = 0;
        clearInterval(interval);
        interval = setInterval(() => {
          el.textContent = original.split('').map((c, i) => {
            if (i < iterations) return original[i];
            if (!/\d/.test(c)) return c;
            return chars[Math.floor(Math.random() * chars.length)];
          }).join('');
          if (iterations >= original.length) clearInterval(interval);
          iterations += 0.5;
        }, 40);
      });
    });
  }

  /* ===== SECTION PROGRESS LINE ===== */
  function initProgressLine() {
    const line = document.createElement('div');
    line.style.cssText = `position:fixed;top:0;left:0;height:2px;background:var(--accent);z-index:99999;transform-origin:left;transition:width 0.1s linear;`;
    document.body.appendChild(line);
    window.addEventListener('scroll', () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      line.style.width = (window.scrollY / h * 100) + '%';
    }, { passive: true });
  }

  /* ===== SECTION BACKGROUND SHIFT ON SCROLL ===== */
  function initSectionBg() {
    const sections = $$('[data-bg]');
    if (!sections.length) return;
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          document.body.style.background = e.target.dataset.bg;
        }
      });
    }, { threshold: 0.5 });
    sections.forEach(s => obs.observe(s));
  }

  /* ===== INIT ALL ===== */
  document.addEventListener('DOMContentLoaded', () => {
    initLoader();
    initReveal();
    initSplitText();
    initCounters();
    initMagnetic();
    initTilt();
    initTabs();
    initFilter();
    initForm();
    initDragScroll();
    initAnchorScroll();
    initScramble();
    initProgressLine();
    initSectionBg();
    setTimeout(initParallax, 100);
  });

})();
