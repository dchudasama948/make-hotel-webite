/* ================================================================
   NEXLEARN v3 — Animation Engine
   GSAP ScrollTrigger + Anime.js + Lenis Smooth Scroll
   ================================================================ */
(function () {
  'use strict';

  /* ─────────────────────────────────────
   WAIT FOR LIBS
  ───────────────────────────────────── */
  function waitForGSAP(cb) {
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      gsap.registerPlugin(ScrollTrigger);
      cb();
    } else {
      setTimeout(() => waitForGSAP(cb), 50);
    }
  }

  /* ─────────────────────────────────────
   UTILS
  ───────────────────────────────────── */
  const $ = (s, ctx = document) => ctx.querySelector(s);
  const $$ = (s, ctx = document) => [...ctx.querySelectorAll(s)];
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

  /* ─────────────────────────────────────
   LENIS SMOOTH SCROLL
  ───────────────────────────────────── */
  let lenis;
  function initLenis() {
    if (typeof Lenis === 'undefined') return;
    lenis = new Lenis({
      duration: 1.4,
      easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      direction: 'vertical',
      gestureDirection: 'vertical',
      smooth: true,
      smoothTouch: false,
      touchMultiplier: 2
    });
    function raf(time) {
      lenis.raf(time);
      if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.update();
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
  }

  /* ─────────────────────────────────────
   PROGRESS LINE
  ───────────────────────────────────── */
  function initProgressLine() {
    const line = $('#progress-line');
    if (!line) return;
    window.addEventListener('scroll', () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      const pct = window.scrollY / h;
      line.style.transform = `scaleX(${pct})`;
    }, { passive: true });
  }

  /* ─────────────────────────────────────
   CURSOR
  ───────────────────────────────────── */
  const dot = $('.c-dot'), ring = $('.c-ring'), ctxt = $('.c-text');
  let mx = 0, my = 0, rx = 0, ry = 0;

  if (dot && ring) {
    document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

    (function animCursor() {
      rx = lerp(rx, mx, 0.10);
      ry = lerp(ry, my, 0.10);
      dot.style.left = mx + 'px'; dot.style.top = my + 'px';
      ring.style.left = rx + 'px'; ring.style.top = ry + 'px';
      if (ctxt) { ctxt.style.left = rx + 'px'; ctxt.style.top = ry + 'px'; }
      requestAnimationFrame(animCursor);
    })();

    $$('a, button, [data-cur]').forEach(el => {
      el.addEventListener('mouseenter', () => {
        const label = el.dataset.cur || '';
        document.body.classList.add('cur-expand');
        if (ctxt && label) { ctxt.textContent = label; document.body.classList.add('cur-view'); }
      });
      el.addEventListener('mouseleave', () => {
        document.body.classList.remove('cur-expand', 'cur-view');
      });
    });

    document.addEventListener('mouseleave', () => {
      dot.style.opacity = '0'; ring.style.opacity = '0';
    });
    document.addEventListener('mouseenter', () => {
      dot.style.opacity = '1'; ring.style.opacity = '1';
    });
  }

  /* ─────────────────────────────────────
   ANIME.JS LOADER
  ───────────────────────────────────── */
  function initLoader(onDone) {
    const loader = $('#loader');
    if (!loader) { onDone(); return; }
    document.body.style.overflow = 'hidden';

    const logo = $('.loader-logo');
    const tagline = $('.loader-tagline');
    const bar = $('.loader-bar');
    const counter = $('.loader-counter');
    const slideOut = $('.loader-slide-out');

    // If Anime.js available, use it; else CSS fallback
    if (typeof anime !== 'undefined') {
      // Bar progress
      anime({
        targets: bar,
        width: ['0%', '100%'],
        duration: 2200,
        easing: 'easeInOutQuart'
      });
      // Counter
      if (counter) {
        anime({
          targets: { val: 0 },
          val: 100,
          round: 1,
          duration: 2200,
          easing: 'easeInOutQuart',
          update: function(a) { counter.textContent = Math.round(a.animations[0].currentValue) + '%'; }
        });
      }
      // Logo
      anime({
        targets: logo,
        translateY: [120, 0],
        duration: 900, delay: 200,
        easing: 'easeOutExpo'
      });
      // Tagline
      anime({
        targets: tagline,
        opacity: [0,1], translateY: [8,0],
        duration: 600, delay: 700,
        easing: 'easeOutExpo'
      });
      // Slide out
      setTimeout(() => {
        anime({
          targets: slideOut,
          scaleY: [0, 1],
          duration: 700,
          easing: 'easeInOutExpo',
          complete: () => {
            anime({
              targets: loader,
              opacity: 0, duration: 400,
              complete: () => {
                loader.remove();
                document.body.style.overflow = '';
                onDone();
              }
            });
          }
        });
      }, 2400);
    } else {
      // Fallback
      setTimeout(() => {
        loader.style.transition = 'opacity 0.6s';
        loader.style.opacity = '0';
        setTimeout(() => { loader.remove(); document.body.style.overflow = ''; onDone(); }, 600);
      }, 2200);
    }
  }

  /* ─────────────────────────────────────
   HERO ANIMATIONS (Anime.js)
  ───────────────────────────────────── */
  function initHero() {
    if (typeof anime === 'undefined') return;

    const lines = $$('.hero-h1 .line-inner');
    anime({
      targets: lines,
      translateY: [110, 0],
      duration: 1000,
      delay: anime.stagger(130),
      easing: 'easeOutExpo'
    });

    // Underline after word lands
    const underlines = $$('.hero-h1 .underline-word::after');
    setTimeout(() => {
      $$('.hero-h1 .underline-word').forEach(el => {
        anime({ targets: el, '--scaleX': [0,1], duration: 800, delay: 300, easing: 'easeOutExpo' });
        // CSS-based via class
        el.classList.add('uw-active');
      });
    }, 900);

    anime({
      targets: '.hero-chip',
      opacity: [0, 1], translateY: [16, 0],
      duration: 700, delay: 200,
      easing: 'easeOutExpo'
    });
    anime({
      targets: '.hero-desc',
      opacity: [0, 1], translateY: [20, 0],
      duration: 700, delay: 700,
      easing: 'easeOutExpo'
    });
    anime({
      targets: '.hero-cta-row',
      opacity: [0, 1], translateY: [20, 0],
      duration: 700, delay: 900,
      easing: 'easeOutExpo'
    });
    anime({
      targets: '.hero-stats-row',
      opacity: [0, 1], translateY: [16, 0],
      duration: 700, delay: 1100,
      easing: 'easeOutExpo'
    });
    // Hero image reveal
    anime({
      targets: '.hero-img-main',
      clipPath: ['inset(0 100% 0 0 round 40px)', 'inset(0 0% 0 0 round 40px)'],
      duration: 1200, delay: 400,
      easing: 'easeOutExpo'
    });
    // Badges
    setTimeout(() => {
      anime({
        targets: '.hero-badge-1',
        opacity: [0, 1], translateY: [30, 0], rotate: [-2, -2],
        duration: 800, easing: 'easeOutExpo'
      });
      anime({
        targets: '.hero-badge-2',
        opacity: [0, 1], translateY: [-30, 0], rotate: [2, 2],
        duration: 800, delay: 150, easing: 'easeOutExpo'
      });
    }, 1200);

    // Floating badges animation loop
    if (typeof anime !== 'undefined') {
      anime({
        targets: '.hero-badge-1',
        translateY: ['-6px', '6px'],
        rotate: [-2, -1.5],
        duration: 4000,
        direction: 'alternate',
        loop: true,
        easing: 'easeInOutSine',
        delay: 2000
      });
      anime({
        targets: '.hero-badge-2',
        translateY: ['6px', '-6px'],
        rotate: [2, 1.5],
        duration: 5000,
        direction: 'alternate',
        loop: true,
        easing: 'easeInOutSine',
        delay: 2200
      });
    }
  }

  /* ─────────────────────────────────────
   CSS underline trick
  ───────────────────────────────────── */
  function addGlobalStyle() {
    const s = document.createElement('style');
    s.textContent = `
      .hero-h1 .underline-word.uw-active::after {
        animation: uwIn 0.8s cubic-bezier(0.16,1,0.3,1) 0s forwards;
      }
      @keyframes uwIn { from { transform: scaleX(0); } to { transform: scaleX(1); } }
      .feat-card-h { transform-style: preserve-3d; }
    `;
    document.head.appendChild(s);
  }

  /* ─────────────────────────────────────
   GSAP SCROLL ANIMATIONS
  ───────────────────────────────────── */
  function initGSAP() {
    if (typeof gsap === 'undefined') return;

    // General reveals
    $$('.reveal-up').forEach(el => {
      gsap.to(el, {
        opacity: 1, y: 0, duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: el, start: 'top 88%',
          toggleActions: 'play none none none'
        }
      });
    });
    $$('.reveal-left').forEach(el => {
      gsap.to(el, {
        opacity: 1, x: 0, duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' }
      });
    });
    $$('.reveal-right').forEach(el => {
      gsap.to(el, {
        opacity: 1, x: 0, duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' }
      });
    });
    $$('.reveal-scale').forEach(el => {
      gsap.to(el, {
        opacity: 1, scale: 1, duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' }
      });
    });

    // Stagger children
    $$('[data-stagger]').forEach(parent => {
      const delay = parseFloat(parent.dataset.stagger || 0.1);
      gsap.from(parent.children, {
        opacity: 0, y: 50, duration: 0.8,
        stagger: delay, ease: 'power3.out',
        scrollTrigger: { trigger: parent, start: 'top 85%', toggleActions: 'play none none none' }
      });
    });

    // HORIZONTAL SCROLL SECTION
    const hOuter = $('.h-scroll-outer');
    if (hOuter) {
      const track = $('.h-scroll-track');
      if (track) {
        const trackWidth = track.scrollWidth;
        const viewportWidth = window.innerWidth;

        gsap.to(track, {
          x: -(trackWidth - viewportWidth),
          ease: 'none',
          scrollTrigger: {
            trigger: hOuter,
            start: 'top top',
            end: () => `+=${trackWidth - viewportWidth + 200}`,
            pin: true,
            scrub: 1.2,
            anticipatePin: 1,
            invalidateOnRefresh: true
          }
        });
      }
    }

    // PARALLAX BAND
    const pbImg = $('.pb-img');
    if (pbImg) {
      gsap.to(pbImg, {
        yPercent: 30,
        ease: 'none',
        scrollTrigger: { trigger: '.pb', start: 'top bottom', end: 'bottom top', scrub: true }
      });
    }

    // Image parallax on about section
    const avMain = $('.av-main img');
    if (avMain) {
      gsap.to(avMain, {
        yPercent: 12, ease: 'none',
        scrollTrigger: { trigger: '.about-visual', start: 'top bottom', end: 'bottom top', scrub: true }
      });
    }

    // Hero image subtle parallax
    const heroImg = $('.hero-img-main img');
    if (heroImg) {
      gsap.to(heroImg, {
        yPercent: 8, ease: 'none',
        scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true }
      });
    }

    // Section big text reveal (split chars with stagger)
    $$('[data-char-reveal]').forEach(el => {
      const text = el.textContent;
      el.innerHTML = text.split('').map(c =>
        c === ' ' ? '<span class="char-sp"> </span>' : `<span class="char-r" style="display:inline-block;overflow:hidden;"><span style="display:inline-block;transform:translateY(110%)">${c}</span></span>`
      ).join('');
      const chars = $$('.char-r > span', el);
      gsap.to(chars, {
        y: 0, duration: 0.7, stagger: 0.025,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' }
      });
    });

    // Clip-path image reveals
    $$('[data-clip-reveal]').forEach(el => {
      gsap.to(el, {
        clipPath: 'inset(0 0% 0 0 round 20px)',
        duration: 1.2, ease: 'power4.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' }
      });
    });
  }

  /* ─────────────────────────────────────
   ANIMATED COUNTERS
  ───────────────────────────────────── */
  function initCounters() {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (!e.isIntersecting || e.target._done) return;
        e.target._done = true;
        const target = parseFloat(e.target.dataset.count);
        const dec = parseInt(e.target.dataset.dec || 0);
        const dur = parseInt(e.target.dataset.dur || 2000);
        const start = performance.now();
        const tick = now => {
          const t = Math.min((now - start) / dur, 1);
          const ease = 1 - Math.pow(1 - t, 3);
          e.target.textContent = dec ? (target * ease).toFixed(dec) : Math.round(target * ease).toLocaleString();
          if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.6 });
    $$('[data-count]').forEach(el => obs.observe(el));
  }

  /* ─────────────────────────────────────
   3D TILT ON CARDS
  ───────────────────────────────────── */
  function initTilt() {
    $$('[data-tilt]').forEach(el => {
      el.addEventListener('mousemove', e => {
        const r = el.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width - 0.5) * 14;
        const y = ((e.clientY - r.top) / r.height - 0.5) * 14;
        el.style.transform = `perspective(700px) rotateY(${x}deg) rotateX(${-y}deg) translateY(-10px) scale(1.02)`;
        el.style.boxShadow = `${-x}px ${y + 20}px 60px rgba(28,22,16,0.15)`;
        el.style.zIndex = '2';
      });
      el.addEventListener('mouseleave', () => {
        el.style.transform = ''; el.style.boxShadow = ''; el.style.zIndex = '';
      });
    });
  }

  /* ─────────────────────────────────────
   MAGNETIC ELEMENTS
  ───────────────────────────────────── */
  function initMagnetic() {
    $$('[data-mag]').forEach(el => {
      const str = parseFloat(el.dataset.mag || 0.4);
      el.addEventListener('mousemove', e => {
        const r = el.getBoundingClientRect();
        const dx = (e.clientX - r.left - r.width / 2) * str;
        const dy = (e.clientY - r.top - r.height / 2) * str;
        el.style.transform = `translate(${dx}px, ${dy}px)`;
        el.style.transition = 'transform 0.2s';
      });
      el.addEventListener('mouseleave', () => {
        el.style.transform = '';
        el.style.transition = 'transform 0.6s cubic-bezier(0.16,1,0.3,1)';
      });
    });
  }

  /* ─────────────────────────────────────
   NAV
  ───────────────────────────────────── */
  function initNav() {
    const nav = $('#nav');
    if (!nav) return;
    const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    const burger = $('.nav-hamburger');
    const mobileNav = $('.mobile-nav');
    if (burger && mobileNav) {
      burger.addEventListener('click', () => {
        const open = mobileNav.classList.toggle('open');
        burger.classList.toggle('open', open);
        document.body.style.overflow = open ? 'hidden' : '';
      });
      $$('.mobile-nav a').forEach(a => a.addEventListener('click', () => {
        mobileNav.classList.remove('open');
        burger.classList.remove('open');
        document.body.style.overflow = '';
      }));
    }
  }

  /* ─────────────────────────────────────
   FEATURE TABS
  ───────────────────────────────────── */
  function initTabs() {
    $$('.feat-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.tab;
        $$('.feat-tab-btn').forEach(b => b.classList.remove('active'));
        $$('.feat-tab-panel').forEach(p => {
          p.style.display = 'none';
          p.classList.remove('tp-in');
        });
        btn.classList.add('active');
        const panel = $(`[data-panel="${id}"]`);
        if (panel) {
          panel.style.display = 'grid';
          requestAnimationFrame(() => panel.classList.add('tp-in'));
          // re-trigger counters
          $$('[data-count]', panel).forEach(el => {
            el._done = false;
          });
        }
      });
    });
  }

  /* ─────────────────────────────────────
   FILTER (courses)
  ───────────────────────────────────── */
  function initFilter() {
    $$('.filt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.filt-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const f = btn.dataset.filter;
        $$('.course-wrap').forEach((w, i) => {
          const show = f === 'all' || w.dataset.cat === f;
          if (show) {
            w.style.display = 'block';
            w.style.opacity = '0';
            w.style.transform = 'translateY(24px)';
            requestAnimationFrame(() => {
              w.style.transition = `opacity .5s ease ${i * 0.07}s, transform .5s ease ${i * 0.07}s`;
              w.style.opacity = '1';
              w.style.transform = '';
            });
          } else {
            w.style.opacity = '0';
            w.style.transform = 'translateY(-10px)';
            setTimeout(() => { w.style.display = 'none'; }, 350);
          }
        });
      });
    });
  }

  /* ─────────────────────────────────────
   FORM
  ───────────────────────────────────── */
  function initForm() {
    const form = document.getElementById('cForm');
    if (!form) return;
    form.addEventListener('submit', e => {
      e.preventDefault();
      let ok = true;
      $$('[data-req]', form).forEach(field => {
        const g = field.closest('.fl');
        const err = g?.querySelector('.ferr');
        const empty = !field.value.trim();
        const emailErr = field.type === 'email' && field.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
        if (empty || emailErr) {
          field.classList.add('has-err');
          if (err) { err.textContent = emailErr ? 'Enter a valid email.' : 'This field is required.'; err.classList.add('show'); }
          ok = false;
        } else {
          field.classList.remove('has-err');
          err?.classList.remove('show');
        }
      });
      if (ok) {
        const fields = $('.form-fields-inner', form);
        const success = $('.form-success', form);
        if (fields) {
          if (typeof anime !== 'undefined') {
            anime({ targets: fields, opacity: 0, translateY: -20, duration: 400, easing: 'easeInExpo', complete: () => fields.style.display = 'none' });
          } else { fields.style.display = 'none'; }
        }
        setTimeout(() => success?.classList.add('show'), 420);
      }
    });
    $$('.fi', form).forEach(f => f.addEventListener('input', () => {
      f.classList.remove('has-err');
      f.closest('.fl')?.querySelector('.ferr')?.classList.remove('show');
    }));
  }

  /* ─────────────────────────────────────
   NUMBER SCRAMBLE HOVER
  ───────────────────────────────────── */
  function initScramble() {
    $$('[data-scramble]').forEach(el => {
      const orig = el.textContent;
      const chars = '0123456789';
      let iv;
      el.addEventListener('mouseenter', () => {
        let its = 0;
        clearInterval(iv);
        iv = setInterval(() => {
          el.textContent = orig.split('').map((c, i) => {
            if (i < its) return orig[i];
            if (!/\d/.test(c)) return c;
            return chars[Math.floor(Math.random() * chars.length)];
          }).join('');
          if (its >= orig.length) clearInterval(iv);
          its += 0.6;
        }, 45);
      });
    });
  }

  /* ─────────────────────────────────────
   DRAG SCROLL
  ───────────────────────────────────── */
  function initDragScroll() {
    $$('[data-drag]').forEach(el => {
      let down = false, sx, sl;
      el.addEventListener('mousedown', e => {
        down = true; sx = e.pageX - el.offsetLeft; sl = el.scrollLeft;
        el.style.cursor = 'grabbing';
      });
      document.addEventListener('mouseup', () => { down = false; el.style.cursor = ''; });
      el.addEventListener('mousemove', e => {
        if (!down) return;
        e.preventDefault();
        el.scrollLeft = sl - (e.pageX - el.offsetLeft - sx) * 1.5;
      });
    });
  }

  /* ─────────────────────────────────────
   BOOT
  ───────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', () => {
    addGlobalStyle();
    initProgressLine();
    initNav();
    initCounters();
    initTilt();
    initMagnetic();
    initTabs();
    initFilter();
    initForm();
    initDragScroll();
    initScramble();
    initLenis();

    initLoader(() => {
      initHero();
      waitForGSAP(initGSAP);
    });
  });

})();
