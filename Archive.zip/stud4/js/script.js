/* ============================================
   LEARNOVA ACADEMY – PREMIUM ANIMATIONS
   GSAP + ScrollTrigger + Anime.js
   ============================================ */

(function () {
  'use strict';

  // ---- GSAP SETUP ----
  gsap.registerPlugin(ScrollTrigger);

  // ---- NAVBAR ----
  const navbar = document.getElementById('navbar');
  const navToggle = document.getElementById('navToggle');
  const navMobile = document.getElementById('navMobile');

  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  if (navToggle && navMobile) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMobile.classList.toggle('open');
      navMobile.style.display = isOpen ? 'flex' : 'none';
      // Animate hamburger to X
      const spans = navToggle.querySelectorAll('span');
      if (isOpen) {
        anime({ targets: spans[0], translateY: 7, rotate: 45, duration: 300, easing: 'easeInOutQuad' });
        anime({ targets: spans[1], opacity: 0, duration: 200, easing: 'easeInOutQuad' });
        anime({ targets: spans[2], translateY: -7, rotate: -45, duration: 300, easing: 'easeInOutQuad' });
      } else {
        anime({ targets: spans[0], translateY: 0, rotate: 0, duration: 300, easing: 'easeInOutQuad' });
        anime({ targets: spans[1], opacity: 1, duration: 200, easing: 'easeInOutQuad' });
        anime({ targets: spans[2], translateY: 0, rotate: 0, duration: 300, easing: 'easeInOutQuad' });
      }
    });
  }

  // ---- HERO ANIMATIONS ----
  function initHero() {
    if (!document.getElementById('hero')) return;

    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    // Badge entrance
    tl.fromTo('#heroBadge',
      { opacity: 0, y: 20, scale: 0.9 },
      { opacity: 1, y: 0, scale: 1, duration: 0.7 }, 0.3
    );

    // Headline — staggered lines
    const lines = document.querySelectorAll('.hero-headline .line');
    lines.forEach((line, i) => {
      gsap.set(line, { overflow: 'hidden' });
    });

    tl.fromTo('.hero-headline .line',
      { y: '110%', opacity: 0 },
      { y: '0%', opacity: 1, duration: 0.9, stagger: 0.12 }, 0.5
    );

    tl.fromTo('#heroSub',
      { opacity: 0, y: 24 },
      { opacity: 1, y: 0, duration: 0.8 }, 0.9
    );

    tl.fromTo('#heroActions',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.7 }, 1.1
    );

    tl.fromTo('#heroStats .stat-item',
      { opacity: 0, y: 16 },
      { opacity: 1, y: 0, duration: 0.5, stagger: 0.1 }, 1.2
    );

    tl.fromTo('#heroVisual',
      { opacity: 0, x: 40, scale: 0.97 },
      { opacity: 1, x: 0, scale: 1, duration: 1.1, ease: 'power2.out' }, 0.4
    );

    tl.fromTo('.hero-card',
      { opacity: 0, scale: 0.8, y: 20 },
      { opacity: 1, scale: 1, y: 0, duration: 0.6, stagger: 0.2 }, 1.0
    );

    tl.fromTo('.floating-tag',
      { opacity: 0, scale: 0.7 },
      { opacity: 1, scale: 1, duration: 0.4, stagger: 0.15 }, 1.3
    );

    // Hero scroll hint
    tl.fromTo('.hero-scroll-hint',
      { opacity: 0 },
      { opacity: 1, duration: 0.6 }, 1.8
    );
  }

  // ---- ANIMATED COUNTERS ----
  function initCounters() {
    const counters = document.querySelectorAll('.stat-number');
    counters.forEach(el => {
      const target = parseInt(el.getAttribute('data-target')) || 0;
      ScrollTrigger.create({
        trigger: el,
        start: 'top 90%',
        once: true,
        onEnter: () => {
          anime({
            targets: el,
            innerHTML: [0, target],
            round: 1,
            duration: 1800,
            easing: 'easeOutExpo',
            update: function (anim) {
              el.innerHTML = Math.round(parseFloat(el.innerHTML));
            }
          });
        }
      });
    });
  }

  // ---- SECTION REVEAL ANIMATIONS ----
  function initSectionReveals() {
    // Stagger items inside revealed sections
    gsap.utils.toArray('.stagger-item').forEach((el, i) => {
      gsap.fromTo(el,
        { opacity: 0, y: 50, scale: 0.97 },
        {
          opacity: 1, y: 0, scale: 1,
          duration: 0.75,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 88%',
            end: 'bottom 20%',
          }
        }
      );
    });

    // Section tags / titles slide in
    gsap.utils.toArray('.section-tag').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, x: -20 },
        {
          opacity: 1, x: 0, duration: 0.6, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 90%' }
        }
      );
    });

    gsap.utils.toArray('.section-title').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, y: 30 },
        {
          opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 88%' }
        }
      );
    });

    gsap.utils.toArray('.section-sub').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, y: 20 },
        {
          opacity: 1, y: 0, duration: 0.7, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 90%' }
        }
      );
    });

    // Page hero
    gsap.utils.toArray('.page-hero-title').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, y: 40 },
        {
          opacity: 1, y: 0, duration: 1, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 90%' }
        }
      );
    });

    gsap.utils.toArray('.page-hero-sub').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, y: 20 },
        {
          opacity: 1, y: 0, duration: 0.7, ease: 'power3.out', delay: 0.2,
          scrollTrigger: { trigger: el, start: 'top 90%' }
        }
      );
    });
  }

  // ---- PARALLAX IMAGES ----
  function initParallax() {
    gsap.utils.toArray('.parallax-img').forEach(img => {
      gsap.fromTo(img,
        { yPercent: -12 },
        {
          yPercent: 12,
          ease: 'none',
          scrollTrigger: {
            trigger: img,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1.5
          }
        }
      );
    });

    // CTA background parallax
    const ctaBg = document.getElementById('ctaBg');
    if (ctaBg) {
      gsap.to(ctaBg, {
        yPercent: 20,
        ease: 'none',
        scrollTrigger: {
          trigger: ctaBg.closest('.cta-section'),
          start: 'top bottom',
          end: 'bottom top',
          scrub: 2
        }
      });
    }

    // Hero image zoom on scroll
    const heroImg = document.querySelector('.hero-img');
    if (heroImg) {
      gsap.to(heroImg, {
        scale: 1.08,
        ease: 'none',
        scrollTrigger: {
          trigger: '.hero',
          start: 'top top',
          end: 'bottom top',
          scrub: 2
        }
      });
    }
  }

  // ---- LOGO MARQUEE PAUSE ON HOVER ----
  function initMarquee() {
    const marqueeInner = document.querySelector('.marquee-inner');
    if (!marqueeInner) return;
    marqueeInner.addEventListener('mouseenter', () => {
      marqueeInner.style.animationPlayState = 'paused';
    });
    marqueeInner.addEventListener('mouseleave', () => {
      marqueeInner.style.animationPlayState = 'running';
    });
  }

  // ---- PROGRESS BAR ----
  function initProgressBar() {
    const bars = document.querySelectorAll('.progress-bar');
    bars.forEach(bar => {
      const pct = bar.getAttribute('data-progress') || '0';
      ScrollTrigger.create({
        trigger: bar,
        start: 'top 90%',
        once: true,
        onEnter: () => {
          gsap.to(bar, {
            width: pct + '%',
            duration: 1.8,
            ease: 'power3.out',
            delay: 0.5
          });
        }
      });
    });
  }

  // ---- ANIME.JS MICRO INTERACTIONS ----

  // Button hover ripple effect
  function initButtonAnimations() {
    const buttons = document.querySelectorAll('.btn-primary, .btn-sm');

    buttons.forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        anime({
          targets: btn,
          scale: [1, 1.03],
          duration: 200,
          easing: 'easeOutQuad'
        });
      });

      btn.addEventListener('mouseleave', () => {
        anime({
          targets: btn,
          scale: [1.03, 1],
          duration: 250,
          easing: 'easeOutElastic(1, 0.5)'
        });
      });

      // Ripple position tracking
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        btn.style.setProperty('--rx', x + '%');
        btn.style.setProperty('--ry', y + '%');
      });
    });

    // Category card arrow micro animation
    const catCards = document.querySelectorAll('.cat-card');
    catCards.forEach(card => {
      card.addEventListener('mouseenter', () => {
        const arrow = card.querySelector('.cat-arrow');
        if (arrow) {
          anime({
            targets: arrow,
            translateX: [0, 8],
            duration: 300,
            easing: 'easeOutQuad'
          });
        }
      });
      card.addEventListener('mouseleave', () => {
        const arrow = card.querySelector('.cat-arrow');
        if (arrow) {
          anime({
            targets: arrow,
            translateX: [8, 0],
            duration: 300,
            easing: 'easeOutQuad'
          });
        }
      });
    });
  }

  // ---- CARD LIFT ON SCROLL ----
  function initCardScrollEffects() {
    const cards = document.querySelectorAll('.course-card, .testi-card, .value-card, .mentor-profile');
    cards.forEach((card, i) => {
      gsap.fromTo(card,
        { y: 0 },
        {
          y: -4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 85%',
            end: 'top 65%',
            scrub: 1
          }
        }
      );
    });
  }

  // ---- HORIZONTAL SCROLL SECTION ----
  // Courses filter on courses page
  function initFilterBar() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const courseCards = document.querySelectorAll('.course-card[data-category]');
    if (!filterBtns.length || !courseCards.length) return;

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const filter = btn.getAttribute('data-filter');

        courseCards.forEach((card, i) => {
          const category = card.getAttribute('data-category');
          const show = filter === 'all' || category === filter;

          if (show) {
            anime({
              targets: card,
              opacity: [0, 1],
              translateY: [20, 0],
              scale: [0.95, 1],
              duration: 400,
              delay: i * 50,
              easing: 'easeOutQuad',
              begin: () => { card.style.display = 'block'; }
            });
          } else {
            anime({
              targets: card,
              opacity: [1, 0],
              scale: [1, 0.95],
              duration: 250,
              easing: 'easeInQuad',
              complete: () => { card.style.display = 'none'; }
            });
          }
        });

        // Animate the active button
        anime({
          targets: btn,
          scale: [0.95, 1.05, 1],
          duration: 300,
          easing: 'easeOutElastic(1, 0.5)'
        });
      });
    });
  }

  // ---- CONTACT FORM VALIDATION ----
  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const fields = {
      firstName: { el: document.getElementById('firstName'), errEl: document.getElementById('firstNameError'), validate: v => v.trim().length >= 2 ? '' : 'First name must be at least 2 characters.' },
      lastName: { el: document.getElementById('lastName'), errEl: document.getElementById('lastNameError'), validate: v => v.trim().length >= 2 ? '' : 'Last name must be at least 2 characters.' },
      email: { el: document.getElementById('email'), errEl: document.getElementById('emailError'), validate: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Please enter a valid email address.' },
      subject: { el: document.getElementById('subject'), errEl: document.getElementById('subjectError'), validate: v => v ? '' : 'Please select a topic.' },
      message: { el: document.getElementById('message'), errEl: document.getElementById('messageError'), validate: v => v.trim().length >= 10 ? '' : 'Message must be at least 10 characters.' }
    };

    // Live validation
    Object.values(fields).forEach(field => {
      if (!field.el) return;
      field.el.addEventListener('blur', () => {
        const err = field.validate(field.el.value);
        field.errEl.textContent = err;
        field.el.classList.toggle('error', !!err);
      });
      field.el.addEventListener('input', () => {
        if (field.el.classList.contains('error')) {
          const err = field.validate(field.el.value);
          field.errEl.textContent = err;
          field.el.classList.toggle('error', !!err);
        }
      });
    });

    form.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;

      Object.values(fields).forEach(field => {
        if (!field.el) return;
        const err = field.validate(field.el.value);
        field.errEl.textContent = err;
        field.el.classList.toggle('error', !!err);
        if (err) valid = false;
      });

      if (!valid) {
        // Shake invalid fields
        const errorFields = form.querySelectorAll('.error');
        anime({
          targets: errorFields,
          translateX: [0, -8, 8, -6, 6, -4, 4, 0],
          duration: 500,
          easing: 'easeInOutSine'
        });
        return;
      }

      // Submit simulation
      const submitBtn = form.querySelector('.contact-submit');
      const btnText = submitBtn.querySelector('.btn-text');
      const btnLoading = submitBtn.querySelector('.btn-loading');

      btnText.style.display = 'none';
      btnLoading.style.display = 'inline';
      submitBtn.disabled = true;

      setTimeout(() => {
        form.reset();
        submitBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';

        const successMsg = document.getElementById('formSuccess');
        successMsg.style.display = 'block';
        anime({
          targets: successMsg,
          opacity: [0, 1],
          translateY: [-10, 0],
          duration: 400,
          easing: 'easeOutQuad'
        });

        setTimeout(() => {
          anime({
            targets: successMsg,
            opacity: 0,
            duration: 400,
            easing: 'easeInQuad',
            complete: () => { successMsg.style.display = 'none'; }
          });
        }, 5000);
      }, 1500);
    });
  }

  // ---- FLOATING ELEMENTS ANIMATION ----
  function initFloatingElements() {
    const floatingTags = document.querySelectorAll('.floating-tag');
    floatingTags.forEach((tag, i) => {
      anime({
        targets: tag,
        translateY: ['-6px', '6px'],
        duration: 3000 + i * 700,
        loop: true,
        direction: 'alternate',
        easing: 'easeInOutSine',
        delay: i * 400
      });
    });
  }

  // ---- SMOOTH SCROLL FOR ANCHOR LINKS ----
  function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', e => {
        const href = anchor.getAttribute('href');
        if (href === '#') return;
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          gsap.to(window, {
            duration: 1.2,
            scrollTo: { y: target, offsetY: 80 },
            ease: 'power3.inOut'
          });
        }
      });
    });
  }

  // ---- CTA SECTION ANIMATION ----
  function initCTASection() {
    const ctaSections = document.querySelectorAll('.cta-section');
    ctaSections.forEach(section => {
      gsap.fromTo(section.querySelector('.cta-container'),
        { opacity: 0, y: 50 },
        {
          opacity: 1, y: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%'
          }
        }
      );
    });
  }

  // ---- FOOTER ANIMATION ----
  function initFooter() {
    gsap.fromTo('.footer-brand',
      { opacity: 0, x: -30 },
      {
        opacity: 1, x: 0, duration: 0.8, ease: 'power3.out',
        scrollTrigger: { trigger: '.footer', start: 'top 90%' }
      }
    );

    gsap.fromTo('.footer-col',
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power3.out',
        scrollTrigger: { trigger: '.footer', start: 'top 85%' }
      }
    );
  }

  // ---- GSAP SCROLL-DRIVEN TEXT REVEAL ----
  function initTextReveal() {
    gsap.utils.toArray('.features-intro h2').forEach(el => {
      gsap.fromTo(el,
        { backgroundPositionX: '0%' },
        {
          backgroundPositionX: '100%',
          scrollTrigger: {
            trigger: el,
            start: 'top 80%',
            end: 'bottom 40%',
            scrub: 1
          }
        }
      );
    });
  }

  // ---- NAVBAR PROGRESS INDICATOR ----
  function initScrollProgress() {
    const progress = document.createElement('div');
    progress.style.cssText = `
      position: fixed; top: 0; left: 0; right: 0;
      height: 3px; z-index: 9999;
      background: linear-gradient(to right, #3B6EF5, #2EC37C);
      transform-origin: left;
      transform: scaleX(0);
      transition: transform 0.1s;
      pointer-events: none;
    `;
    document.body.appendChild(progress);

    gsap.to(progress, {
      scaleX: 1,
      ease: 'none',
      scrollTrigger: {
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0
      }
    });

    ScrollTrigger.create({
      start: 'top top',
      end: 'bottom bottom',
      onUpdate: (self) => {
        progress.style.transform = `scaleX(${self.progress})`;
      }
    });
  }

  // ---- ABOUT PAGE ----
  function initAboutPage() {
    const aboutImgCol = document.querySelector('.about-img-col');
    if (!aboutImgCol) return;

    gsap.fromTo('.about-img-col',
      { opacity: 0, x: -50, rotate: -2 },
      {
        opacity: 1, x: 0, rotate: 0, duration: 1, ease: 'power3.out',
        scrollTrigger: { trigger: '.about-split', start: 'top 80%' }
      }
    );
  }

  // ---- INIT ALL ----
  function init() {
    initHero();
    initCounters();
    initSectionReveals();
    initParallax();
    initMarquee();
    initProgressBar();
    initButtonAnimations();
    initCardScrollEffects();
    initFilterBar();
    initContactForm();
    initFloatingElements();
    initCTASection();
    initFooter();
    initTextReveal();
    initScrollProgress();
    initAboutPage();
  }

  // Wait for DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Refresh ScrollTrigger after images load
  window.addEventListener('load', () => {
    ScrollTrigger.refresh();
    // Animate progress bars after page load
    document.querySelectorAll('.progress-bar').forEach(bar => {
      const pct = bar.getAttribute('data-progress') || '0';
      gsap.to(bar, {
        width: pct + '%',
        duration: 1.8,
        ease: 'power3.out',
        delay: 1.5
      });
    });
  });

})();
