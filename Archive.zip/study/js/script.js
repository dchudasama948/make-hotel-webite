/* ═══════════════════════════════════════════════════
   NEXLEARN — Main JavaScript
   ═══════════════════════════════════════════════════ */

'use strict';

/* ─── Navigation ─────────────────────────────────── */
(function initNav() {
  const nav = document.querySelector('.nav');
  const menuBtn = document.querySelector('.nav-menu-btn');
  const drawer = document.querySelector('.nav-drawer');

  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  if (menuBtn && drawer) {
    menuBtn.addEventListener('click', () => {
      const isOpen = menuBtn.classList.toggle('open');
      drawer.classList.toggle('open', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    drawer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        menuBtn.classList.remove('open');
        drawer.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  // Active nav link
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .nav-drawer a').forEach(a => {
    const href = a.getAttribute('href');
    if (href && (href === path || (path === 'index.html' && href === 'index.html'))) {
      a.classList.add('active');
    }
  });
})();

/* ─── Scroll Reveal ──────────────────────────────── */
(function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  els.forEach(el => io.observe(el));
})();

/* ─── Counter Animations ─────────────────────────── */
(function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.count);
      const suffix = el.dataset.suffix || '';
      const duration = 1800;
      const start = performance.now();
      const isFloat = target % 1 !== 0;

      function tick(now) {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const value = target * eased;
        el.textContent = (isFloat ? value.toFixed(1) : Math.floor(value)) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      io.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(c => io.observe(c));
})();

/* ─── Feature Tabs ───────────────────────────────── */
(function initFeatureTabs() {
  const tabs = document.querySelectorAll('.feature-tab');
  const images = document.querySelectorAll('.feature-panel-img');
  if (!tabs.length) return;

  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      if (images.length) {
        images.forEach(img => img.classList.remove('visible-panel'));
        if (images[i]) images[i].classList.add('visible-panel');
      }
    });
  });
})();

/* ─── FAQ Accordion ──────────────────────────────── */
(function initFAQ() {
  document.querySelectorAll('.faq-item').forEach(item => {
    const btn = item.querySelector('.faq-q');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(o => o.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });
})();

/* ─── Contact Form Validation ────────────────────── */
(function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  function validateField(group, input) {
    const val = input.value.trim();
    const type = input.type;
    let valid = val.length > 0;
    if (type === 'email') valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
    group.classList.toggle('error', !valid);
    return valid;
  }

  form.querySelectorAll('input, textarea').forEach(input => {
    input.addEventListener('blur', () => {
      validateField(input.closest('.form-group'), input);
    });
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    let allValid = true;
    form.querySelectorAll('input, textarea').forEach(input => {
      const group = input.closest('.form-group');
      if (group && !validateField(group, input)) allValid = false;
    });

    if (allValid) {
      const success = document.getElementById('formSuccess');
      if (success) {
        success.style.display = 'block';
        form.reset();
        setTimeout(() => { success.style.display = 'none'; }, 5000);
      }
    }
  });
})();

/* ─── Smooth Anchor Scrolling ─────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 80;
      window.scrollTo({ top: target.offsetTop - offset, behavior: 'smooth' });
    }
  });
});

/* ─── Parallax Hero Background ───────────────────── */
(function initParallax() {
  const mesh = document.querySelector('.mesh-bg');
  if (!mesh || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    mesh.style.transform = `translateY(${y * 0.3}px)`;
  }, { passive: true });
})();
