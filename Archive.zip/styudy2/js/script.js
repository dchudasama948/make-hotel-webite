/* =========================================
   NEXLEARN — Main Script
   Scroll Animations, Counters, Cursor, etc.
   ========================================= */

document.addEventListener('DOMContentLoaded', () => {

  // ====== PAGE LOADER ======
  const loader = document.querySelector('.loader');
  if (loader) {
    setTimeout(() => {
      loader.classList.add('hidden');
      document.body.style.overflow = '';
      initScrollReveal();
    }, 2000);
  } else {
    initScrollReveal();
  }
  document.body.style.overflow = 'hidden';

  // ====== CUSTOM CURSOR ======
  const cursor = document.querySelector('.cursor');
  const follower = document.querySelector('.cursor-follower');
  let mouseX = 0, mouseY = 0;
  let followerX = 0, followerY = 0;

  if (cursor && follower) {
    document.addEventListener('mousemove', e => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursor.style.left = mouseX + 'px';
      cursor.style.top = mouseY + 'px';
    });

    function animateFollower() {
      followerX += (mouseX - followerX) * 0.1;
      followerY += (mouseY - followerY) * 0.1;
      follower.style.left = followerX + 'px';
      follower.style.top = followerY + 'px';
      requestAnimationFrame(animateFollower);
    }
    animateFollower();

    const hoverEls = document.querySelectorAll('a, button, [data-cursor-hover]');
    hoverEls.forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.classList.add('hovering');
        follower.classList.add('hovering');
      });
      el.addEventListener('mouseleave', () => {
        cursor.classList.remove('hovering');
        follower.classList.remove('hovering');
      });
    });

    document.addEventListener('mouseleave', () => {
      cursor.style.opacity = '0';
      follower.style.opacity = '0';
    });
    document.addEventListener('mouseenter', () => {
      cursor.style.opacity = '1';
      follower.style.opacity = '1';
    });
  }

  // ====== NAVBAR SCROLL ======
  const nav = document.querySelector('nav');
  if (nav) {
    const handleScroll = () => {
      nav.classList.toggle('scrolled', window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  // ====== MOBILE NAV ======
  const navToggle = document.querySelector('.nav-toggle');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileClose = document.querySelector('.mobile-nav-close');

  if (navToggle && mobileNav) {
    navToggle.addEventListener('click', () => {
      mobileNav.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
    mobileClose?.addEventListener('click', closeMobileNav);
    mobileNav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMobileNav));

    function closeMobileNav() {
      mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    }
  }

  // ====== SCROLL REVEAL ======
  function initScrollReveal() {
    const revealEls = document.querySelectorAll('[data-reveal], [data-stagger]');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const delay = el.dataset.delay || 0;
          setTimeout(() => {
            el.classList.add('revealed');
          }, parseInt(delay));
          observer.unobserve(el);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -60px 0px'
    });

    revealEls.forEach(el => observer.observe(el));

    // Hero elements reveal immediately
    const heroEls = document.querySelectorAll('.hero [data-reveal], .hero [data-stagger]');
    heroEls.forEach((el, i) => {
      setTimeout(() => el.classList.add('revealed'), 200 + i * 120);
    });
  }

  // ====== COUNTER ANIMATION ======
  function animateCounter(el) {
    if (el.dataset.animated) return;
    el.dataset.animated = 'true';

    const target = parseFloat(el.dataset.target);
    const duration = parseInt(el.dataset.duration || 2000);
    const decimals = el.dataset.decimals ? parseInt(el.dataset.decimals) : 0;
    const start = performance.now();

    function easeOut(t) {
      return 1 - Math.pow(1 - t, 3);
    }

    function update(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const value = target * easeOut(progress);

      if (decimals > 0) {
        el.textContent = value.toFixed(decimals);
      } else {
        el.textContent = Math.round(value).toLocaleString();
      }

      if (progress < 1) requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
  }

  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-counter]').forEach(el => {
    counterObserver.observe(el);
  });

  // ====== FEATURES TABS ======
  const featTabs = document.querySelectorAll('.feat-tab');
  const featPanels = document.querySelectorAll('.feat-panel');

  featTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;

      featTabs.forEach(t => t.classList.remove('active'));
      featPanels.forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const panel = document.querySelector(`.feat-panel[data-panel="${target}"]`);
      if (panel) {
        panel.classList.add('active');
        // re-trigger reveals in panel
        panel.querySelectorAll('[data-reveal]').forEach(el => {
          el.classList.remove('revealed');
          setTimeout(() => el.classList.add('revealed'), 50);
        });
      }
    });
  });

  // ====== PARALLAX HERO IMAGE ======
  const heroImg = document.querySelector('.hero-image-float');
  if (heroImg) {
    window.addEventListener('scroll', () => {
      const scrolled = window.scrollY;
      heroImg.style.transform = `translateY(calc(-50% + ${scrolled * 0.15}px))`;
    }, { passive: true });
  }

  // ====== CONTACT FORM VALIDATION ======
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;

      const fields = contactForm.querySelectorAll('[data-required]');
      fields.forEach(field => {
        const err = field.closest('.form-group')?.querySelector('.form-error');
        if (!field.value.trim()) {
          field.classList.add('error');
          if (err) err.classList.add('show');
          valid = false;
        } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
          field.classList.add('error');
          if (err) { err.textContent = 'Please enter a valid email address.'; err.classList.add('show'); }
          valid = false;
        } else {
          field.classList.remove('error');
          if (err) err.classList.remove('show');
        }
      });

      if (valid) {
        const formContent = contactForm.querySelector('.form-fields');
        const formSuccess = contactForm.querySelector('.form-success');
        if (formContent) formContent.style.display = 'none';
        if (formSuccess) formSuccess.classList.add('show');
      }
    });

    // Live validation clear
    contactForm.querySelectorAll('.form-control').forEach(field => {
      field.addEventListener('input', () => {
        field.classList.remove('error');
        const err = field.closest('.form-group')?.querySelector('.form-error');
        if (err) err.classList.remove('show');
      });
    });
  }

  // ====== SMOOTH SCROLL FOR ANCHORS ======
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ====== TEXT CHAR SPLIT ANIMATION ======
  document.querySelectorAll('[data-split]').forEach(el => {
    const text = el.textContent;
    el.innerHTML = text.split('').map((char, i) => {
      if (char === ' ') return ' ';
      return `<span style="display:inline-block; transition-delay:${i * 0.025}s">${char}</span>`;
    }).join('');

    const charObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('span').forEach(span => {
            span.style.opacity = '1';
            span.style.transform = 'translateY(0)';
          });
          charObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });

    el.querySelectorAll('span').forEach(span => {
      span.style.opacity = '0';
      span.style.transform = 'translateY(30px)';
      span.style.transition = 'opacity 0.5s, transform 0.5s';
    });
    charObserver.observe(el);
  });

  // ====== HORIZONTAL SCROLL SECTION ======
  const hScrollSection = document.querySelector('.h-scroll-section');
  if (hScrollSection) {
    const track = hScrollSection.querySelector('.h-scroll-track');
    window.addEventListener('scroll', () => {
      const rect = hScrollSection.getBoundingClientRect();
      const progress = -rect.top / (rect.height - window.innerHeight);
      if (progress >= 0 && progress <= 1) {
        const maxScroll = track.scrollWidth - window.innerWidth;
        track.style.transform = `translateX(-${progress * maxScroll}px)`;
      }
    }, { passive: true });
  }

  // ====== CARD MAGNETIC EFFECT ======
  document.querySelectorAll('.cat-card, .course-card, .mentor-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width - 0.5) * 8;
      const y = ((e.clientY - rect.top) / rect.height - 0.5) * 8;
      card.style.transform = `translateY(-6px) rotateX(${-y}deg) rotateY(${x}deg)`;
      card.style.transformStyle = 'preserve-3d';
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
      card.style.transformStyle = '';
    });
  });

  // ====== HEADER LOGO HOVER ======
  const navLogo = document.querySelector('.nav-logo');
  if (navLogo) {
    navLogo.addEventListener('mouseenter', () => {
      navLogo.style.letterSpacing = '-0.5px';
    });
    navLogo.addEventListener('mouseleave', () => {
      navLogo.style.letterSpacing = '-1px';
    });
  }

});
