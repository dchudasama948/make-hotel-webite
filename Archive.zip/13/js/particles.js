/* ============================================
   LEARNVERSE — Particle Systems (Canvas 2D)
   ============================================ */

// ── HERO NEURAL NETWORK CANVAS ──────────────────────────────
function initHeroCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H, particles = [], mouse = { x: -999, y: -999 };
  let animFrame;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }

  function createParticles() {
    particles = [];
    const count = Math.min(120, Math.floor((W * H) / 8000));
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.2 + 0.4,
        baseVx: 0, baseVy: 0,
        pulse: Math.random() * Math.PI * 2,
        pulseSpeed: 0.01 + Math.random() * 0.015
      });
      particles[particles.length - 1].baseVx = particles[particles.length - 1].vx;
      particles[particles.length - 1].baseVy = particles[particles.length - 1].vy;
    }
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach((p, i) => {
      // Mouse repel
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 120) {
        const force = (120 - dist) / 120;
        p.vx += (dx / dist) * force * 0.3;
        p.vy += (dy / dist) * force * 0.3;
      }

      // Dampen toward base velocity
      p.vx += (p.baseVx - p.vx) * 0.03;
      p.vy += (p.baseVy - p.vy) * 0.03;

      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0) p.x = W;
      if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H;
      if (p.y > H) p.y = 0;

      p.pulse += p.pulseSpeed;
      const pulseFactor = 0.8 + Math.sin(p.pulse) * 0.2;

      // Draw dot
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * pulseFactor, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${0.25 + Math.sin(p.pulse) * 0.1})`;
      ctx.fill();

      // Draw connections
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const ex = p.x - q.x, ey = p.y - q.y;
        const edist = Math.sqrt(ex * ex + ey * ey);
        if (edist < 130) {
          const alpha = (1 - edist / 130) * 0.055;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(79,142,247,${alpha})`;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }
    });

    animFrame = requestAnimationFrame(draw);
  }

  resize();
  createParticles();
  draw();

  window.addEventListener('resize', () => { resize(); createParticles(); });
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  canvas.addEventListener('mouseleave', () => { mouse.x = -999; mouse.y = -999; });

  return { destroy: () => cancelAnimationFrame(animFrame) };
}

// ── PARTICLE CONVERGENCE CANVAS (Section 3) ──────────────────
function initConvergenceCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  let particles = [];
  let scrollProgress = 0;
  let animFrame;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    buildParticles();
  }

  function buildParticles() {
    particles = [];
    const count = 200;
    const cx = W / 2, cy = H / 2;
    const radius = Math.min(W, H) * 0.28;

    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      // Home position = on a circle
      const homeX = cx + Math.cos(angle) * radius;
      const homeY = cy + Math.sin(angle) * radius;
      // Scatter position = random
      const scatterX = Math.random() * W;
      const scatterY = Math.random() * H;

      particles.push({
        homeX, homeY,
        scatterX, scatterY,
        x: scatterX, y: scatterY,
        r: Math.random() * 1.5 + 0.5,
        hue: 210 + Math.random() * 40,
        angle
      });
    }
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // progress: 0→0.5 = scatter out, 0.5→1 = converge to circle
    let t;
    if (scrollProgress < 0.5) {
      t = 1 - (scrollProgress / 0.5); // 1→0 (scatter)
    } else {
      t = (scrollProgress - 0.5) / 0.5; // 0→1 (converge)
    }

    // Easing
    const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

    particles.forEach((p, i) => {
      p.x = p.scatterX + (p.homeX - p.scatterX) * eased;
      p.y = p.scatterY + (p.homeY - p.scatterY) * eased;

      const brightness = 0.2 + eased * 0.7;
      const size = p.r * (0.5 + eased * 1.5);

      ctx.beginPath();
      ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(79,142,247,${brightness})`;
      ctx.fill();

      // Glow at convergence
      if (eased > 0.7) {
        const glowAlpha = (eased - 0.7) / 0.3 * 0.15;
        ctx.beginPath();
        ctx.arc(p.x, p.y, size * 3, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(79,142,247,${glowAlpha})`;
        ctx.fill();
      }
    });

    // Center glow at full convergence
    if (eased > 0.8) {
      const cx = W / 2, cy = H / 2;
      const alpha = (eased - 0.8) / 0.2 * 0.12;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.min(W, H) * 0.35);
      grad.addColorStop(0, `rgba(79,142,247,${alpha})`);
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    }

    animFrame = requestAnimationFrame(draw);
  }

  resize();
  draw();
  window.addEventListener('resize', resize);

  return {
    setProgress: (p) => { scrollProgress = p; },
    destroy: () => cancelAnimationFrame(animFrame)
  };
}
