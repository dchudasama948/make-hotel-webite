/* ============================================
   LEARNVERSE — Animations (GSAP + Three.js + Anime.js)
   ============================================ */

gsap.registerPlugin(ScrollTrigger);

/* ── UTILITY ──────────────────────────────── */
function lerp(a, b, t) { return a + (b - a) * t; }

/* ============================================
   HERO ENTRANCE
   ============================================ */
function initHeroEntrance() {
  // Eyebrow
  gsap.to('.hero-eyebrow', {
    opacity: 1, y: 0, duration: 0.6, delay: 0.3, ease: 'power2.out'
  });

  // Words slide up
  const words = document.querySelectorAll('.hero-h1 .word');
  words.forEach((word, i) => {
    gsap.to(word, {
      y: '0%',
      duration: 0.75,
      delay: 0.5 + i * 0.08,
      ease: 'power4.out'
    });
  });

  // Sub + actions
  gsap.to('.hero-sub', {
    opacity: 1, y: 0, duration: 0.7, delay: 0.85, ease: 'power2.out'
  });
  gsap.to('.hero-actions', {
    opacity: 1, y: 0, duration: 0.7, delay: 1.0, ease: 'power2.out'
  });
  gsap.to('.scroll-hint', {
    opacity: 1, duration: 0.6, delay: 1.4, ease: 'power2.out'
  });
}

/* ============================================
   HERO → THREE.JS CAMERA SCROLL
   ============================================ */
function initHeroScrollCamera(threeObj) {
  if (!threeObj) return;
  gsap.to({}, {
    scrollTrigger: {
      trigger: '#hero',
      start: 'top top',
      end: 'bottom top',
      scrub: 1.5,
      onUpdate: (self) => {
        if (threeObj.setScrollProgress) {
          threeObj.setScrollProgress(self.progress);
        }
      }
    }
  });
}

/* ============================================
   THREE.JS NEURAL NETWORK (Hero BG)
   ============================================ */
function initThreeHero(containerId) {
  const container = document.getElementById(containerId);
  if (!container || !window.THREE) return null;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, container.offsetWidth / container.offsetHeight, 0.1, 1000);
  camera.position.z = 5;

  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.offsetWidth, container.offsetHeight);
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);
  renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';

  // Create particles
  const count = 180;
  const positions = new Float32Array(count * 3);
  const velocities = [];
  const particleData = [];

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 14;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 8;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 4;
    velocities.push({
      x: (Math.random() - 0.5) * 0.008,
      y: (Math.random() - 0.5) * 0.008,
      z: (Math.random() - 0.5) * 0.004
    });
    particleData.push({ x: positions[i * 3], y: positions[i * 3 + 1], z: positions[i * 3 + 2] });
  }

  const pGeom = new THREE.BufferGeometry();
  pGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const pMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.06, transparent: true, opacity: 0.6 });
  const points = new THREE.Points(pGeom, pMat);
  scene.add(points);

  // Lines between nearby particles
  const linePositions = [];
  const lineGeom = new THREE.BufferGeometry();
  const lineMat = new THREE.LineBasicMaterial({
    color: 0x4F8EF7, transparent: true, opacity: 0.07, vertexColors: false
  });
  const maxConnections = 400;
  const linePos = new Float32Array(maxConnections * 6);
  lineGeom.setAttribute('position', new THREE.BufferAttribute(linePos, 3));
  const lines = new THREE.LineSegments(lineGeom, lineMat);
  scene.add(lines);

  let scrollProgress = 0;
  let mouseX = 0, mouseY = 0;
  let frame;

  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = -(e.clientY / window.innerHeight - 0.5) * 2;
  });

  function animate() {
    frame = requestAnimationFrame(animate);

    const pos = pGeom.attributes.position.array;
    for (let i = 0; i < count; i++) {
      pos[i * 3] += velocities[i].x;
      pos[i * 3 + 1] += velocities[i].y;
      pos[i * 3 + 2] += velocities[i].z;
      if (Math.abs(pos[i * 3]) > 7) velocities[i].x *= -1;
      if (Math.abs(pos[i * 3 + 1]) > 4) velocities[i].y *= -1;
      if (Math.abs(pos[i * 3 + 2]) > 2) velocities[i].z *= -1;
    }
    pGeom.attributes.position.needsUpdate = true;

    // Update lines
    let lineIdx = 0;
    const lp = lineGeom.attributes.position.array;
    for (let i = 0; i < count && lineIdx < maxConnections; i++) {
      for (let j = i + 1; j < count && lineIdx < maxConnections; j++) {
        const dx = pos[i * 3] - pos[j * 3];
        const dy = pos[i * 3 + 1] - pos[j * 3 + 1];
        const dz = pos[i * 3 + 2] - pos[j * 3 + 2];
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 2.2) {
          lp[lineIdx * 6] = pos[i * 3];
          lp[lineIdx * 6 + 1] = pos[i * 3 + 1];
          lp[lineIdx * 6 + 2] = pos[i * 3 + 2];
          lp[lineIdx * 6 + 3] = pos[j * 3];
          lp[lineIdx * 6 + 4] = pos[j * 3 + 1];
          lp[lineIdx * 6 + 5] = pos[j * 3 + 2];
          lineIdx++;
        }
      }
    }
    lineGeom.attributes.position.needsUpdate = true;
    lineGeom.setDrawRange(0, lineIdx * 2);

    // Camera drift + scroll zoom
    camera.position.x = lerp(camera.position.x, mouseX * 0.8, 0.04);
    camera.position.y = lerp(camera.position.y, mouseY * 0.5, 0.04);
    camera.position.z = 5 + scrollProgress * 3;
    pMat.opacity = Math.max(0, 0.6 - scrollProgress * 0.8);
    lineMat.opacity = Math.max(0, 0.07 - scrollProgress * 0.1);

    renderer.render(scene, camera);
  }

  animate();

  window.addEventListener('resize', () => {
    camera.aspect = container.offsetWidth / container.offsetHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.offsetWidth, container.offsetHeight);
  });

  return {
    setScrollProgress: (p) => { scrollProgress = p; },
    destroy: () => { cancelAnimationFrame(frame); renderer.dispose(); }
  };
}

/* ============================================
   THREE.JS FLOATING BOOKS (Pinned Section 1)
   ============================================ */
function initThreeBooks(containerId) {
  const container = document.getElementById(containerId);
  if (!container || !window.THREE) return null;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, container.offsetWidth / container.offsetHeight, 0.1, 100);
  camera.position.z = 7;

  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.offsetWidth, container.offsetHeight);
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);
  renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';

  // Create book-like flat panels
  const books = [];
  const colors = [0x4F8EF7, 0x3a7be0, 0x6ea8ff, 0x2156b5, 0x8abcff, 0x4F8EF7];
  const bookData = [
    { w: 1.2, h: 1.7, d: 0.12 }, { w: 1.4, h: 1.9, d: 0.1 },
    { w: 1.0, h: 1.6, d: 0.15 }, { w: 1.3, h: 1.8, d: 0.11 },
    { w: 1.1, h: 1.65, d: 0.13 }, { w: 1.25, h: 1.75, d: 0.09 }
  ];

  bookData.forEach((bd, i) => {
    const geom = new THREE.BoxGeometry(bd.w, bd.h, bd.d);
    const mat = new THREE.MeshPhongMaterial({
      color: colors[i],
      transparent: true,
      opacity: 0.85,
      shininess: 80
    });
    const mesh = new THREE.Mesh(geom, mat);

    // Scatter start position
    const angle = (i / bookData.length) * Math.PI * 2;
    const r = 3.5 + Math.random() * 1.5;
    mesh.userData.scatterX = Math.cos(angle) * r;
    mesh.userData.scatterY = Math.sin(angle) * r + (Math.random() - 0.5) * 2;
    mesh.userData.scatterZ = (Math.random() - 0.5) * 3;
    mesh.userData.scatterRX = (Math.random() - 0.5) * 1.5;
    mesh.userData.scatterRY = (Math.random() - 0.5) * 1.5;

    // Grid end position
    const col = i % 3, row = Math.floor(i / 3);
    mesh.userData.homeX = (col - 1) * 1.6;
    mesh.userData.homeY = (row - 0.5) * 2.1;
    mesh.userData.homeZ = 0;

    mesh.position.set(mesh.userData.scatterX, mesh.userData.scatterY, mesh.userData.scatterZ);
    mesh.rotation.set(mesh.userData.scatterRX, mesh.userData.scatterRY, 0);

    scene.add(mesh);
    books.push(mesh);
  });

  // Lights
  const ambient = new THREE.AmbientLight(0xffffff, 0.3);
  scene.add(ambient);
  const point = new THREE.PointLight(0x4F8EF7, 2, 20);
  point.position.set(3, 3, 5);
  scene.add(point);
  const point2 = new THREE.PointLight(0xffffff, 1, 15);
  point2.position.set(-3, -2, 5);
  scene.add(point2);

  let scrollProgress = 0;
  let frame;

  function easeInOut(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  function animate() {
    frame = requestAnimationFrame(animate);
    const t = easeInOut(Math.max(0, Math.min(1, scrollProgress)));

    books.forEach((book, i) => {
      book.position.x = lerp(book.userData.scatterX, book.userData.homeX, t);
      book.position.y = lerp(book.userData.scatterY, book.userData.homeY, t);
      book.position.z = lerp(book.userData.scatterZ, book.userData.homeZ, t);
      book.rotation.x = lerp(book.userData.scatterRX, 0, t);
      book.rotation.y = lerp(book.userData.scatterRY, -0.1, t) + Math.sin(Date.now() * 0.001 + i) * 0.02;
    });

    camera.rotation.y = Math.sin(Date.now() * 0.0003) * 0.05;
    renderer.render(scene, camera);
  }

  animate();
  window.addEventListener('resize', () => {
    camera.aspect = container.offsetWidth / container.offsetHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.offsetWidth, container.offsetHeight);
  });

  return {
    setProgress: (p) => { scrollProgress = p; },
    destroy: () => { cancelAnimationFrame(frame); renderer.dispose(); }
  };
}

/* ============================================
   THREE.JS ORBIT RINGS (Pinned Section 4)
   ============================================ */
function initThreeOrbits(containerId) {
  const container = document.getElementById(containerId);
  if (!container || !window.THREE) return null;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, container.offsetWidth / container.offsetHeight, 0.1, 100);
  camera.position.z = 9;
  camera.position.y = 1;
  camera.rotation.x = -0.1;

  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.offsetWidth, container.offsetHeight);
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);
  renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';

  const ringData = [
    { radius: 1.2, tilt: 0,    color: 0x4F8EF7, orbs: 3, speed: 1.0 },
    { radius: 2.1, tilt: 0.4,  color: 0x6ea8ff, orbs: 4, speed: 0.7 },
    { radius: 3.0, tilt: 0.7,  color: 0x3a7be0, orbs: 5, speed: 0.5 },
    { radius: 3.9, tilt: 1.0,  color: 0x8abcff, orbs: 6, speed: 0.35 }
  ];

  const rings = [];
  ringData.forEach((rd) => {
    const group = new THREE.Group();
    group.rotation.x = rd.tilt;

    // Ring line
    const pts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * rd.radius, Math.sin(a) * rd.radius, 0));
    }
    const ringGeom = new THREE.BufferGeometry().setFromPoints(pts);
    const ringMat = new THREE.LineBasicMaterial({ color: rd.color, transparent: true, opacity: 0.25 });
    group.add(new THREE.Line(ringGeom, ringMat));

    // Orbiting spheres
    const orbs = [];
    for (let i = 0; i < rd.orbs; i++) {
      const sg = new THREE.SphereGeometry(0.09, 8, 8);
      const sm = new THREE.MeshPhongMaterial({ color: rd.color, emissive: rd.color, emissiveIntensity: 0.5 });
      const sphere = new THREE.Mesh(sg, sm);
      sphere.userData.baseAngle = (i / rd.orbs) * Math.PI * 2;
      sphere.userData.radius = rd.radius;
      group.add(sphere);
      orbs.push(sphere);
    }

    scene.add(group);
    rings.push({ group, orbs, rd });
  });

  const ambient = new THREE.AmbientLight(0xffffff, 0.2);
  scene.add(ambient);
  const pt = new THREE.PointLight(0x4F8EF7, 3, 30);
  pt.position.set(0, 0, 5);
  scene.add(pt);

  let scrollProgress = 0;
  let time = 0;
  let frame;

  function animate() {
    frame = requestAnimationFrame(animate);
    time += 0.016;
    const speedMult = 0.5 + scrollProgress * 4;

    rings.forEach(({ group, orbs, rd }) => {
      group.rotation.z = time * rd.speed * 0.3 * speedMult * 0.1;
      orbs.forEach((orb) => {
        const angle = orb.userData.baseAngle + time * rd.speed * speedMult * 0.5;
        orb.position.x = Math.cos(angle) * orb.userData.radius;
        orb.position.y = Math.sin(angle) * orb.userData.radius;
      });
    });

    // At full scroll: tilt camera for dramatic effect
    camera.position.y = lerp(1, -0.5, scrollProgress);
    camera.rotation.x = lerp(-0.1, 0.3, scrollProgress);

    renderer.render(scene, camera);
  }

  animate();
  window.addEventListener('resize', () => {
    camera.aspect = container.offsetWidth / container.offsetHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.offsetWidth, container.offsetHeight);
  });

  return {
    setProgress: (p) => { scrollProgress = p; },
    destroy: () => { cancelAnimationFrame(frame); renderer.dispose(); }
  };
}

/* ============================================
   DOT GRID (Pinned Section 2)
   ============================================ */
function initDotGrid(section) {
  const dots = section.querySelectorAll('.dot');
  const cx = 3.5, cy = 3.5; // center of 8×8 grid (0-indexed)

  dots.forEach((dot, i) => {
    const row = Math.floor(i / 8), col = i % 8;
    const distFromCenter = Math.sqrt(Math.pow(col - cx, 2) + Math.pow(row - cy, 2));
    dot.dataset.delay = distFromCenter / 7;
  });

  return {
    setProgress: (p) => {
      dots.forEach((dot, i) => {
        const delay = parseFloat(dot.dataset.delay);
        const localP = Math.max(0, Math.min(1, (p - delay * 0.4) / 0.6));
        const scale = 1 + localP * 1.8;
        const opacity = 0.08 + localP * 0.85;
        const alpha = localP;
        dot.style.transform = `scale(${scale})`;
        dot.style.opacity = opacity;
        dot.style.background = `rgba(79,142,247,${alpha})`;
        dot.style.boxShadow = localP > 0.5 ? `0 0 ${localP * 12}px rgba(79,142,247,${localP * 0.5})` : 'none';
      });
    }
  };
}

/* ============================================
   SVG PATH DRAW (Pinned Section 3)
   ============================================ */
function initSVGPaths(section) {
  const paths = section.querySelectorAll('.draw-path');
  const milestoneIcons = section.querySelectorAll('.milestone-icon');

  const lengths = [];
  paths.forEach((path) => {
    const len = path.getTotalLength();
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    lengths.push(len);
  });

  return {
    setProgress: (p) => {
      paths.forEach((path, i) => {
        const len = lengths[i];
        const delay = i * 0.12;
        const localP = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
        path.style.strokeDashoffset = len * (1 - localP);
        path.style.opacity = 0.3 + localP * 0.7;
      });

      // Milestone icons pop in
      milestoneIcons.forEach((icon, i) => {
        const threshold = 0.2 + i * 0.25;
        const localP = Math.max(0, Math.min(1, (p - threshold) / 0.1));
        icon.style.transform = `scale(${localP})`;
        icon.style.opacity = localP;
      });
    }
  };
}

/* ============================================
   PINNED SECTION FACTORY
   ============================================ */
function createPinnedSection(sectionEl, animObj, textSelector) {
  const textEl = sectionEl.querySelector(textSelector || '.pinned-content');
  let textShown = false;

  ScrollTrigger.create({
    trigger: sectionEl,
    start: 'top top',
    end: '+=200%',
    pin: true,
    scrub: 1,
    onUpdate: (self) => {
      if (animObj && animObj.setProgress) animObj.setProgress(self.progress);

      // Fade in text at 25% through
      if (textEl) {
        const textP = Math.max(0, Math.min(1, (self.progress - 0.2) / 0.15));
        textEl.style.opacity = textP;
        textEl.style.transform = `translateY(${(1 - textP) * 30}px)`;
      }
    }
  });
}

/* ============================================
   STATS COUNT-UP
   ============================================ */
function initStats() {
  const stats = [
    { selector: '#stat-courses', target: 26, suffix: '+' },
    { selector: '#stat-mentors', target: 20, suffix: '+' },
    { selector: '#stat-learners', target: 50, suffix: 'K+' },
    { selector: '#stat-rating', target: 4.9, suffix: '★', decimals: 1 }
  ];

  ScrollTrigger.create({
    trigger: '.stats-section',
    start: 'top 80%',
    once: true,
    onEnter: () => {
      stats.forEach((s, i) => {
        const el = document.querySelector(s.selector);
        if (!el) return;
        anime({
          targets: { val: 0 },
          val: s.target,
          duration: 1800,
          delay: i * 150,
          easing: 'easeOutQuart',
          round: s.decimals ? false : 1,
          update: function(anim) {
            const v = anim.animations[0].currentValue;
            el.textContent = s.decimals
              ? parseFloat(v).toFixed(s.decimals) + s.suffix
              : Math.round(v) + s.suffix;
          }
        });
      });
    }
  });
}

/* ============================================
   NAVBAR SCROLL BEHAVIOR
   ============================================ */
function initNavbar() {
  const nav = document.querySelector('nav');
  ScrollTrigger.create({
    start: 60,
    onUpdate: (self) => {
      if (self.scroller.scrollY > 60) nav.classList.add('scrolled');
      else nav.classList.remove('scrolled');
    }
  });
}

/* ============================================
   HORIZONTAL DRAG SCROLL (Courses)
   ============================================ */
function initDragScroll(trackSelector) {
  const track = document.querySelector(trackSelector);
  if (!track) return;
  let isDown = false, startX, scrollLeft;
  track.addEventListener('mousedown', (e) => {
    isDown = true; startX = e.pageX - track.offsetLeft; scrollLeft = track.scrollLeft;
    track.style.cursor = 'grabbing';
  });
  document.addEventListener('mouseup', () => { isDown = false; track.style.cursor = 'grab'; });
  document.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - track.offsetLeft;
    track.scrollLeft = scrollLeft - (x - startX) * 1.4;
  });
}

/* ============================================
   SECTION REVEAL (non-pinned sections)
   ============================================ */
function initRevealAnimations() {
  gsap.utils.toArray('.reveal-up').forEach((el) => {
    gsap.fromTo(el, { y: 40, opacity: 0 }, {
      y: 0, opacity: 1, duration: 0.8, ease: 'power2.out',
      scrollTrigger: { trigger: el, start: 'top 85%', once: true }
    });
  });
}

/* ============================================
   MOBILE: DISABLE PINS
   ============================================ */
function initMobileResponsive() {
  ScrollTrigger.matchMedia({
    '(max-width: 900px)': function () {
      // On mobile, pins are disabled — content flows normally
      document.querySelectorAll('.pinned-content').forEach(el => {
        el.style.opacity = 1;
        el.style.transform = 'none';
      });
    }
  });
}

/* ============================================
   BOOT
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initHeroEntrance();
  initStats();
  initDragScroll('.courses-track');
  initRevealAnimations();
  initMobileResponsive();

  // Hero Three.js
  const heroThree = initThreeHero('hero-three');
  initHeroScrollCamera(heroThree);

  // Pinned Section 1 — Three.js Books
  const booksThree = initThreeBooks('books-three');
  const sec1 = document.getElementById('section-books');
  if (sec1 && booksThree) createPinnedSection(sec1, booksThree);

  // Pinned Section 2 — Dot Grid
  const sec2 = document.getElementById('section-dots');
  if (sec2) {
    const dotAnim = initDotGrid(sec2);
    createPinnedSection(sec2, dotAnim);
  }

  // Pinned Section 3 — SVG Path Draw
  const sec3 = document.getElementById('section-path');
  if (sec3) {
    const pathAnim = initSVGPaths(sec3);
    createPinnedSection(sec3, pathAnim);
  }

  // Pinned Section 4 — Particle Convergence (Canvas)
  const sec4canvas = document.getElementById('convergence-canvas');
  const sec4 = document.getElementById('section-convergence');
  if (sec4canvas && sec4) {
    const convAnim = initConvergenceCanvas(sec4canvas);
    createPinnedSection(sec4, convAnim);
  }

  // Pinned Section 5 — Three.js Orbits
  const orbitThree = initThreeOrbits('orbit-three');
  const sec5 = document.getElementById('section-orbits');
  if (sec5 && orbitThree) createPinnedSection(sec5, orbitThree);
});
