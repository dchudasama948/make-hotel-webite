// shared.js — used by all pages

document.addEventListener('DOMContentLoaded', () => {

  // ── CUSTOM CURSOR ──
  const cursor = document.getElementById('cursor');
  const follower = document.getElementById('cursor-follower');
  if (cursor && follower) {
    let fx = 0, fy = 0, cx = 0, cy = 0;
    document.addEventListener('mousemove', e => { cx = e.clientX; cy = e.clientY; });
    (function tick() {
      cursor.style.left = cx + 'px';
      cursor.style.top = cy + 'px';
      fx += (cx - fx) * 0.12;
      fy += (cy - fy) * 0.12;
      follower.style.left = fx + 'px';
      follower.style.top = fy + 'px';
      requestAnimationFrame(tick);
    })();
    document.querySelectorAll('a, button').forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.style.width = '20px'; cursor.style.height = '20px';
        cursor.style.background = 'var(--accent)';
        follower.style.opacity = '0';
      });
      el.addEventListener('mouseleave', () => {
        cursor.style.width = ''; cursor.style.height = '';
        cursor.style.background = '';
        follower.style.opacity = '';
      });
    });
  }

  // ── PROGRESS BAR ──
  const bar = document.getElementById('progress-bar');
  if (bar) {
    window.addEventListener('scroll', () => {
      const pct = window.scrollY / (document.body.scrollHeight - window.innerHeight) * 100;
      bar.style.width = pct + '%';
    }, { passive: true });
  }

  // ── NAVBAR ──
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  // ── HAMBURGER ──
  const hamburger = document.querySelector('.nav-hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => mobileNav.classList.toggle('open'));
  }

  // ── REVEAL ON SCROLL ──
  const revealIO = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        revealIO.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -50px 0px' });
  document.querySelectorAll('.reveal, .stagger-child').forEach(el => revealIO.observe(el));

  // ── STATS COUNTER ──
  const statBand = document.querySelector('.stats-band-shared');
  if (statBand && typeof anime !== 'undefined') {
    let counted = false;
    const sio = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !counted) {
        counted = true;
        statBand.querySelectorAll('.stat-cell').forEach(c => c.classList.add('in-view'));
        statBand.querySelectorAll('.counter').forEach((el, i) => {
          const target = parseFloat(el.dataset.target);
          const isDecimal = el.dataset.decimal === 'true';
          anime({
            targets: el,
            innerHTML: [0, target],
            round: isDecimal ? 10 : 1,
            duration: 1800,
            delay: i * 120,
            easing: 'easeOutExpo',
            update: function() {
              if (isDecimal) el.textContent = parseFloat(el.innerHTML).toFixed(1);
              else el.textContent = Math.round(parseFloat(el.innerHTML)).toLocaleString();
            }
          });
        });
      }
    }, { threshold: 0.4 });
    sio.observe(statBand);
  }

  // ── FAQ ──
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.parentElement;
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  // ── CONTACT FORM ──
  const form = document.getElementById('contact-form');
  if (form) {
    function showError(id, msg) {
      const el = document.getElementById(id + '-error');
      if (el) { el.textContent = msg; el.style.display = 'block'; }
    }
    function clearErrors() {
      form.querySelectorAll('.form-error').forEach(e => e.style.display = 'none');
    }
    function validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

    form.addEventListener('submit', e => {
      e.preventDefault();
      clearErrors();
      let valid = true;
      const name = form.querySelector('#name');
      const email = form.querySelector('#email');
      const subject = form.querySelector('#subject');
      const message = form.querySelector('#message');
      if (!name || name.value.trim().length < 2) { showError('name', 'Please enter your full name.'); valid = false; }
      if (!email || !validEmail(email.value)) { showError('email', 'Please enter a valid email address.'); valid = false; }
      if (subject && subject.value.trim().length < 3) { showError('subject', 'Please enter a subject.'); valid = false; }
      if (!message || message.value.trim().length < 15) { showError('message', 'Message must be at least 15 characters.'); valid = false; }
      if (valid) {
        const btn = form.querySelector('[type=submit]');
        btn.textContent = 'Message Sent ✓';
        btn.style.background = '#2d6a4f';
        btn.disabled = true;
        form.reset();
        setTimeout(() => {
          btn.textContent = 'Send Message';
          btn.style.background = '';
          btn.disabled = false;
        }, 3500);
      }
    });
  }
});
