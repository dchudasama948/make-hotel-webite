/* ===========================
   VINTAR ACADEMY — ANIMATIONS.JS
   =========================== */

gsap.registerPlugin(ScrollTrigger);

// ===========================
// CURSOR
// ===========================
(function initCursor() {
  const cursor = document.getElementById('cursor');
  const ring = document.getElementById('cursor-ring');
  if (!cursor || !ring) return;

  let cx = 0, cy = 0, rx = 0, ry = 0;

  window.addEventListener('mousemove', (e) => {
    cx = e.clientX; cy = e.clientY;
    gsap.set(cursor, { x: cx, y: cy });
  });

  function animRing() {
    rx += (cx - rx) * 0.12;
    ry += (cy - ry) * 0.12;
    gsap.set(ring, { x: rx, y: ry });
    requestAnimationFrame(animRing);
  }
  animRing();

  document.querySelectorAll('a, button, .filter-btn').forEach(el => {
    el.addEventListener('mouseenter', () => {
      gsap.to(cursor, { width: 6, height: 6, duration: 0.2 });
      gsap.to(ring, { width: 60, height: 60, opacity: 0.8, duration: 0.3 });
    });
    el.addEventListener('mouseleave', () => {
      gsap.to(cursor, { width: 12, height: 12, duration: 0.2 });
      gsap.to(ring, { width: 40, height: 40, opacity: 1, duration: 0.3 });
    });
  });
})();

// ===========================
// NAVBAR SCROLL
// ===========================
(function initNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  ScrollTrigger.create({
    start: 'top+=60 top',
    onEnter: () => nav.classList.add('scrolled'),
    onLeaveBack: () => nav.classList.remove('scrolled')
  });
})();

// ===========================
// CINEMATIC SCROLL STAGE (index only)
// ===========================
(function initCinematicStage() {
  const stage = document.getElementById('cinematic-stage');
  if (!stage) return;

  const pin = document.getElementById('cinematic-pin');
  const cuts = {
    0: document.getElementById('cut-0'),
    1: document.getElementById('cut-1'),
    2: document.getElementById('cut-2'),
    3: document.getElementById('cut-3'),
    4: document.getElementById('cut-4'),
  };
  const bgOverlay = document.getElementById('stage-bg');

  // Init particles on hero canvas
  const heroCanvas = document.getElementById('particle-canvas');
  let heroParticles = null;
  if (heroCanvas && window.initHeroParticles) {
    heroParticles = window.initHeroParticles(heroCanvas);
  }

  // Hero entrance animation
  const heroWords = document.querySelectorAll('#cut-0 .hero-word span');
  const heroSub = document.querySelector('#cut-0 .hero-sub');
  const scrollHint = document.querySelector('.scroll-hint');

  if (heroWords.length) {
    anime({
      targets: heroWords,
      translateY: ['110%', '0%'],
      duration: 700,
      delay: anime.stagger(80),
      easing: 'cubicBezier(0.16, 1, 0.3, 1)'
    });
  }
  if (heroSub) {
    anime({ targets: heroSub, opacity: [0, 1], translateY: [10, 0], delay: 600, duration: 600, easing: 'easeOutExpo' });
  }
  if (scrollHint) {
    anime({ targets: scrollHint, opacity: [0, 1], delay: 1200, duration: 800, easing: 'easeOutExpo' });
  }
  if (cuts[0]) gsap.set(cuts[0], { opacity: 1 });

  // Map progress 0-1 across 4 cuts
  // Each cut occupies roughly 1/4 of the scroll
  const proxy = { value: 0 };
  let lastCut = 0;
  let reelCards = document.querySelectorAll('.reel-card');
  let springCards = document.querySelectorAll('.spring-card');
  let mentorTiles = document.querySelectorAll('.mentor-tile');
  let statItems = document.querySelectorAll('.stat-item');
  let statNumbers = document.querySelectorAll('.stat-number');

  // Stats rolling counters
  const statTargets = [26, 20, 50000, 4.9];
  const statSuffix = ['+', '+', 'K+', '★'];
  let statsAnimated = false;

  function animateStats() {
    if (statsAnimated) return;
    statsAnimated = true;
    statNumbers.forEach((el, i) => {
      const target = statTargets[i];
      const isDecimal = String(target).includes('.');
      anime({
        targets: el,
        innerHTML: [0, target],
        duration: 1800,
        delay: i * 150,
        easing: 'easeOutExpo',
        round: isDecimal ? 10 : 1,
        update: function(anim) {
          const raw = parseFloat(el.innerHTML);
          if (i === 3) {
            el.innerHTML = raw.toFixed(1) + statSuffix[i];
          } else if (i === 2) {
            el.innerHTML = Math.round(raw / 1000) + statSuffix[i];
          } else {
            el.innerHTML = Math.round(raw) + statSuffix[i];
          }
        }
      });
    });
  }

  function showCut(n, instant) {
    Object.values(cuts).forEach(c => { if (c) { c.style.opacity = '0'; c.style.pointerEvents = 'none'; }});
    if (cuts[n]) { cuts[n].style.opacity = '1'; cuts[n].style.pointerEvents = 'auto'; }
  }

  function onProgress(p) {
    // p: 0 → 1 across entire stage
    const cutIndex = Math.min(4, Math.floor(p * 5));
    const cutLocal = (p * 5) - cutIndex; // 0-1 within current cut

    if (cutIndex !== lastCut) {
      showCut(cutIndex);
      lastCut = cutIndex;

      // Cut-specific entrance animations
      if (cutIndex === 1) {
        anime({
          targets: reelCards,
          translateX: [120, 0],
          opacity: [0, 1],
          delay: anime.stagger(80),
          duration: 600,
          easing: 'cubicBezier(0.16, 1, 0.3, 1)'
        });
      }
      if (cutIndex === 2) {
        animateStats();
        anime({
          targets: statItems,
          opacity: [0, 1],
          translateY: [30, 0],
          delay: anime.stagger(120),
          duration: 700,
          easing: 'cubicBezier(0.16, 1, 0.3, 1)'
        });
      }
      if (cutIndex === 3) {
        anime({
          targets: springCards,
          opacity: [0, 1],
          translateY: [80, 0],
          delay: anime.stagger(80),
          duration: 700,
          easing: 'cubicBezier(0.16, 1, 0.3, 1)'
        });
      }
      if (cutIndex === 4) {
        anime({
          targets: mentorTiles,
          scale: [0.7, 1],
          opacity: [0, 1],
          delay: anime.stagger(100),
          duration: 700,
          easing: 'cubicBezier(0.34, 1.56, 0.64, 1)'
        });
      }
    }
  }

  showCut(0);

  gsap.to(proxy, {
    value: 1,
    ease: 'none',
    scrollTrigger: {
      trigger: stage,
      start: 'top top',
      end: '+=400%',
      pin: pin,
      scrub: 0.8,
      onUpdate: (self) => onProgress(self.progress)
    }
  });
})();

// ===========================
// DOT GRID SECTION (Pinned)
// ===========================
(function initDotGridSection() {
  const section = document.getElementById('dot-grid-section');
  if (!section) return;
  const outer = section.closest('.pinned-outer');
  const canvas = section.querySelector('.feature-canvas');
  const content = section.querySelector('.feature-content');
  if (!canvas || !window.initDotGridCanvas) return;

  const dotGrid = window.initDotGridCanvas(canvas);
  const proxy = { value: 0 };

  gsap.to(proxy, {
    value: 1,
    ease: 'none',
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: '+=200%',
      pin: true,
      scrub: 1,
      onUpdate: (self) => {
        dotGrid.setProgress(self.progress);
        if (self.progress > 0.25 && content) {
          gsap.to(content, { opacity: 1, y: 0, duration: 0.5 });
        } else if (content) {
          gsap.to(content, { opacity: 0, y: 20, duration: 0.3 });
        }
      }
    }
  });
})();

// ===========================
// SVG LINE DRAW SECTION (Pinned)
// ===========================
(function initSVGSection() {
  const section = document.getElementById('svg-section');
  if (!section) return;
  const paths = section.querySelectorAll('.draw-path');
  const dots = section.querySelectorAll('.path-dot');
  const content = section.querySelector('.feature-content');
  if (!paths.length) return;

  // Set up dash arrays
  const lengths = [];
  paths.forEach(path => {
    const len = path.getTotalLength ? path.getTotalLength() : 1000;
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    lengths.push(len);
  });

  const proxy = { value: 0 };
  gsap.to(proxy, {
    value: 1,
    ease: 'none',
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: '+=200%',
      pin: true,
      scrub: 1,
      onUpdate: (self) => {
        const p = self.progress;
        paths.forEach((path, i) => {
          const delay = i * 0.15;
          const local = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
          path.style.strokeDashoffset = lengths[i] * (1 - local);
        });

        // Move dots along paths
        paths.forEach((path, i) => {
          if (!path.getTotalLength) return;
          const len = path.getTotalLength();
          const delay = i * 0.15;
          const local = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
          const pt = path.getPointAtLength(len * local);
          if (dots[i]) {
            dots[i].setAttribute('cx', pt.x);
            dots[i].setAttribute('cy', pt.y);
            dots[i].setAttribute('r', 4 + local * 3);
            dots[i].style.opacity = local > 0 ? 1 : 0;
          }
        });

        if (p > 0.35 && content) {
          gsap.to(content, { opacity: 1, y: 0, duration: 0.5 });
        } else if (content) {
          gsap.to(content, { opacity: 0, y: 20, duration: 0.3 });
        }
      }
    }
  });
})();

// ===========================
// SCATTER CANVAS SECTION (Pinned)
// ===========================
(function initScatterSection() {
  const section = document.getElementById('scatter-section');
  if (!section) return;
  const canvas = section.querySelector('.feature-canvas');
  const content = section.querySelector('.feature-content');
  if (!canvas || !window.initScatterCanvas) return;

  const scatter = window.initScatterCanvas(canvas);
  const proxy = { value: 0 };

  gsap.to(proxy, {
    value: 1,
    ease: 'none',
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: '+=200%',
      pin: true,
      scrub: 1,
      onUpdate: (self) => {
        scatter.setProgress(self.progress);
        if (self.progress > 0.4 && content) {
          gsap.to(content, { opacity: 1, y: 0, duration: 0.5 });
        } else if (content) {
          gsap.to(content, { opacity: 0, y: 20, duration: 0.3 });
        }
      }
    }
  });
})();

// ===========================
// ORBIT SECTION (Pinned)
// ===========================
(function initOrbitSection() {
  const section = document.getElementById('orbit-section');
  if (!section) return;
  const canvas = section.querySelector('.feature-canvas');
  const content = section.querySelector('.feature-content');
  if (!canvas || !window.initOrbitCanvas) return;

  const orbit = window.initOrbitCanvas(canvas);
  const proxy = { value: 0 };

  gsap.to(proxy, {
    value: 1,
    ease: 'none',
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: '+=200%',
      pin: true,
      scrub: 1,
      onUpdate: (self) => {
        orbit.setProgress(self.progress);
        if (self.progress > 0.2 && content) {
          gsap.to(content, { opacity: 1, y: 0, duration: 0.5 });
        } else if (content) {
          gsap.to(content, { opacity: 0, y: 20, duration: 0.3 });
        }
      }
    }
  });
})();

// ===========================
// TESTIMONIALS — SCROLL REVEAL
// ===========================
(function initTestiReveal() {
  const cards = document.querySelectorAll('.testi-card');
  if (!cards.length) return;
  gsap.fromTo(cards, 
    { opacity: 0, y: 40 },
    {
      opacity: 1, y: 0,
      stagger: 0.12,
      duration: 0.8,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: cards[0].closest('.testimonials-section'),
        start: 'top 80%'
      }
    }
  );
})();

// ===========================
// MOBILE: DISABLE PINNING
// ===========================
ScrollTrigger.matchMedia({
  '(max-width: 768px)': function() {
    ScrollTrigger.getAll().forEach(t => {
      if (t.pin) {
        t.kill();
      }
    });
  }
});

// ===========================
// CONTACT FORM VALIDATION
// ===========================
(function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  function showError(fieldId, msg) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    const err = field.parentElement.querySelector('.form-error');
    if (err) { err.textContent = msg; err.style.display = 'block'; }
    field.style.borderColor = 'rgba(255,61,0,0.6)';
  }

  function clearError(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    const err = field.parentElement.querySelector('.form-error');
    if (err) err.style.display = 'none';
    field.style.borderColor = '';
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validatePhone(phone) {
    return /^\+?[\d\s\-()]{7,}$/.test(phone);
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;

    const name = document.getElementById('f-name');
    const email = document.getElementById('f-email');
    const phone = document.getElementById('f-phone');
    const course = document.getElementById('f-course');
    const message = document.getElementById('f-message');

    if (name && name.value.trim().length < 2) {
      showError('f-name', 'Please enter your full name.'); valid = false;
    } else if (name) clearError('f-name');

    if (email && !validateEmail(email.value)) {
      showError('f-email', 'Please enter a valid email address.'); valid = false;
    } else if (email) clearError('f-email');

    if (phone && phone.value && !validatePhone(phone.value)) {
      showError('f-phone', 'Please enter a valid phone number.'); valid = false;
    } else if (phone) clearError('f-phone');

    if (course && course.value === '') {
      showError('f-course', 'Please select a course of interest.'); valid = false;
    } else if (course) clearError('f-course');

    if (message && message.value.trim().length < 10) {
      showError('f-message', 'Please write at least 10 characters.'); valid = false;
    } else if (message) clearError('f-message');

    if (valid) {
      const formEl = form.querySelector('.form-fields');
      const success = form.querySelector('.form-success');
      if (formEl) formEl.style.display = 'none';
      if (success) success.style.display = 'block';
    }
  });
})();

// ===========================
// BUTTON RIPPLE (anime.js)
// ===========================
document.querySelectorAll('.btn-primary, .btn-outline').forEach(btn => {
  btn.addEventListener('click', function(e) {
    const ripple = document.createElement('span');
    ripple.style.cssText = `
      position:absolute; border-radius:50%; background:rgba(255,255,255,0.25);
      width:10px; height:10px; pointer-events:none;
      left:${e.offsetX - 5}px; top:${e.offsetY - 5}px;
    `;
    this.style.position = 'relative';
    this.style.overflow = 'hidden';
    this.appendChild(ripple);
    anime({
      targets: ripple,
      width: ['10px', '300px'],
      height: ['10px', '300px'],
      left: [e.offsetX - 5, e.offsetX - 150],
      top: [e.offsetY - 5, e.offsetY - 150],
      opacity: [1, 0],
      duration: 600,
      easing: 'easeOutExpo',
      complete: () => ripple.remove()
    });
  });
});

// ===========================
// SECTION REVEAL ANIMATIONS
// ===========================
(function initRevealAnimations() {
  // About page values
  gsap.utils.toArray('.value-card').forEach((card, i) => {
    gsap.fromTo(card,
      { opacity: 0, y: 40 },
      {
        opacity: 1, y: 0,
        duration: 0.7,
        delay: i * 0.1,
        ease: 'power3.out',
        scrollTrigger: { trigger: card, start: 'top 85%' }
      }
    );
  });

  // Course cards
  gsap.utils.toArray('.course-card').forEach((card, i) => {
    gsap.fromTo(card,
      { opacity: 0, y: 50 },
      {
        opacity: 1, y: 0,
        duration: 0.7,
        delay: (i % 3) * 0.08,
        ease: 'power3.out',
        scrollTrigger: { trigger: card, start: 'top 88%' }
      }
    );
  });

  // Mentor cards
  gsap.utils.toArray('.mentor-card').forEach((card, i) => {
    gsap.fromTo(card,
      { opacity: 0, x: i % 2 === 0 ? -30 : 30 },
      {
        opacity: 1, x: 0,
        duration: 0.7,
        ease: 'power3.out',
        scrollTrigger: { trigger: card, start: 'top 85%' }
      }
    );
  });

  // Page hero words
  document.querySelectorAll('.page-hero h1').forEach(h1 => {
    gsap.fromTo(h1,
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', delay: 0.2 }
    );
  });
  document.querySelectorAll('.page-hero p').forEach(p => {
    gsap.fromTo(p,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out', delay: 0.4 }
    );
  });
})();
