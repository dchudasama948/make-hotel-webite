/* ===========================
   VINTAR ACADEMY — PARTICLES.JS
   =========================== */

// Hero particle canvas — white dots + red sparks, 3D-ish drift
function initHeroParticles(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  let particles = [];
  let sparks = [];
  let mouse = { x: -1000, y: -1000 };

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function createParticles(n) {
    particles = [];
    sparks = [];
    for (let i = 0; i < n; i++) {
      const z = Math.random();
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        z: z,
        vx: (Math.random() - 0.5) * (0.15 + z * 0.25),
        vy: (Math.random() - 0.5) * (0.15 + z * 0.25),
        r: 0.5 + z * 1.5,
        alpha: 0.2 + z * 0.5,
        spark: false
      });
    }
    // Red sparks
    for (let i = 0; i < 20; i++) {
      sparks.push({
        x: Math.random() * W,
        y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 1.2 + 0.3,
        life: Math.random()
      });
    }
  }
  createParticles(110);

  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  canvas.addEventListener('mouseleave', () => {
    mouse.x = -1000; mouse.y = -1000;
  });

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // Particles
    particles.forEach((p, i) => {
      // Mouse repulsion
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 100) {
        const force = (100 - dist) / 100 * 0.8;
        p.x += (dx / dist) * force;
        p.y += (dy / dist) * force;
      }

      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(245,245,240,${p.alpha})`;
      ctx.fill();

      // Connect nearby
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const dx2 = p.x - q.x;
        const dy2 = p.y - q.y;
        const d2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
        if (d2 < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(245,245,240,${(1 - d2 / 120) * 0.05})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });

    // Sparks
    sparks.forEach(s => {
      s.x += s.vx;
      s.y += s.vy;
      s.life += 0.005;
      if (s.life > 1) { s.life = 0; s.x = Math.random() * W; s.y = Math.random() * H; }
      const alpha = Math.sin(s.life * Math.PI) * 0.6;
      if (s.x < 0 || s.x > W) s.vx *= -1;
      if (s.y < 0 || s.y > H) s.vy *= -1;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,61,0,${alpha})`;
      ctx.fill();
    });

    requestAnimationFrame(draw);
  }
  draw();

  return {
    resize: () => { resize(); createParticles(110); }
  };
}

// Feature canvas 1 — 8x8 dot grid scroll-driven
function initDotGridCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  let dots = [];
  let progress = 0;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    buildGrid();
  }

  function buildGrid() {
    dots = [];
    const cols = 12, rows = 12;
    const gapX = W / (cols + 1);
    const gapY = H / (rows + 1);
    const cx = W / 2, cy = H / 2;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = gapX * (c + 1);
        const y = gapY * (r + 1);
        const dx = x - cx;
        const dy = y - cy;
        const distFromCenter = Math.sqrt(dx * dx + dy * dy);
        dots.push({ x, y, distFromCenter });
      }
    }
    // Sort by dist from center for stagger
    dots.sort((a, b) => a.distFromCenter - b.distFromCenter);
    const maxDist = dots[dots.length - 1].distFromCenter;
    dots.forEach(d => d.normDist = d.distFromCenter / maxDist);
  }

  resize();
  window.addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, W, H);
    dots.forEach((d, i) => {
      const delay = d.normDist * 0.6;
      const local = Math.max(0, Math.min(1, (progress - delay) / 0.5));
      const scale = 1 + local * 2.5;
      const alpha = 0.06 + local * 0.7;
      const r = (3 + local * 8) * scale * 0.3;
      
      // Outer glow
      if (local > 0.1) {
        const grd = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, r * 3);
        grd.addColorStop(0, `rgba(255,61,0,${local * 0.15})`);
        grd.addColorStop(1, 'rgba(255,61,0,0)');
        ctx.beginPath();
        ctx.arc(d.x, d.y, r * 3, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
      }

      ctx.beginPath();
      ctx.arc(d.x, d.y, Math.max(0.5, r), 0, Math.PI * 2);
      ctx.fillStyle = local < 0.1
        ? `rgba(245,245,240,${alpha})`
        : `rgba(255,${61 + (1 - local) * 140},${local < 0.5 ? 0 : (local - 0.5) * 40},${alpha})`;
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  draw();

  return {
    setProgress: (p) => { progress = p; }
  };
}

// Feature canvas 2 — SVG line draw (handled in HTML/animations.js)

// Feature canvas 3 — particle scatter→converge
function initScatterCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  let particles = [];
  let progress = 0;
  const COUNT = 220;

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    buildParticles();
  }

  function buildParticles() {
    particles = [];
    const cx = W / 2, cy = H / 2;
    const R = Math.min(W, H) * 0.28;
    for (let i = 0; i < COUNT; i++) {
      const angle = (i / COUNT) * Math.PI * 2;
      particles.push({
        // Origin: scattered
        ox: Math.random() * W,
        oy: Math.random() * H,
        // Target: circle
        tx: cx + Math.cos(angle) * R,
        ty: cy + Math.sin(angle) * R,
        // Current
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 1.5 + 0.5,
        hue: Math.random() > 0.85 ? 'red' : 'white'
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach(p => {
      let tx, ty, alpha;
      if (progress < 0.5) {
        // 0→0.5: scatter outward from center
        const t = progress / 0.5;
        const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        tx = p.ox;
        ty = p.oy;
        alpha = 0.15 + t * 0.25;
      } else {
        // 0.5→1: converge to circle
        const t = (progress - 0.5) / 0.5;
        const eased = t * t * (3 - 2 * t);
        tx = p.ox + (p.tx - p.ox) * eased;
        ty = p.oy + (p.ty - p.oy) * eased;
        alpha = 0.4 + t * 0.5;
      }

      p.x += (tx - p.x) * 0.04;
      p.y += (ty - p.y) * 0.04;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.hue === 'red'
        ? `rgba(255,61,0,${alpha + 0.2})`
        : `rgba(245,245,240,${alpha})`;
      ctx.fill();
    });

    requestAnimationFrame(draw);
  }
  draw();

  return {
    setProgress: (p) => { progress = p; }
  };
}

// Orbit canvas — concentric rings with dots
function initOrbitCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let W, H;
  let progress = 0;
  const rings = [
    { r: 80, dots: 6, speed: 0.3, offset: 0, color: 'rgba(245,245,240,0.6)' },
    { r: 140, dots: 8, speed: -0.2, offset: Math.PI / 4, color: 'rgba(255,61,0,0.7)' },
    { r: 200, dots: 12, speed: 0.15, offset: Math.PI / 8, color: 'rgba(245,245,240,0.3)' },
    { r: 260, dots: 16, speed: -0.1, offset: Math.PI / 6, color: 'rgba(255,61,0,0.4)' }
  ];

  function resize() {
    W = canvas.width = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  let frame = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const cx = W / 2, cy = H / 2;
    frame++;

    const speedMult = 1 + progress * 8;
    const t = frame * 0.008 * speedMult;

    // Center glow
    const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 40);
    grd.addColorStop(0, `rgba(255,61,0,${0.15 + progress * 0.25})`);
    grd.addColorStop(1, 'rgba(255,61,0,0)');
    ctx.beginPath();
    ctx.arc(cx, cy, 40, 0, Math.PI * 2);
    ctx.fillStyle = grd;
    ctx.fill();

    // Rings
    rings.forEach((ring, ri) => {
      const angle = t * ring.speed + ring.offset;
      
      // Ring circle
      ctx.beginPath();
      ctx.arc(cx, cy, ring.r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(245,245,240,${0.05 + progress * 0.05})`;
      ctx.lineWidth = 0.5;
      ctx.stroke();

      // Orbiting dots
      for (let i = 0; i < ring.dots; i++) {
        const a = angle + (i / ring.dots) * Math.PI * 2;
        const dx = Math.cos(a) * ring.r;
        const dy = Math.sin(a) * ring.r;
        
        // Check alignment at progress=1
        const alignBonus = progress > 0.9 ? (progress - 0.9) / 0.1 : 0;
        const dotR = 2.5 + alignBonus * 3;
        
        ctx.beginPath();
        ctx.arc(cx + dx, cy + dy, dotR, 0, Math.PI * 2);
        ctx.fillStyle = ring.color;
        ctx.fill();

        if (alignBonus > 0.5) {
          // Glow on alignment
          const grd2 = ctx.createRadialGradient(cx + dx, cy + dy, 0, cx + dx, cy + dy, dotR * 4);
          grd2.addColorStop(0, ring.color.replace(/[\d.]+\)$/, `${alignBonus * 0.4})`));
          grd2.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.beginPath();
          ctx.arc(cx + dx, cy + dy, dotR * 4, 0, Math.PI * 2);
          ctx.fillStyle = grd2;
          ctx.fill();
        }
      }
    });

    requestAnimationFrame(draw);
  }
  draw();

  return {
    setProgress: (p) => { progress = p; }
  };
}
