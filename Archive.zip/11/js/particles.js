/* ============================================
   particles.js — Canvas Animation Systems
   Vintar Academy
   ============================================ */

// ── HERO PARTICLE NETWORK ──────────────────────
function initHeroParticles(canvas) {
  const ctx = canvas.getContext('2d');
  const particles = [];
  let mouse = { x: -1000, y: -1000 };
  let animId;

  function resize() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const COUNT = window.innerWidth < 768 ? 60 : 100;
  for (let i = 0; i < COUNT; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() * 1.5 + 0.5,
      ox: 0, oy: 0
    });
  }

  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  canvas.addEventListener('mouseleave', () => {
    mouse.x = -1000; mouse.y = -1000;
  });

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(255,255,255,0)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    particles.forEach((p, i) => {
      // repel from mouse
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 100) {
        const force = (100 - dist) / 100 * 0.8;
        p.vx += (dx / dist) * force;
        p.vy += (dy / dist) * force;
      }

      // damping
      p.vx *= 0.99;
      p.vy *= 0.99;

      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(61,90,254,0.4)';
      ctx.fill();

      // connect nearby
      for (let j = i + 1; j < particles.length; j++) {
        const ddx = p.x - particles[j].x;
        const ddy = p.y - particles[j].y;
        const d = Math.sqrt(ddx * ddx + ddy * ddy);
        if (d < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(61,90,254,${(1 - d / 120) * 0.12})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });

    animId = requestAnimationFrame(draw);
  }
  draw();

  return {
    setMouse: (x, y) => { mouse.x = x; mouse.y = y; },
    destroy: () => cancelAnimationFrame(animId)
  };
}

// ── FEATURE SECTION 1 — DOT GRID SCROLL ───────
function initDotGrid(container) {
  const cells = container.querySelectorAll('.dot-cell span');
  const total = cells.length;
  // Pre-compute center distances
  const cx = 3.5, cy = 3.5; // center of 8x8
  const distances = [];
  cells.forEach((_, i) => {
    const row = Math.floor(i / 8);
    const col = i % 8;
    const d = Math.sqrt((col - cx) ** 2 + (row - cy) ** 2);
    distances.push(d);
  });
  const maxDist = Math.max(...distances);

  function update(progress) {
    cells.forEach((dot, i) => {
      const normDist = distances[i] / maxDist;
      // Center-out wave: center dots animate first
      const delay = normDist * 0.4;
      const localP = Math.max(0, Math.min(1, (progress - delay) / 0.6));
      const scale = 1 + localP * 2;
      const opacity = 0.08 + localP * 0.9;
      dot.style.transform = `scale(${scale})`;
      dot.style.opacity = opacity;
      dot.style.background = `rgba(61,90,254,${localP})`;
    });
  }

  return { update };
}

// ── FEATURE SECTION 3 — PARTICLES CONVERGE ────
function initConvergeCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let animId;
  const particles = [];
  const COUNT = 200;
  let progress = 0;
  let w, h;

  function resize() {
    w = canvas.width = canvas.offsetWidth;
    h = canvas.height = canvas.offsetHeight;
    initParticles();
  }

  function initParticles() {
    particles.length = 0;
    for (let i = 0; i < COUNT; i++) {
      const angle = (i / COUNT) * Math.PI * 2;
      const r = 80;
      particles.push({
        // random scattered position
        sx: Math.random() * w,
        sy: Math.random() * h,
        // target: circle
        tx: w / 2 + Math.cos(angle) * r,
        ty: h / 2 + Math.sin(angle) * r,
        // current
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 2 + 1,
        color: `hsl(${220 + i * 1.5}, 70%, 60%)`
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, w, h);

    particles.forEach(p => {
      let tx, ty;
      if (progress < 0.5) {
        // scatter phase
        const t = progress / 0.5;
        tx = p.x + (p.sx - p.x) * t;
        ty = p.y + (p.sy - p.y) * t;
      } else {
        // converge phase
        const t = (progress - 0.5) / 0.5;
        const fromX = p.sx;
        const fromY = p.sy;
        tx = fromX + (p.tx - fromX) * t;
        ty = fromY + (p.ty - fromY) * t;
      }

      ctx.beginPath();
      ctx.arc(tx, ty, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = 0.7;
      ctx.fill();
    });

    ctx.globalAlpha = 1;
    animId = requestAnimationFrame(draw);
  }
  draw();

  return {
    update: (p) => { progress = p; },
    destroy: () => cancelAnimationFrame(animId)
  };
}

// ── FEATURE SECTION 4 — ORBIT RINGS ───────────
function initOrbitCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let animId;
  let progress = 0;
  let w, h;

  const rings = [
    { r: 60, dotCount: 6, speed: 0.8, color: 'rgba(61,90,254,0.7)', offset: 0 },
    { r: 100, dotCount: 8, speed: 0.5, color: 'rgba(255,107,53,0.6)', offset: Math.PI / 4 },
    { r: 140, dotCount: 10, speed: 0.3, color: 'rgba(0,200,150,0.5)', offset: Math.PI / 3 },
    { r: 180, dotCount: 14, speed: 0.15, color: 'rgba(61,90,254,0.35)', offset: Math.PI / 6 }
  ];

  let angle = 0;

  function resize() {
    w = canvas.width = canvas.offsetWidth;
    h = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    angle += 0.005 * (1 + progress * 3);

    rings.forEach((ring, ri) => {
      const scale = Math.min(w, h) / 480;
      const r = ring.r * scale;

      // Draw ring
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = ring.color.replace('0.7', '0.12').replace('0.6', '0.1').replace('0.5', '0.08').replace('0.35', '0.06');
      ctx.lineWidth = 1;
      ctx.stroke();

      // Draw orbiting dots
      const rotAngle = angle * ring.speed + ring.offset;
      for (let i = 0; i < ring.dotCount; i++) {
        const a = rotAngle + (i / ring.dotCount) * Math.PI * 2;
        const dx = cx + Math.cos(a) * r;
        const dy = cy + Math.sin(a) * r;
        const dotSize = 3 + progress * 2;
        ctx.beginPath();
        ctx.arc(dx, dy, dotSize * scale, 0, Math.PI * 2);
        ctx.fillStyle = ring.color;
        ctx.fill();
      }
    });

    // Center glow
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 40 * Math.min(w, h) / 480);
    grad.addColorStop(0, `rgba(61,90,254,${0.2 + progress * 0.3})`);
    grad.addColorStop(1, 'rgba(61,90,254,0)');
    ctx.beginPath();
    ctx.arc(cx, cy, 40 * Math.min(w, h) / 480, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    animId = requestAnimationFrame(draw);
  }
  draw();

  return {
    update: (p) => { progress = p; },
    destroy: () => cancelAnimationFrame(animId)
  };
}

// ── SVG LINE DRAW ──────────────────────────────
function initLineDraw(svgEl) {
  const paths = svgEl.querySelectorAll('path, polyline, line');
  const lengths = [];
  paths.forEach(p => {
    const len = p.getTotalLength ? p.getTotalLength() : 300;
    lengths.push(len);
    p.style.strokeDasharray = len;
    p.style.strokeDashoffset = len;
    p.style.fill = 'none';
  });

  // Moving circles along path
  const circles = svgEl.querySelectorAll('.travel-dot');

  function update(progress) {
    paths.forEach((path, i) => {
      path.style.strokeDashoffset = lengths[i] * (1 - progress);
    });
    circles.forEach((c, i) => {
      if (!paths[i]) return;
      const pt = paths[i].getPointAtLength ? paths[i].getPointAtLength(lengths[i] * progress) : null;
      if (pt) {
        c.setAttribute('cx', pt.x);
        c.setAttribute('cy', pt.y);
        c.style.opacity = progress > 0.05 ? 1 : 0;
      }
    });
  }

  return { update };
}
