/* ============================================
   animations.js — GSAP ScrollTrigger + Tutor
   Vintar Academy
   ============================================ */

gsap.registerPlugin(ScrollTrigger);

/* ══════════════════════════════════════
   NAVBAR SCROLL BEHAVIOR
══════════════════════════════════════ */
function initNavbar() {
  const nav = document.querySelector('.navbar');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });
}

/* ══════════════════════════════════════
   HERO ENTRANCE ANIMATION
══════════════════════════════════════ */
function initHeroEntrance() {
  const words = document.querySelectorAll('.word-inner');
  const label = document.querySelector('.hero-label');
  const sub = document.querySelector('.hero-sub');
  const actions = document.querySelector('.hero-actions');
  const hint = document.querySelector('.scroll-hint');

  if (!words.length) return;

  const tl = gsap.timeline({ delay: 0.3 });

  tl.to(label, { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' })
    .to(words, {
      y: 0,
      duration: 0.7,
      ease: 'expo.out',
      stagger: 0.08
    }, '-=0.2')
    .to([sub, actions], {
      opacity: 1,
      y: 0,
      duration: 0.6,
      ease: 'power2.out',
      stagger: 0.12
    }, '-=0.3')
    .to(hint, { opacity: 1, duration: 0.5, ease: 'power2.out' }, '-=0.2');
}

/* ══════════════════════════════════════
   PINNED SECTION HELPER
══════════════════════════════════════ */
function createPinnedSection(sectionEl, onProgress) {
  ScrollTrigger.matchMedia({
    '(min-width: 769px)': function () {
      gsap.to({}, {
        scrollTrigger: {
          trigger: sectionEl,
          start: 'top top',
          end: '+=200%',
          pin: true,
          scrub: 1,
          onUpdate: (self) => {
            onProgress(self.progress);
          }
        }
      });
    },
    '(max-width: 768px)': function () {
      ScrollTrigger.create({
        trigger: sectionEl,
        start: 'top 80%',
        onEnter: () => onProgress(1),
        once: true
      });
    }
  });
}

/* ══════════════════════════════════════
   SECTION TEXT FADE IN
══════════════════════════════════════ */
function fadeInText(sectionEl, threshold = 0.2) {
  const els = sectionEl.querySelectorAll('.section-label, .section-title, .section-body, .section-link');
  els.forEach((el, i) => {
    ScrollTrigger.create({
      trigger: sectionEl,
      start: 'top 70%',
      onEnter: () => {
        gsap.to(el, {
          opacity: 1,
          y: 0,
          duration: 0.7,
          delay: i * 0.1,
          ease: 'power2.out'
        });
      }
    });
    gsap.set(el, { opacity: 0, y: 20 });
  });
}

/* ══════════════════════════════════════
   STATS COUNT-UP
══════════════════════════════════════ */
function initStats() {
  const items = document.querySelectorAll('.stat-number');
  if (!items.length) return;

  ScrollTrigger.create({
    trigger: '.stats-band',
    start: 'top 80%',
    once: true,
    onEnter: () => {
      items.forEach((el, i) => {
        const target = parseInt(el.getAttribute('data-target'), 10);
        anime({
          targets: el,
          innerHTML: [0, target],
          round: 1,
          duration: 1400,
          delay: i * 150,
          easing: 'easeOutCubic'
        });
      });
    }
  });
}

/* ══════════════════════════════════════
   CARDS DRAG SCROLL
══════════════════════════════════════ */
function initCardsDrag() {
  const wrapper = document.querySelector('.cards-scroll-wrapper');
  if (!wrapper) return;
  let isDown = false, startX, scrollLeft;

  wrapper.addEventListener('mousedown', e => {
    isDown = true;
    wrapper.classList.add('active');
    startX = e.pageX - wrapper.offsetLeft;
    scrollLeft = wrapper.scrollLeft;
  });
  wrapper.addEventListener('mouseleave', () => { isDown = false; });
  wrapper.addEventListener('mouseup', () => { isDown = false; });
  wrapper.addEventListener('mousemove', e => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - wrapper.offsetLeft;
    wrapper.scrollLeft = scrollLeft - (x - startX) * 1.5;
  });
}

/* ══════════════════════════════════════
   SCROLL-REVEAL GENERIC
══════════════════════════════════════ */
function initScrollReveal() {
  const els = document.querySelectorAll('.course-card, .testimonial-card, .team-card, .mentor-card');
  els.forEach((el, i) => {
    gsap.set(el, { opacity: 0, y: 30 });
    ScrollTrigger.create({
      trigger: el,
      start: 'top 88%',
      once: true,
      onEnter: () => {
        gsap.to(el, {
          opacity: 1,
          y: 0,
          duration: 0.65,
          delay: (i % 3) * 0.08,
          ease: 'power2.out'
        });
      }
    });
  });
}

/* ══════════════════════════════════════
   ANIMATED TUTOR CHARACTER
══════════════════════════════════════ */
const TutorCharacter = (function () {
  const STATES = {
    IDLE: 'idle',
    WALK: 'walk',
    TALK: 'talk',
    WAVE: 'wave',
    THINK: 'think',
    CELEBRATE: 'celebrate'
  };

  const MESSAGES = [
    "Welcome! Let's start learning!",
    "Scroll down to explore our courses.",
    "Great mentors await you here!",
    "50,000+ students have joined us!",
    "Our courses are career-focused.",
    "Learn at your own pace, anytime!",
    "Join our live community today!",
    "98% of students are satisfied!",
    "Start your journey with us!",
    "Ready to master new skills?"
  ];

  let canvas, ctx, state, frame, animFrame;
  let armAngle = 0, legAngle = 0, bodyBob = 0;
  let walkCycle = 0;
  let currentMessage = '';
  let speechEl;
  let messageTimeout;
  let blinkTimer = 0;
  let blinkOpen = true;
  let lastScrollY = 0;
  let scrollVelocity = 0;
  let msgIndex = 0;

  // Color palette
  const SKIN = '#FFCC99';
  const HAIR = '#3d2c1e';
  const SHIRT = '#3d5afe';
  const PANTS = '#1a237e';
  const SHOES = '#1a1a1a';
  const COLLAR = '#ffffff';
  const GLASSES = '#0d0d0d';

  function init() {
    canvas = document.getElementById('tutor-canvas');
    if (!canvas) return;
    ctx = canvas.getContext('2d');
    speechEl = document.querySelector('.tutor-speech');
    state = STATES.WAVE;
    frame = 0;

    // Show first message after delay
    setTimeout(() => showMessage(MESSAGES[0]), 1500);

    startAnimation();
    initScrollTracking();
  }

  function initScrollTracking() {
    let prevScroll = window.scrollY;
    window.addEventListener('scroll', () => {
      const curr = window.scrollY;
      scrollVelocity = Math.abs(curr - prevScroll);
      prevScroll = curr;

      // Change state based on scroll
      if (scrollVelocity > 15) {
        setState(STATES.WALK);
      } else if (scrollVelocity > 3) {
        setState(STATES.WALK);
      }

      // Trigger messages at scroll milestones
      const sections = document.querySelectorAll('section, .pinned-section, .hero');
      sections.forEach((sec, i) => {
        const rect = sec.getBoundingClientRect();
        if (rect.top > -100 && rect.top < 200) {
          const msgI = i % MESSAGES.length;
          if (msgI !== msgIndex) {
            msgIndex = msgI;
            showMessage(MESSAGES[msgI]);
            setState(STATES.TALK);
          }
        }
      });
    }, { passive: true });

    // Idle when not scrolling
    let scrollEndTimeout;
    window.addEventListener('scroll', () => {
      clearTimeout(scrollEndTimeout);
      scrollEndTimeout = setTimeout(() => {
        scrollVelocity = 0;
        setState(Math.random() > 0.5 ? STATES.IDLE : STATES.THINK);
      }, 800);
    }, { passive: true });
  }

  function setState(newState) {
    if (state === newState) return;
    state = newState;
  }

  function showMessage(msg) {
    if (!speechEl) return;
    clearTimeout(messageTimeout);
    currentMessage = msg;
    speechEl.textContent = msg;
    speechEl.classList.add('visible');
    messageTimeout = setTimeout(() => {
      speechEl.classList.remove('visible');
    }, 3000);
  }

  function startAnimation() {
    function loop() {
      frame++;
      walkCycle += 0.12;
      blinkTimer++;
      if (blinkTimer > 120) {
        blinkOpen = false;
        if (blinkTimer > 125) {
          blinkOpen = true;
          blinkTimer = 0;
        }
      }

      drawCharacter();
      animFrame = requestAnimationFrame(loop);
    }
    loop();
  }

  function drawCharacter() {
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const cx = W / 2;
    const scale = W / 120;

    // Body bob based on state
    let bob = 0;
    if (state === STATES.WALK) {
      bob = Math.sin(walkCycle * 2) * 3;
      armAngle = Math.sin(walkCycle) * 35;
      legAngle = Math.sin(walkCycle) * 30;
    } else if (state === STATES.CELEBRATE) {
      bob = Math.abs(Math.sin(walkCycle * 3)) * -8;
      armAngle = -60 + Math.sin(walkCycle * 4) * 15;
    } else if (state === STATES.IDLE) {
      bob = Math.sin(frame * 0.04) * 2;
      armAngle = 5 + Math.sin(frame * 0.06) * 5;
    } else if (state === STATES.THINK) {
      bob = Math.sin(frame * 0.03) * 1.5;
      armAngle = -50;
    } else if (state === STATES.TALK) {
      bob = Math.sin(frame * 0.1) * 2;
      armAngle = -20 + Math.sin(frame * 0.15) * 10;
    } else if (state === STATES.WAVE) {
      bob = Math.sin(frame * 0.05) * 2;
      armAngle = -70 + Math.sin(frame * 0.15) * 25;
    }

    const baseY = H * 0.88 + bob;

    ctx.save();
    ctx.translate(cx, 0);
    ctx.scale(scale, scale);

    const BY = baseY / scale;

    // ── SHADOW ──
    ctx.save();
    ctx.translate(0, BY);
    ctx.scale(1, 0.3);
    ctx.beginPath();
    ctx.ellipse(0, 0, 22, 8, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(0,0,0,0.12)';
    ctx.fill();
    ctx.restore();

    // ── LEFT LEG ──
    ctx.save();
    ctx.translate(-7, BY - 20);
    const leftLegAngle = state === STATES.WALK ? legAngle : 0;
    ctx.rotate((leftLegAngle * Math.PI) / 180);
    ctx.fillStyle = PANTS;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 10, 28, 3);
    ctx.fill();
    // Shoe
    ctx.fillStyle = SHOES;
    ctx.beginPath();
    ctx.ellipse(0, 28, 7, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // ── RIGHT LEG ──
    ctx.save();
    ctx.translate(7, BY - 20);
    const rightLegAngle = state === STATES.WALK ? -legAngle : 0;
    ctx.rotate((rightLegAngle * Math.PI) / 180);
    ctx.fillStyle = PANTS;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 10, 28, 3);
    ctx.fill();
    ctx.fillStyle = SHOES;
    ctx.beginPath();
    ctx.ellipse(0, 28, 7, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // ── BODY / SHIRT ──
    ctx.fillStyle = SHIRT;
    ctx.beginPath();
    ctx.roundRect(-14, BY - 52, 28, 32, [6, 6, 0, 0]);
    ctx.fill();

    // Collar
    ctx.fillStyle = COLLAR;
    ctx.beginPath();
    ctx.moveTo(-5, BY - 52);
    ctx.lineTo(0, BY - 44);
    ctx.lineTo(5, BY - 52);
    ctx.fill();

    // Shirt detail line
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, BY - 44);
    ctx.lineTo(0, BY - 22);
    ctx.stroke();

    // ── LEFT ARM ──
    const isWaving = state === STATES.WAVE;
    ctx.save();
    ctx.translate(-14, BY - 48);
    const leftArmA = isWaving ? armAngle : (state === STATES.CELEBRATE ? armAngle : -armAngle * 0.5);
    ctx.rotate((leftArmA * Math.PI) / 180);
    ctx.fillStyle = SHIRT;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 10, 22, 5);
    ctx.fill();
    // Hand
    ctx.fillStyle = SKIN;
    ctx.beginPath();
    ctx.arc(0, 24, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // ── RIGHT ARM ──
    ctx.save();
    ctx.translate(14, BY - 48);
    const rightArmA = isWaving ? 15 : (state === STATES.THINK ? -armAngle : armAngle * 0.5);
    ctx.rotate((rightArmA * Math.PI) / 180);
    ctx.fillStyle = SHIRT;
    ctx.beginPath();
    ctx.roundRect(-5, 0, 10, 22, 5);
    ctx.fill();
    ctx.fillStyle = SKIN;
    ctx.beginPath();
    ctx.arc(0, 24, 6, 0, Math.PI * 2);
    ctx.fill();
    // Think finger on chin
    if (state === STATES.THINK) {
      ctx.fillStyle = SKIN;
      ctx.beginPath();
      ctx.arc(0, 26, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // ── NECK ──
    ctx.fillStyle = SKIN;
    ctx.beginPath();
    ctx.roundRect(-5, BY - 60, 10, 10, 3);
    ctx.fill();

    // ── HEAD ──
    const headY = BY - 82;
    ctx.fillStyle = SKIN;
    ctx.beginPath();
    ctx.ellipse(0, headY, 18, 20, 0, 0, Math.PI * 2);
    ctx.fill();

    // ── HAIR ──
    ctx.fillStyle = HAIR;
    ctx.beginPath();
    ctx.ellipse(0, headY - 12, 18, 12, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    // Side hair
    ctx.beginPath();
    ctx.ellipse(-18, headY - 4, 4, 8, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(18, headY - 4, 4, 8, 0.3, 0, Math.PI * 2);
    ctx.fill();

    // ── FACE ──
    // Ears
    ctx.fillStyle = SKIN;
    ctx.beginPath();
    ctx.ellipse(-19, headY, 4, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(19, headY, 4, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Glasses frames
    ctx.strokeStyle = GLASSES;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(-14, headY - 5, 10, 8, 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(4, headY - 5, 10, 8, 2);
    ctx.stroke();
    // Bridge
    ctx.beginPath();
    ctx.moveTo(-4, headY - 1);
    ctx.lineTo(4, headY - 1);
    ctx.stroke();
    // Temple pieces
    ctx.beginPath();
    ctx.moveTo(-14, headY - 1);
    ctx.lineTo(-20, headY - 1);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(14, headY - 1);
    ctx.lineTo(20, headY - 1);
    ctx.stroke();

    // Eyes
    if (blinkOpen) {
      ctx.fillStyle = '#2d1a00';
      ctx.beginPath();
      ctx.arc(-9, headY - 1, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(9, headY - 1, 3, 0, Math.PI * 2);
      ctx.fill();
      // Pupils
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(-8, headY - 2, 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(10, headY - 2, 1, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Blink - closed eyes
      ctx.strokeStyle = '#2d1a00';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(-9, headY - 1, 3, Math.PI, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(9, headY - 1, 3, Math.PI, 0);
      ctx.stroke();
    }

    // Eyebrows
    ctx.strokeStyle = HAIR;
    ctx.lineWidth = 1.8;
    ctx.lineCap = 'round';
    let browLift = 0;
    if (state === STATES.THINK) browLift = -3;
    if (state === STATES.CELEBRATE) browLift = -4;
    ctx.beginPath();
    ctx.moveTo(-14, headY - 8 + browLift);
    ctx.quadraticCurveTo(-9, headY - 11 + browLift, -4, headY - 8 + browLift);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(4, headY - 8 + browLift);
    ctx.quadraticCurveTo(9, headY - 11 + browLift, 14, headY - 8 + browLift);
    ctx.stroke();

    // Nose
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, headY - 1);
    ctx.quadraticCurveTo(4, headY + 3, 2, headY + 6);
    ctx.stroke();

    // Mouth
    ctx.strokeStyle = '#c77850';
    ctx.lineWidth = 1.5;
    if (state === STATES.TALK) {
      // Open mouth
      const mouthOpen = Math.abs(Math.sin(frame * 0.3)) * 4;
      ctx.beginPath();
      ctx.ellipse(0, headY + 10, 6, 2 + mouthOpen, 0, 0, Math.PI);
      ctx.stroke();
      ctx.fillStyle = '#a0522d';
      ctx.beginPath();
      ctx.ellipse(0, headY + 10, 5, 1 + mouthOpen, 0, 0, Math.PI);
      ctx.fill();
    } else if (state === STATES.CELEBRATE || state === STATES.WAVE) {
      // Big smile
      ctx.beginPath();
      ctx.moveTo(-8, headY + 8);
      ctx.quadraticCurveTo(0, headY + 16, 8, headY + 8);
      ctx.stroke();
    } else {
      // Normal smile
      ctx.beginPath();
      ctx.moveTo(-6, headY + 9);
      ctx.quadraticCurveTo(0, headY + 14, 6, headY + 9);
      ctx.stroke();
    }

    // Cheek blush (celebrate/wave)
    if (state === STATES.CELEBRATE || state === STATES.WAVE) {
      ctx.fillStyle = 'rgba(255,150,150,0.35)';
      ctx.beginPath();
      ctx.ellipse(-13, headY + 6, 5, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(13, headY + 6, 5, 3, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // THINK bubble
    if (state === STATES.THINK) {
      ctx.fillStyle = 'rgba(61,90,254,0.15)';
      ctx.beginPath();
      ctx.arc(22, headY - 20, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(28, headY - 28, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(24, headY - 38, 9, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  return { init, setState, showMessage, STATES };
})();

/* ══════════════════════════════════════
   CONTACT FORM VALIDATION
══════════════════════════════════════ */
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  const successMsg = document.getElementById('form-success');

  function showError(fieldId, msg) {
    const errEl = document.getElementById(fieldId + '-error');
    if (errEl) {
      errEl.textContent = msg;
      errEl.style.display = 'block';
    }
  }

  function clearErrors() {
    form.querySelectorAll('.form-error').forEach(el => el.style.display = 'none');
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    clearErrors();
    let valid = true;

    const name = form.querySelector('#name');
    const email = form.querySelector('#email');
    const message = form.querySelector('#message');

    if (!name || name.value.trim().length < 2) {
      showError('name', 'Please enter your full name.');
      valid = false;
    }

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
      showError('email', 'Please enter a valid email address.');
      valid = false;
    }

    if (!message || message.value.trim().length < 10) {
      showError('message', 'Please enter a message (at least 10 characters).');
      valid = false;
    }

    if (valid) {
      // Simulate submission
      const btn = form.querySelector('.btn-primary');
      btn.textContent = 'Sending…';
      btn.disabled = true;

      setTimeout(() => {
        form.reset();
        if (successMsg) {
          successMsg.style.display = 'block';
          gsap.from(successMsg, { opacity: 0, y: 10, duration: 0.4 });
        }
        btn.textContent = 'Send Message';
        btn.disabled = false;
        TutorCharacter.setState(TutorCharacter.STATES.CELEBRATE);
        TutorCharacter.showMessage('Message sent! We\'ll reply soon! 🎉');
      }, 1200);
    }
  });
}

/* ══════════════════════════════════════
   COURSE FILTER (courses page)
══════════════════════════════════════ */
function initCourseFilter() {
  const btns = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('[data-category]');
  if (!btns.length) return;

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');

      cards.forEach(card => {
        const show = cat === 'all' || card.getAttribute('data-category') === cat;
        gsap.to(card, {
          opacity: show ? 1 : 0.2,
          scale: show ? 1 : 0.95,
          duration: 0.3,
          ease: 'power2.out'
        });
      });
    });
  });
}

/* ══════════════════════════════════════
   MAIN INIT
══════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initHeroEntrance();
  initStats();
  initCardsDrag();
  initScrollReveal();
  initContactForm();
  initCourseFilter();

  // Init tutor on all pages
  TutorCharacter.init();

  // Hero canvas
  const heroCanvas = document.getElementById('hero-canvas');
  if (heroCanvas) {
    initHeroParticles(heroCanvas);
  }

  // ── PINNED SECTION 1 — Dot Grid ──
  const sec1 = document.getElementById('feature-1');
  if (sec1) {
    const dotGrid = initDotGrid(sec1);
    createPinnedSection(sec1, (p) => {
      dotGrid.update(p);
      if (p > 0.2) fadeInSectionText(sec1, p);
    });
    fadeInText(sec1);
  }

  // ── PINNED SECTION 2 — SVG Line Draw ──
  const sec2 = document.getElementById('feature-2');
  if (sec2) {
    const svgEl = sec2.querySelector('svg');
    if (svgEl) {
      const lineDraw = initLineDraw(svgEl);
      createPinnedSection(sec2, (p) => {
        lineDraw.update(p);
      });
    }
    fadeInText(sec2);
  }

  // ── PINNED SECTION 3 — Converge Particles ──
  const sec3 = document.getElementById('feature-3');
  if (sec3) {
    const cvs = sec3.querySelector('canvas');
    if (cvs) {
      const converge = initConvergeCanvas(cvs);
      createPinnedSection(sec3, (p) => {
        converge.update(p);
      });
    }
    fadeInText(sec3);
  }

  // ── PINNED SECTION 4 — Orbit Rings ──
  const sec4 = document.getElementById('feature-4');
  if (sec4) {
    const cvs = sec4.querySelector('canvas');
    if (cvs) {
      const orbit = initOrbitCanvas(cvs);
      createPinnedSection(sec4, (p) => {
        orbit.update(p);
      });
    }
    fadeInText(sec4);
  }

  // ── PINNED SECTION 5 — Particle Network ──
  const sec5 = document.getElementById('feature-5');
  if (sec5) {
    const cvs = sec5.querySelector('canvas');
    if (cvs) {
      const net = initHeroParticles(cvs);
      createPinnedSection(sec5, (p) => {
        // intensity increases with progress
      });
    }
    fadeInText(sec5);
  }

  // Celebrate on page load after a while
  setTimeout(() => {
    TutorCharacter.setState(TutorCharacter.STATES.WAVE);
  }, 500);

  setTimeout(() => {
    TutorCharacter.setState(TutorCharacter.STATES.IDLE);
  }, 4000);
});

function fadeInSectionText(sec, progress) {
  if (progress < 0.2) return;
  const els = sec.querySelectorAll('.section-label, .section-title, .section-body, .section-link');
  els.forEach((el, i) => {
    if (parseFloat(el.style.opacity || 0) < 1) {
      gsap.to(el, { opacity: 1, y: 0, duration: 0.5, delay: i * 0.08, ease: 'power2.out' });
    }
  });
}
