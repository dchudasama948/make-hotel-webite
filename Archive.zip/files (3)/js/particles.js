/* ============================================================
   LEARNOVA ACADEMY — PARTICLES.JS
   Three.js Hero + Canvas Particle Systems
   ============================================================ */

window.ParticleSystems = {};

// ── Three.js Hero Particle Field ─────────────────────────────
(function initThreeHero() {
  const container = document.getElementById('three-hero');
  if (!container || typeof THREE === 'undefined') return;

  const W = container.offsetWidth;
  const H = container.offsetHeight;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(W, H);
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);
  renderer.domElement.style.position = 'absolute';
  renderer.domElement.style.inset = '0';

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, W / H, 0.1, 1000);
  camera.position.z = 5;

  const COUNT = 2200;
  const positions = new Float32Array(COUNT * 3);
  const colors = new Float32Array(COUNT * 3);
  const sizes = new Float32Array(COUNT);

  for (let i = 0; i < COUNT; i++) {
    positions[i * 3]     = (Math.random() - 0.5) * 16;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 9;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 6;

    // White with occasional red sparks
    const isRed = Math.random() < 0.07;
    colors[i * 3]     = isRed ? 1.0 : 0.9 + Math.random() * 0.1;
    colors[i * 3 + 1] = isRed ? 0.24 : 0.9 + Math.random() * 0.1;
    colors[i * 3 + 2] = isRed ? 0.0  : 0.9 + Math.random() * 0.1;

    sizes[i] = isRed ? (Math.random() * 0.04 + 0.03) : (Math.random() * 0.025 + 0.01);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

  const mat = new THREE.ShaderMaterial({
    vertexColors: true,
    transparent: true,
    uniforms: {
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
    },
    vertexShader: `
      attribute float size;
      attribute vec3 color;
      varying vec3 vColor;
      uniform float uTime;
      uniform vec2 uMouse;
      void main() {
        vColor = color;
        vec3 pos = position;
        // gentle drift
        pos.x += sin(uTime * 0.3 + position.y * 1.2) * 0.08;
        pos.y += cos(uTime * 0.25 + position.x * 1.1) * 0.08;
        pos.z += sin(uTime * 0.2 + position.z * 0.8) * 0.05;
        // mouse parallax
        pos.x += uMouse.x * 0.6;
        pos.y += uMouse.y * 0.4;
        vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
        gl_PointSize = size * (380.0 / -mvPosition.z);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      varying vec3 vColor;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        if (d > 0.5) discard;
        float alpha = 1.0 - smoothstep(0.3, 0.5, d);
        gl_FragColor = vec4(vColor, alpha * 0.75);
      }
    `,
  });

  const points = new THREE.Points(geo, mat);
  scene.add(points);

  // Mouse
  let mouseX = 0, mouseY = 0;
  let targetMX = 0, targetMY = 0;
  window.addEventListener('mousemove', e => {
    targetMX = (e.clientX / window.innerWidth - 0.5) * 0.5;
    targetMY = -(e.clientY / window.innerHeight - 0.5) * 0.5;
  }, { passive: true });

  // Resize
  window.addEventListener('resize', () => {
    const nW = container.offsetWidth;
    const nH = container.offsetHeight;
    camera.aspect = nW / nH;
    camera.updateProjectionMatrix();
    renderer.setSize(nW, nH);
  });

  let frameId;
  function animate(t) {
    frameId = requestAnimationFrame(animate);
    const time = t * 0.001;
    mat.uniforms.uTime.value = time;
    mouseX += (targetMX - mouseX) * 0.05;
    mouseY += (targetMY - mouseY) * 0.05;
    mat.uniforms.uMouse.value.set(mouseX, mouseY);
    renderer.render(scene, camera);
  }
  animate(0);

  // Fade out when scroll leaves hero
  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.create({
      trigger: '#cinematic-stage',
      start: 'top top',
      end: '+=200%',
      onUpdate(self) {
        renderer.domElement.style.opacity = Math.max(0, 1 - self.progress * 3);
      }
    });
  }
})();

// ── Feature 3: Converge Canvas ────────────────────────────────
window.ParticleSystems.initConvergeCanvas = function(canvas) {
  const ctx = canvas.getContext('2d');
  const COUNT = 200;
  const particles = [];

  function resize() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    resetParticles();
  }

  function resetParticles() {
    particles.length = 0;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const R = Math.min(cx, cy) * 0.45;

    for (let i = 0; i < COUNT; i++) {
      const angle = (i / COUNT) * Math.PI * 2;
      particles.push({
        // Circle target position
        tx: cx + Math.cos(angle) * R,
        ty: cy + Math.sin(angle) * R,
        // Scatter position
        sx: (Math.random() - 0.5) * canvas.width * 1.5 + cx,
        sy: (Math.random() - 0.5) * canvas.height * 1.5 + cy,
        // Current
        x: (Math.random() - 0.5) * canvas.width * 1.5 + cx,
        y: (Math.random() - 0.5) * canvas.height * 1.5 + cy,
        r: Math.random() * 2 + 1,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
      });
    }
  }

  resize();
  window.addEventListener('resize', resize);

  let progress = 0;

  function draw() {
    requestAnimationFrame(draw);
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    particles.forEach(p => {
      // Phase 1: scatter (progress 0→0.5)
      // Phase 2: converge to circle (progress 0.5→1)
      let targetX, targetY;
      if (progress < 0.5) {
        const lp = progress * 2; // 0→1
        targetX = p.sx;
        targetY = p.sy;
        p.x += (targetX - p.x) * 0.02 + p.vx * (1 - lp);
        p.y += (targetY - p.y) * 0.02 + p.vy * (1 - lp);
      } else {
        const lp = (progress - 0.5) * 2; // 0→1
        targetX = p.tx;
        targetY = p.ty;
        p.x += (targetX - p.x) * (0.04 + lp * 0.06);
        p.y += (targetY - p.y) * (0.04 + lp * 0.06);
      }

      const brightness = 0.3 + progress * 0.7;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,61,0,${brightness * 0.8})`;
      ctx.fill();

      // Connect nearby
      particles.forEach(q => {
        const dx = p.x - q.x;
        const dy = p.y - q.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 60 && dist > 0) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(255,61,0,${(1 - dist / 60) * 0.12})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      });
    });
  }
  draw();

  return {
    setProgress(p) { progress = p; }
  };
};

// ── Feature Hero bg: standard particle canvas ─────────────────
(function initPageHeroCanvas() {
  const canvas = document.getElementById('page-hero-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const particles = [];

  function resize() {
    canvas.width = canvas.offsetWidth || window.innerWidth;
    canvas.height = canvas.offsetHeight || 500;
  }
  resize();
  window.addEventListener('resize', resize);

  for (let i = 0; i < 80; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() * 1.5 + 0.5
    });
  }

  let mx = -999, my = -999;
  window.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; }, { passive: true });

  function draw() {
    requestAnimationFrame(draw);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p, i) => {
      // Repel from mouse
      const dx = p.x - mx;
      const dy = p.y - my;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 100) {
        p.vx += dx / dist * 0.3;
        p.vy += dy / dist * 0.3;
      }
      p.vx *= 0.98;
      p.vy *= 0.98;
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const ddx = p.x - particles[j].x;
        const ddy = p.y - particles[j].y;
        const d = Math.sqrt(ddx * ddx + ddy * ddy);
        if (d < 120) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(255,255,255,${(1 - d / 120) * 0.06})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    });
  }
  draw();
})();
