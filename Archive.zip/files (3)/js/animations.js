/* ============================================================
   LEARNOVA ACADEMY — ANIMATIONS.JS
   GSAP ScrollTrigger + Anime.js driven cinematic scroll system
   ============================================================ */

// ── Cursor ──────────────────────────────────────────────────
(function initCursor() {
  const cursor = document.getElementById('cursor');
  const trail = document.getElementById('cursor-trail');
  if (!cursor) return;

  let mx = 0, my = 0, tx = 0, ty = 0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cursor.style.left = mx + 'px';
    cursor.style.top = my + 'px';
  });

  function animTrail() {
    tx += (mx - tx) * 0.12;
    ty += (my - ty) * 0.12;
    trail.style.left = tx + 'px';
    trail.style.top = ty + 'px';
    requestAnimationFrame(animTrail);
  }
  animTrail();

  document.querySelectorAll('a, button, .drag-card').forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursor.style.width = '20px';
      cursor.style.height = '20px';
      trail.style.width = '54px';
      trail.style.height = '54px';
    });
    el.addEventListener('mouseleave', () => {
      cursor.style.width = '12px';
      cursor.style.height = '12px';
      trail.style.width = '36px';
      trail.style.height = '36px';
    });
  });
})();

// ── Navbar ───────────────────────────────────────────────────
(function initNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  // Mobile hamburger
  const ham = document.querySelector('.nav-hamburger');
  const links = document.querySelector('.nav-links');
  if (ham && links) {
    ham.addEventListener('click', () => {
      const open = links.style.display === 'flex';
      links.style.display = open ? 'none' : 'flex';
      links.style.flexDirection = open ? '' : 'column';
      links.style.position = open ? '' : 'absolute';
      links.style.top = open ? '' : '60px';
      links.style.right = open ? '' : '0';
      links.style.left = open ? '' : '0';
      links.style.background = open ? '' : 'rgba(10,10,10,0.97)';
      links.style.padding = open ? '' : '1.5rem 2rem';
    });
  }
})();

// ── Draggable Track ──────────────────────────────────────────
(function initDragTracks() {
  document.querySelectorAll('.drag-track').forEach(track => {
    let isDown = false, startX, scrollLeft;
    track.addEventListener('mousedown', e => {
      isDown = true;
      startX = e.pageX - track.offsetLeft;
      scrollLeft = track.scrollLeft;
    });
    document.addEventListener('mouseup', () => isDown = false);
    track.addEventListener('mousemove', e => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - track.offsetLeft;
      track.scrollLeft = scrollLeft - (x - startX) * 1.5;
    });
    // Touch
    track.addEventListener('touchstart', e => {
      startX = e.touches[0].pageX - track.offsetLeft;
      scrollLeft = track.scrollLeft;
    }, { passive: true });
    track.addEventListener('touchmove', e => {
      const x = e.touches[0].pageX - track.offsetLeft;
      track.scrollLeft = scrollLeft - (x - startX) * 1.5;
    }, { passive: true });
  });
})();

// ── GSAP Cinematic Scroll ────────────────────────────────────
window.addEventListener('load', function () {
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  gsap.registerPlugin(ScrollTrigger);

  const isMobile = window.innerWidth <= 900;

  // ─── Hero word entrance (always runs) ─────────────────────
  const heroWords = document.querySelectorAll('.hero-word');
  const heroSub = document.querySelector('.hero-sub');
  const scrollHint = document.querySelector('.scroll-hint');

  if (heroWords.length) {
    anime({
      targets: heroWords,
      translateY: [110, 0],
      easing: 'cubicBezier(0.16, 1, 0.3, 1)',
      duration: 820,
      delay: anime.stagger(80, { start: 200 }),
    });
    anime({
      targets: [heroSub, scrollHint].filter(Boolean),
      translateY: [20, 0],
      opacity: [0, 1],
      easing: 'easeOutCubic',
      duration: 700,
      delay: 900,
    });
  }

  if (isMobile) {
    // On mobile — show all cut panels statically
    document.querySelectorAll('.cut-panel').forEach(p => {
      p.style.position = 'relative';
      p.style.opacity = '1';
      p.style.pointerEvents = 'auto';
    });
    initMobileStats();
    return;
  }

  // ─── Cinematic Stage: 5 cuts over 700vh ───────────────────
  const stage = document.getElementById('cinematic-stage');
  const cuts = document.querySelectorAll('.cut-panel');
  if (!stage || !cuts.length) goto_features();

  if (stage && cuts.length) {
    // Activate cut 0 immediately
    cuts[0].style.opacity = '1';
    cuts[0].style.pointerEvents = 'auto';

    const proxy = { t: 0 };

    gsap.to(proxy, {
      t: 1,
      ease: 'none',
      scrollTrigger: {
        trigger: stage,
        start: 'top top',
        end: '+=600%',
        pin: true,
        scrub: 0.8,
        onUpdate(self) {
          const p = self.progress; // 0 → 1
          // Cut thresholds: 0, 0.2, 0.45, 0.65, 0.82, end
          const cutIndex =
            p < 0.2  ? 0 :
            p < 0.45 ? 1 :
            p < 0.65 ? 2 :
            p < 0.82 ? 3 :
                       4;

          cuts.forEach((c, i) => {
            c.style.opacity = (i === cutIndex) ? '1' : '0';
            c.style.pointerEvents = (i === cutIndex) ? 'auto' : 'none';
          });

          // Local progress within each cut
          if (cutIndex === 1) {
            const lp = (p - 0.2) / 0.25;
            animateCut1(lp);
          }
          if (cutIndex === 2) {
            const lp = (p - 0.45) / 0.20;
            animateCut2(lp);
          }
          if (cutIndex === 3) {
            const lp = (p - 0.65) / 0.17;
            animateCut3(lp);
          }
          if (cutIndex === 4) {
            const lp = (p - 0.82) / 0.18;
            animateCut4(lp);
          }
        }
      }
    });

    setupCut1Cards();
    setupCut2Stats();
    setupCut3SpringCards();
    setupCut4Mentors();
  }

  goto_features();
});

// ─── Cut 1: Film reel cards ──────────────────────────────────
function setupCut1Cards() {}
let cut1Done = false;
function animateCut1(lp) {
  if (lp < 0.05) cut1Done = false;
  if (!cut1Done && lp > 0.1) {
    cut1Done = true;
    anime({
      targets: '.reel-card',
      translateX: [120, 0],
      opacity: [0, 1],
      easing: 'cubicBezier(0.16, 1, 0.3, 1)',
      duration: 700,
      delay: anime.stagger(80),
    });
  }
}

// ─── Cut 2: Rolling counters ─────────────────────────────────
function setupCut2Stats() {}
let cut2Done = false;
function animateCut2(lp) {
  if (lp < 0.05) cut2Done = false;
  if (!cut2Done && lp > 0.15) {
    cut2Done = true;
    const targets = [
      { el: document.getElementById('stat0'), val: 26 },
      { el: document.getElementById('stat1'), val: 20 },
      { el: document.getElementById('stat2'), val: 50000 },
      { el: document.getElementById('stat3'), val: 4.9 },
    ];
    targets.forEach((t, i) => {
      if (!t.el) return;
      anime({
        targets: t.el,
        innerHTML: [0, t.val],
        round: t.val < 10 ? 0 : 1,
        easing: 'easeOutExpo',
        duration: 1400,
        delay: i * 150,
        update(a) {
          if (t.val === 50000) t.el.textContent = Math.floor(parseFloat(t.el.innerHTML)).toLocaleString() + 'K+';
          else if (t.val === 4.9) t.el.textContent = parseFloat(t.el.innerHTML).toFixed(1) + '★';
          else t.el.textContent = Math.floor(parseFloat(t.el.innerHTML)) + '+';
        }
      });
    });
  }
}

// ─── Cut 3: Spring cards ─────────────────────────────────────
let cut3Done = false;
function setupCut3SpringCards() {}
function animateCut3(lp) {
  if (lp < 0.05) cut3Done = false;
  if (!cut3Done && lp > 0.1) {
    cut3Done = true;
    anime({
      targets: '.spring-card',
      translateY: [80, 0],
      opacity: [0, 1],
      easing: 'spring(1, 80, 10, 0)',
      duration: 900,
      delay: anime.stagger(60),
    });
  }
}

// ─── Cut 4: Mentor tiles scale ───────────────────────────────
let cut4Done = false;
function setupCut4Mentors() {}
function animateCut4(lp) {
  if (lp < 0.05) cut4Done = false;
  if (!cut4Done && lp > 0.1) {
    cut4Done = true;
    anime({
      targets: '.mentor-tile',
      scale: [0.7, 1],
      opacity: [0, 1],
      easing: 'spring(1, 75, 10, 0)',
      duration: 900,
      delay: anime.stagger(80),
    });
  }
}

// ─── Mobile stats fallback ───────────────────────────────────
function initMobileStats() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      animateCut2(1);
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.4 });
  const cut2 = document.getElementById('cut-2');
  if (cut2) observer.observe(cut2);

  const c1ob = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      animateCut1(1);
      c1ob.unobserve(entry.target);
    });
  }, { threshold: 0.3 });
  const cut1 = document.getElementById('cut-1');
  if (cut1) c1ob.observe(cut1);

  const c3ob = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      animateCut3(1);
      c3ob.unobserve(entry.target);
    });
  }, { threshold: 0.3 });
  const cut3 = document.getElementById('cut-3');
  if (cut3) c3ob.observe(cut3);

  const c4ob = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      animateCut4(1);
      c4ob.unobserve(entry.target);
    });
  }, { threshold: 0.3 });
  const cut4 = document.getElementById('cut-4');
  if (cut4) c4ob.observe(cut4);
}

// ─── Feature pinned sections (post-stage) ────────────────────
function goto_features() {
  const isMobile = window.innerWidth <= 900;
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  gsap.registerPlugin(ScrollTrigger);

  // Feature 1: Dot grid
  const f1 = document.getElementById('feature-1');
  if (f1 && !isMobile) {
    const dots = f1.querySelectorAll('.dot-grid-dot');
    const textEl = f1.querySelector('.feature-text');
    if (textEl) gsap.set(textEl, { opacity: 0 });

    const proxy1 = { p: 0 };
    gsap.to(proxy1, {
      p: 1, ease: 'none',
      scrollTrigger: {
        trigger: f1,
        start: 'top top',
        end: '+=250%',
        pin: true,
        scrub: 1,
        onUpdate(self) {
          const p = self.progress;
          dots.forEach((dot, i) => {
            const delay = i / dots.length;
            const lp = Math.max(0, Math.min(1, (p - delay * 0.4) / 0.6));
            dot.style.transform = `scale(${1 + lp * 1.8})`;
            dot.style.opacity = 0.08 + lp * 0.85;
            dot.style.background = lp > 0
              ? `rgba(255,61,0,${lp * 0.9})`
              : 'rgba(255,255,255,0.08)';
          });
          if (textEl) textEl.style.opacity = Math.max(0, (p - 0.2) / 0.3);
        }
      }
    });
  }

  // Feature 2: SVG line draw
  const f2 = document.getElementById('feature-2');
  if (f2 && !isMobile) {
    const paths = f2.querySelectorAll('.svg-path');
    const textEl = f2.querySelector('.feature-text');
    paths.forEach(path => {
      const len = path.getTotalLength();
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = len;
    });
    if (textEl) gsap.set(textEl, { opacity: 0 });

    const proxy2 = { p: 0 };
    gsap.to(proxy2, {
      p: 1, ease: 'none',
      scrollTrigger: {
        trigger: f2,
        start: 'top top',
        end: '+=250%',
        pin: true,
        scrub: 1,
        onUpdate(self) {
          const p = self.progress;
          paths.forEach((path, i) => {
            const len = parseFloat(path.style.strokeDasharray);
            const offset = len * (1 - Math.min(1, p * 1.2));
            path.style.strokeDashoffset = offset;
          });
          if (textEl) textEl.style.opacity = Math.max(0, (p - 0.3) / 0.3);
        }
      }
    });
  }

  // Feature 3: Particle converge (canvas from particles.js)
  const f3 = document.getElementById('feature-3');
  if (f3 && !isMobile) {
    const canvas = f3.querySelector('canvas');
    const textEl = f3.querySelector('.feature-text');
    if (textEl) gsap.set(textEl, { opacity: 0 });

    let particleSystem;
    if (canvas && window.ParticleSystems) {
      particleSystem = window.ParticleSystems.initConvergeCanvas(canvas);
    }

    const proxy3 = { p: 0 };
    gsap.to(proxy3, {
      p: 1, ease: 'none',
      scrollTrigger: {
        trigger: f3,
        start: 'top top',
        end: '+=250%',
        pin: true,
        scrub: 1,
        onUpdate(self) {
          const p = self.progress;
          if (particleSystem) particleSystem.setProgress(p);
          if (textEl) textEl.style.opacity = Math.max(0, (p - 0.3) / 0.3);
        }
      }
    });
  }

  // Feature 4: Orbit rings
  const f4 = document.getElementById('feature-4');
  if (f4 && !isMobile) {
    const textEl = f4.querySelector('.feature-text');
    if (textEl) gsap.set(textEl, { opacity: 0 });
    const rings = f4.querySelectorAll('.orbit-ring');

    const proxy4 = { p: 0 };
    gsap.to(proxy4, {
      p: 1, ease: 'none',
      scrollTrigger: {
        trigger: f4,
        start: 'top top',
        end: '+=250%',
        pin: true,
        scrub: 1,
        onUpdate(self) {
          const p = self.progress;
          rings.forEach((ring, i) => {
            const speed = (i + 1) * 180;
            ring.style.transform = `rotate(${p * speed}deg)`;
          });
          if (textEl) textEl.style.opacity = Math.max(0, (p - 0.25) / 0.35);
        }
      }
    });
  }

  // Scroll-reveal for non-pinned sections
  gsap.utils.toArray('.reveal').forEach(el => {
    gsap.fromTo(el,
      { opacity: 0, y: 40 },
      {
        opacity: 1, y: 0, duration: 0.9, ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none reverse' }
      }
    );
  });
}

// ── Contact Form Validation ───────────────────────────────────
(function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  function showError(id, msg) {
    const group = document.getElementById(id).closest('.form-group');
    document.getElementById(id).classList.add('error');
    const errEl = group.querySelector('.form-error-msg');
    if (errEl) { errEl.textContent = msg; errEl.classList.add('show'); }
  }
  function clearError(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('error');
    const errEl = el.closest('.form-group').querySelector('.form-error-msg');
    if (errEl) errEl.classList.remove('show');
  }

  ['cf-name','cf-email','cf-phone','cf-message'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', () => clearError(id));
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    let valid = true;

    const name = document.getElementById('cf-name');
    const email = document.getElementById('cf-email');
    const phone = document.getElementById('cf-phone');
    const message = document.getElementById('cf-message');

    if (name && name.value.trim().length < 2) {
      showError('cf-name', 'Please enter your full name.'); valid = false;
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
      showError('cf-email', 'Please enter a valid email address.'); valid = false;
    }
    if (phone && phone.value.trim() && !/^\+?[\d\s\-]{7,15}$/.test(phone.value.trim())) {
      showError('cf-phone', 'Please enter a valid phone number.'); valid = false;
    }
    if (message && message.value.trim().length < 10) {
      showError('cf-message', 'Please enter a message (min 10 characters).'); valid = false;
    }

    if (valid) {
      form.style.display = 'none';
      const success = document.getElementById('form-success');
      if (success) success.classList.add('show');
    }
  });
})();
